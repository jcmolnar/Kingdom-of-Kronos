$AccessoryVar[TerminusEst, $AccessoryType] = $SwordAccessoryType;
$AccessoryVar[TerminusEst, $SpecialVar] = "6 600";
$AccessoryVar[TerminusEst, $Weight] = 10;
$AccessoryVar[TerminusEst, $MiscInfo] = "A sword used by a great warrior Terminus Est = This is the end";
$SkillType[TerminusEst] = $SkillSlashing;
$ItemCost[TerminusEst] = 700000000;
$SkillRestriction[TerminusEst] = $SkillSlashing @ " 2030 " @ $MinRemort @ " 50";
//****************************************************************************************************
//   Terminus Est
//****************************************************************************************************

ItemImageData TerminusEstImage
{
	shapeFile  = "elfinblade";
	mountPoint = 0;

	weaponType = 0;
	reloadTime = 0;
	fireTime = 0.5;
	minEnergy = 0;
	maxEnergy = 0;

	accuFire = true;

	sfxFire = SoundSwing2;
	sfxActivate = ActivateAS;
};
ItemData TerminusEst
{
	heading = "bWeapons";
	description = "Terminus Est";
	className = "Weapon";
	shapeFile  = "katana";
	hudIcon = "blaster";
	shadowDetailMask = 4;
	imageType = TerminusEstImage;
	price = 0;
	showWeaponBar = true;
};
function TerminusEstImage::onFire(%player, %slot)
{
	MeleeAttack(%player, GetRange(TerminusEst), TerminusEst);
}

function TerminusEst::onMount(%player,%item,$WeaponSlot) 
{   %client = Player::getclient(%player); 
   bottomprint(%client, "<f1>Terminus Est: <f0>Attack: <f2>600    <f0>Skill Slashing Req @ <f2>2030 Remort 50    <f0>Speed: <f2>0.50 Seconds    <f0>Price: <f2>$700,000,000    <f0>Weight: <f2>10 Lbs");
}

//****************************************************************************************************
//   Aeco Seorei
//****************************************************************************************************
$AccessoryVar[AecoSeorei, $AccessoryType] = $PolearmAccessoryType;
$AccessoryVar[AecoSeorei, $SpecialVar] = "6 600";
$AccessoryVar[AecoSeorei, $Weight] = 10;
$AccessoryVar[AecoSeorei, $MiscInfo] = "A legendary spear of unmatched power and speed";
$SkillType[AecoSeorei] = $SkillPiercing;
$ItemCost[AecoSeorei] = 700000000;
$SkillRestriction[AecoSeorei] = $SkillPiercing @ " 2030 " @ $MinRemort @ " 50";

ItemImageData AecoSeoreiImage
{
	shapeFile  = "spear";
	mountPoint = 0;

	weaponType = 0;
	reloadTime = 0;
	fireTime = 0.5;
	minEnergy = 0;
	maxEnergy = 0;

	accuFire = true;

	sfxFire = SoundSwing3;
	sfxActivate = AxeSlash2;
};
ItemData AecoSeorei
{
	heading = "bWeapons";
	description = "Aeco Seorei";
	className = "Weapon";
	shapeFile  = "spear";
	hudIcon = "trident";
	shadowDetailMask = 4;
	imageType = AecoSeoreiImage;
	price = 0;
	showWeaponBar = true;
};
function AecoSeoreiImage::onFire(%player, %slot)
{
	MeleeAttack(%player, GetRange(AecoSeorei), AecoSeorei);
}

function AecoSeorei::onMount(%player,%item,$WeaponSlot) 
{   %client = Player::getclient(%player); 
   bottomprint(%client, "<f1>Aeco Seorei: <f0>Attack: <f2>600    <f0>Skill Piercing Req @ <f2>2030 Remort 50    <f0>Speed: <f2>0.50 Seconds    <f0>Price: <f2>$700,000,000    <f0>Weight: <f2>10 Lbs");
}

//****************************************************************************************************
//   Morning Star
//****************************************************************************************************
$AccessoryVar[MorningStar, $AccessoryType] = $BludgeonAccessoryType;
$AccessoryVar[MorningStar, $SpecialVar] = "6 600";
$AccessoryVar[MorningStar, $Weight] = 10;
$AccessoryVar[MorningStar, $MiscInfo] = "A devastating mace of legendary power";
$SkillType[MorningStar] = $SkillBludgeoning;
$ItemCost[MorningStar] = 700000000;
$SkillRestriction[MorningStar] = $SkillBludgeoning @ " 2030 " @ $MinRemort @ " 50";

ItemImageData MorningStarImage
{
	shapeFile  = "mace";
	mountPoint = 0;

	weaponType = 0;
	reloadTime = 0;
	fireTime = GetDelay(MorningStar);
	minEnergy = 0;
	maxEnergy = 0;

	accuFire = true;

	sfxFire = SoundSwing5;
	sfxActivate = AxeSlash2;
};
ItemData MorningStar
{
	heading = "bWeapons";
	description = "Morning Star";
	className = "Weapon";
	shapeFile  = "mace";
	hudIcon = "sclub";
	shadowDetailMask = 4;
	imageType = MorningStarImage;
	price = 0;
	showWeaponBar = true;
};
function MorningStarImage::onFire(%player, %slot)
{
	MeleeAttack(%player, GetRange(MorningStar), MorningStar);
}

function MorningStar::onMount(%player,%item,$WeaponSlot) 
{   %client = Player::getclient(%player); 
   bottomprint(%client, "<f1>Morning Star: <f0>Attack: <f2>600    <f0>Skill Bludgeoning Req @ <f2>2030 Remort 50    <f0>Speed: <f2>" @ GetDelay(MorningStar) @ " Seconds    <f0>Price: <f2>$700,000,000    <f0>Weight: <f2>10 Lbs");
}


//ARMORS
$ItemCost[RedDiamondPlate] = 900000000;
$AccessoryVar[RedDiamondPlate, $AccessoryType] = $BodyAccessoryType;
$AccessoryVar[RedDiamondPlate, $SpecialVar] = "7 1500 4 800 3 250 10 3.0";
$AccessoryVar[RedDiamondPlate, $Weight] = 900;
$AccessoryVar[RedDiamondPlate, $MiscInfo] = "Mastery put into armor. Rare red diamond makes it stronger than Black diamond.";
$ArmorSkin[RedDiamondPlate] = "rpghuman7";
$ArmorPlayerModel[RedDiamondPlate] = "";
$ArmorHitSound[RedDiamondPlate] = SoundHitPlate;
	$ArmorList[19] = "RedDiamondPlate";
	$SkillRestriction[RedDiamondPlate] = $SkillEndurance @ " 1950 " @ $MinRemort @ " 50";
//============================================================================
ItemData RedDiamondPlate
{
	description = "Red Diamond Plate";
	className = "Accessory";
	shapeFile = "discammo";

	heading = "eMiscellany";
	price = 0;

	lightType = 1;   // Always on
	lightRadius = 10;
	lightColor = { 1.0, 0.2, 0.2 };  // Bright red glow
};
ItemData RedDiamondPlate0
{
	description = "Red Diamond Plate";
	className = "Equipped";
	shapeFile = "discammo";

	lightType = 1;   // Always on
	lightRadius = 10;
	lightColor = { 1.0, 0.2, 0.2 };  // Bright red glow

	heading = "aArmor";
};
$ItemCost[WhiteDiamondPlate] = 1000000000;
$AccessoryVar[WhiteDiamondPlate, $AccessoryType] = $BodyAccessoryType;
$AccessoryVar[WhiteDiamondPlate, $SpecialVar] = "7 2000 4 1000 3 500 10 4.0";
$AccessoryVar[WhiteDiamondPlate, $Weight] = 1500;
$AccessoryVar[WhiteDiamondPlate, $MiscInfo] = "The rarest of white diamonds put into armor!";
$ArmorSkin[WhiteDiamondPlate] = "rpghuman9";
$ArmorPlayerModel[WhiteDiamondPlate] = "";
$ArmorHitSound[WhiteDiamondPlate] = SoundHitPlate;
	$ArmorList[987] = "WhiteDiamondPlate";
	$SkillRestriction[WhiteDiamondPlate] = $SkillEndurance @ " 2400 " @ $MinRemort @ " 75";
//============================================================================
ItemData WhiteDiamondPlate
{
	description = "White Diamond Plate";
	className = "Accessory";
	shapeFile = "discammo";

	heading = "eMiscellany";
	price = 0;

	lightType = 2;   // Pulsing
	lightRadius = 10;
	lightColor = { 1.0, 1.0, 1.0 };  // Bright white
};
ItemData WhiteDiamondPlate0
{
	description = "White Diamond Plate";
	className = "Equipped";
	shapeFile = "discammo";

	lightType = 2;   // Pulsing
	lightRadius = 10;
	lightColor = { 1.0, 1.0, 1.0 };  // Bright white

	heading = "aArmor";
};
//============================================================================