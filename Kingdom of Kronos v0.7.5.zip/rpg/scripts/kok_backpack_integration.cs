// =====================
// Kingdom of Kronos — Backpack Integration (slot-free pickups)
// Version: 1.0 (2025-11-12)
// 
// ***** DEPRECATED *****
// This file has been MERGED into backpack.cs (consolidated version)
// DO NOT exec both files - use only backpack.cs
// This file is kept for reference only
// ***** DEPRECATED *****
//
// Original purpose:
//  - Sends backpack-registered items straight into the virtual backpack on pickup
//    instead of consuming Tribes inventory slots.
//  - Fixes backpack weight tally to count all categories (Quest/Rare/Keys/Scrolls/Unique).
//  - Adds robust detection for whether an item is managed by the backpack registry.
//  - Leaves non-managed items alone (vanilla inventory behavior).
//
// All functionality is now in: backpack.cs
//
// =====================
// CONFIG
// =====================

// The logical categories used by the backpack registry in your pack.
// If you add more categories in backpack.cs, include them here too.
$KOK::BackpackTypes[1] = "QuestItems";
$KOK::BackpackTypes[2] = "RareItems";
$KOK::BackpackTypes[3] = "KeysItems";
$KOK::BackpackTypes[4] = "ScrollsItems";
$KOK::BackpackTypes[5] = "UniqueItems";
$KOK::BackpackTypesCount = 5;

// =====================
// HELPERS
// =====================

// Return true if the given ItemData (%item) is registered to be managed by the virtual backpack.
// This probes the registry in a few different ways to be compatible with variations of backpack.cs.
function Backpack::IsManaged(%item)
{
   // Fast path: many builds store by name directly
   if ($Backpackitem[%item, "Item"] != "" || $Backpackitem[%item, "Num"] != "")
      return True;

   // Scan per-category arrays for either an "Item" or "Num" entry that matches %item
   for (%t = 1; %t <= $KOK::BackpackTypesCount; %t++)
   {
      %type = $KOK::BackpackTypes[%t];
      %max  = $count[%type];
      for (%i = 0; %i <= %max; %i++)
      {
         // Some packs store the ItemData at "Item", others invert to "Num".
         %itmByName = $Backpackitem[%i, "Item", %type];
         %itmByNum  = $Backpackitem[%i, "Num",  %type];

         if (%itmByName == %item || %itmByNum == %item)
            return True;
      }
   }

   // Fallback: if the registry has a by-name index map
   if ($BackpackIndexByItem[%item] != "")
      return True;

   return False;
}

// Compute the weight of all items inside the backpack for a client (sum only; does not write state).
function Backpack::GetWeight(%clientId)
{
   %total = 0;

   for (%t = 1; %t <= $KOK::BackpackTypesCount; %t++)
   {
      %type = $KOK::BackpackTypes[%t];
      %max  = $count[%type];

      for (%i = 0; %i <= %max; %i++)
      {
         %itm = $Backpackitem[%i, "Num", %type];
         if (%itm == "") %itm = $Backpackitem[%i, "Item", %type];
         if (%itm == "") continue;

         %amt = Backpack::HasThisStuff(%clientId, %itm);
         if (%amt <= 0) continue;

         %wgt = $AccessoryVar[%itm, $Weight];
         if (%wgt == "") %wgt = 0;
         %total += (%amt * %wgt);
      }
   }
   return %total;
}

// User-friendly receipt message (mirrors your existing style where possible).
function Backpack::ReceiptMsg(%clientId, %item, %delta)
{
   %name = (%item.description == "" ? %item : %item.description);
   if (%delta == "" || %delta <= 0) %delta = 1;
   Client::sendMessage(%clientId, 0, "You received " @ %delta @ " " @ %name @ " (stored in backpack).");
}

// =====================
// CORE OVERRIDE
// =====================

// Intercept grants/pickups. For backpack-managed items, send to virtual backpack storage and
// DO NOT increment Tribes inventory counts (freeing up slots).
function Item::giveItem(%player, %item, %delta, %showmsg)
{
   %clientId = Player::getClient(%player);
   if (!isObject(%clientId)) // safety
      return 0;

   if (%delta == "" || %delta <= 0) %delta = 1;

   if (Backpack::IsManaged(%item))
   {
      // Deposit directly to backpack
      Backpack::GiveThisStuff(%clientId, %item, %delta, True);
      if (%showmsg) Backpack::ReceiptMsg(%clientId, %item, %delta);
      // Important: DO NOT touch Player::incItemCount for managed items.
      return %delta;
   }

   // Non-managed items follow vanilla behavior.
   if (%showmsg)
      Client::sendMessage(%clientId, 0, "You received " @ %delta @ " " @ (%item.description == "" ? %item : %item.description) @ ".");
   Player::incItemCount(%clientId, %item, %delta);
   return %delta;
}

// =====================
// OPTIONAL: NORMALIZATION UTILITIES
// =====================

// Some packs registered a wrong category string (e.g., "uniqueItemsItems"). This helper
// normalizes obvious typos at runtime so those lines won't break things until you clean them up.
function Backpack::NormalizeType(%type)
{
   %t = strtolower(%type);
   if (%t == "uniqueitemsitems") return "UniqueItems";
   if (%t == "uniqueitem")       return "UniqueItems";
   if (%t == "questitem")        return "QuestItems";
   if (%t == "keyitems" || %t == "keysitem") return "KeysItems";
   if (%t == "scrollitems" || %t == "scrollitem") return "ScrollsItems";
   if (%t == "rareitem")         return "RareItems";
   // Default: return as-is
   return %type;
}

// If your BackpackItem::Add calls this, it'll correct the category silently.
if (isFunction("BackpackItem::Add"))
{
   if ($KOK::_WrappedBackpackAdd != True)
   {
      $KOK::_WrappedBackpackAdd = True;
      function BackpackItem::Add(%name, %item, %type, %weight, %cost)
      {
         %type = Backpack::NormalizeType(%type);
         parent::BackpackItem::Add(%name, %item, %type, %weight, %cost);
      }
   }
}

// =====================
// END
// =====================
