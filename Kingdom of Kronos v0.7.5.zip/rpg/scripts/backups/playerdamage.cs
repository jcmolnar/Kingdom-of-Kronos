function Client::onKilled(%clientId, %killerId, %damageType)
{
	dbecho($dbechoMode, "Client::onKilled(" @ %clientId @ ", " @ %killerId @ ", " @ %damageType @ ")");

	//This function is NOT an event, it must be MANUALLY CALLED!
	//At this point, the client can still be queried for getItemCounts, but is not considered an object anymore.

	//we can award the other players exp
	if(!fetchData(%clientId, "noExperienceFlag"))
		DistributeExpForKilling(%clientId);

	//The player with the killshot gets the official "kill"
	if(!IsInCommaList(fetchData(%killerId, "TempKillList"), Client::getName(%clientId)))
	storeData(%killerId, "TempKillList", AddToCommaList(fetchData(%killerId, "TempKillList"), Client::getName(%clientId)));

	if(%killerId != %clientId)
	{
		//a human player killed %clientId
		%n = Client::getName(%killerId);

		Client::sendMessage(%clientId, 0, "You were killed by " @ %n @ "!");

		//if(fetchData(%killerId, "bounty") == Client::getName(%clientId))
		//	storeData(%killerId, "bounty", fetchData(%clientId, "LVL") @ " !Q@W#E$R%T^Y&U*I(O)P");
	}
	else if(%killerId == %clientId)
	{
		Client::sendMessage(%clientId, 0, "You killed yourself!");
	}
	else if(%damageType == 11 || %damageType == 12 || %damageType == 2)
	{
		Client::sendMessage(%clientId, 0, "You were killed!");
	}

	//Check to see if the player was in a sanctioned battle
	if($Colloseum::Mode == "Seal")
	{
		if($Colloseum::Client == %clientId)
			Colloseum::EndSeal(%clientId, false);
		else if($Colloseum::Client == %killerId)
			if(Colloseum::isSealComplete())
				Colloseum::EndSeal(%killerId, true);
	}
	else if($Colloseum::Mode == "Colloseum")
	{
		if($Colloseum::Client == %clientId)
			Colloseum::roomReset(%clientId, true);
		else if($Colloseum::Client == %killerId)
			Colloseum::checkRound(%clientId, $Colloseum::Round);
	}
	else if(Duel::isDueling(%clientId) && Duel::isDueling(%killerId))
	{
		if($Duel::Challenger == Client::getName(%killerId))
			Duel::endDuel(true);
		else
			Duel::endDuel(false);
	}

	UnHide(%clientId);

	//========================================================================================================================

	echo("GAME: kill " @ %killerId @ " " @ %clientId @ " " @ %damageType);
	%clientId.guiLock = true;
	Client::setGuiMode(%clientId, $GuiModePlay);

	Game::clientKilled(%clientId, %killerId);
}

function Game::clientKilled(%playerId, %killerId)
{
	dbecho($dbechoMode, "Game::clientKilled(" @ %playerId @ ", " @ %killerId @ ")");

	%set = nameToID("MissionCleanup/ObjectivesSet");
	for(%i = 0; (%obj = Group::getObject(%set, %i)) != -1; %i++)
	GameBase::virtual(%obj, "clientKilled", %playerId, %killerId);
}

function Player::onKilled(%this)
{
	dbecho($dbechoMode, "Player::onKilled(" @ %this @ ")");

	//At this point, the client can still be queried for getItemCounts, and is also still an object
	//Player::Kill calls this function

	%clientId = Player::getClient(%this);
	%killerId = fetchData(%clientId, "tmpkillerid");
	storeData(%clientId, "tmpkillerid", "");

	//revert
	Client::setControlObject(%clientId.possessId, %clientId.possessId);
	Client::setControlObject(%clientId, %clientId);
	storeData(%clientId.possessId, "dumbAIflag", "");
	$possessedBy[%clientId.possessId] = "";

	%noDropFlag = fetchData(%clientId, "noDropLootbagFlag");
	%isJailed = %clientId.isJailed;
	%isDueling = Duel::isDueling(%clientId);
	
	if(%noDropFlag || %isJailed || %isDueling)
	{
		//do nothing
	}
	else
	{
		%tmploot = "";

		if(fetchData(%clientId, "COINS") > 0)
		%tmploot = %tmploot @ "COINS " @ floor(fetchData(%clientId, "COINS")) @ " ";
		storeData(%clientId, "COINS", 0);

		%eitem = player::getMountedItem(%clientId, $WeaponSlot);
		if(%eitem != -1 && $preventDrop[%eitem] != true)
		{
			// Always prevent dropping CastingBlade - it's AI-only
			if(%eitem == CastingBlade)
			{
				// Skip mounted weapon handling for CastingBlade
			}
			else
			{
				%isAI = RPG::isAiControlled(%clientId);
				%shouldDropWeapon = true;
				
				// For AI bots, only drop weapon with a 15% chance to prevent economy imbalance
				if(%isAI)
				{
					if(getRandom() > 0.15)
						%shouldDropWeapon = false;
				}
				
				if(%shouldDropWeapon)
			{
				if(fetchData(%clientId, "LoadedProjectile " @ %eitem) != "")
				{
					%eammo = fetchData(%clientId, "LoadedProjectile " @ %eitem);
					if((%eamnt = player::getItemCount(%clientId, %eammo)))
					{
						// For AI bots, always drop ammo if 15% chance passed (ignore LCK)
						// For players, use normal LCK logic
						if(%isAI || fetchData(%clientId, "LCK") <= 0)
						{
							if(!%isAI)
								Player::setItemCount(%clientId, %eammo, 0);
							
							%tmploot = %tmploot @ %eammo @ " " @ %eamnt @ " ";
						}
						else
							Player::setItemCount(%clientId, %eammo, %eamnt);
					}				
				}
				
				%eamnt = Player::getItemCount(%clientId, %eitem);
				// For AI bots, always drop weapon if 15% chance passed (ignore LCK)
				// For players, use normal LCK logic
				if(%isAI || fetchData(%clientId, "LCK") <= 0)
				{
					if(!%isAI)
						Player::setItemCount(%clientId, %eitem, 0);
					%tmploot = %tmploot @ %eitem @ " " @ %eamnt @ " ";
				}
				else
				{
					// When LCK > 0 (players only), only drop extras if player has more than 1
					if(%eamnt > 1)
					{
						%tmploot = %tmploot @ %eitem @ " " @ (%eamnt - 1) @ " ";
						if(!%isAI)
							Player::setItemCount(%clientId, %eitem, 1);
					}
					// If player only has 1, don't change anything - keep the weapon
				}
			}
			}
		}
		
		%max = getNumItems();
		for(%i = 0; %i < %max; %i++)
		{
			%a = getItemData(%i);
			%itemcount = Player::getItemCount(%clientId, %a);

			if(%itemcount)
			{
				// Skip the mounted weapon - it's already handled above
				if(%a == %eitem)
				{
					continue;
				}
				
				%flag = false;
				%lck = fetchData(%clientId, "LCK");

				if(%lck <= 0)
				{
					// When LCK <= 0, drop everything except protected items
					%flag = true;
					
					if($preventDrop[%a] == true)
					{
						%flag = false;
					}
					else if(%a.className == "Equipped")
					{
						%flag = false;
					}
					else if(%a.description == fetchData(%clientId, "eArmor") || %a.description == fetchData(%clientId, "eHelm"))
					{
						%flag = false;
					}
				}
				else
				{
					// When LCK > 0, only drop equipped items and lore items (mounted weapon is handled separately above)
					if(%a.className == "Equipped" || $LoreItem[%a] == True)
					{
						%flag = true;
					}
				}
				
				// Always prevent dropping CastingBlade
				if(%a == CastingBlade)
				{
					%flag = false;
				}

				if(%flag)
				{
					%b = %a;
					if(%b.className == "Equipped")
						%b = String::getSubStr(%b, 0, String::len(%b)-1);

					%tmploot = %tmploot @ %b @ " " @ Player::getItemCount(%clientId, %a) @ " ";
					
					if(!RPG::isAiControlled(%clientId))	
						Player::setItemCount(%clientId, %a, 0);
				}
			}
		}
		
		// Add belt items (quest items, key items, etc.) to loot
		%beltCategories = "QuestItems KeyItems GemItems";
		for(%catIdx = 0; (%category = getWord(%beltCategories, %catIdx)) != -1; %catIdx++)
		{
			%beltList = fetchData(%clientId, %category);
			for(%j = 0; (%beltItemName = getWord(%beltList, %j)) != -1; %j += 2)
			{
				%beltItemCount = getWord(%beltList, %j + 1);
				if(%beltItemCount > 0)
				{
					%tmploot = %tmploot @ %beltItemName @ " " @ %beltItemCount @ " ";
				}
			}
			// Clear the belt items from the dead player/bot
			storeData(%clientId, %category, "");
		}

		if(%tmploot != "")
		{
			if(RPG::isAiControlled(%clientId))
				TossLootbag(%clientId, %tmploot, 1, "*", 300);
			else
			{
				%namelist = Client::getName(%clientId) @ ",";
				if(fetchData(%clientId, "LCK") >= 0)
				{
					TossLootbag(%clientId, %tmploot, 5, %namelist, Cap(fetchData(%clientId, "LVL") * 300, 300, 3600));
				}
				else
					TossLootbag(%clientId, %tmploot, 5, %namelist, Cap(fetchData(%clientId, "LVL") * 0.2, 5, "inf"));
			}
		}
	}

	updateSpawnStuff(%clientId);

	//house stuff
	%victimH = fetchData(%clientId, "MyHouse");
	%killerH = fetchData(%killerId, "MyHouse");
	%vhn = $House::Index[%victimH];
	%khn = $House::Index[%killerH];
	if(%vhn != "")
	{
		//a house member is killed

		if(fetchData(%clientId, "LCK") < 0)
		{
			//this house member had no LCK at time of death

			if(fetchData(%clientId, "RankPoints") <= 0)
			{
				//no LCK and no Rank Points! you're booted!
				BootFromCurrentHouse(%clientId, true);
			}
			else
			Client::sendMessage(%clientId, $MsgRed, "You have lost all your Rank Points because you died with 0 LCK!");

			storeData(%clientId, "RankPoints", 0);
		}

		//victim loses two rank points
		Client::sendMessage(%clientId, $MsgWhite, "You lost 2 Rank Points.");
		storeData(%clientId, "RankPoints", 2, "dec");

		if(%khn != "")
		{
			if(%khn != %vhn)
			{
				//both contenders are in a house, different from each other
				Client::sendMessage(%killerId, $MsgWhite, "You gained 1 Rank Point!");
				storeData(%killerId, "RankPoints", 1, "inc");
			}
			else
			{
				//both contenders are in the same house, happens if one target-lists the other.
				Client::sendMessage(%killerId, $MsgWhite, "You lost 1 Rank Point.");
				storeData(%killerId, "RankPoints", 1, "dec");
			}
		}
	}
	else if(%vhn == "" && %khn != "")
	{
		//a house member killed a non-house member. no bonuses or punishments
	}
	
	if(!RPG::isAiControlled(%clientId) && fetchData(%clientId, "LCK") < 0)
		storeData(%clientId, "zone", "");
	
	%zoneType = Zone::getType(fetchData(%clientId, "zone"));
	if(%zoneType == "COLLECT" || %zoneType == "DISPLAY" || %zoneType == "CONTROL")
		storeData(%clientId, "zone", "");
	
	if(fetchData(%clientId, "deathmsg") != "")
	{
		%kitem = Player::getMountedItem(%killerId, $WeaponSlot);
		%msg = nsprintf(fetchData(%clientId, "deathmsg"), Client::getName(%killerId), Client::getName(%clientId), %kitem.description);
		remoteSay(%clientId, 0, %msg);
	}

	if(RPG::isAiControlled(%clientId))
	{
		//Check to see if it was a summoned
		if(getWord(fetchData(%clientId, "Summoner"), 0) != -1)
			Summon::Release(%clientId);
	
		//event stuff
		%i = GetEventCommandIndex(%clientId, "onkill");
		if(%i != -1)
		{
			%name = GetWord($EventCommand[%clientId, %i], 0);
			%type = GetWord($EventCommand[%clientId, %i], 1);
			%cl = NEWgetClientByName(%name);
			if(%cl == -1)
			%cl = 2048;

			%cmd = String::NEWgetSubStr($EventCommand[%clientId, %i], String::findSubStr($EventCommand[%clientId, %i], ">")+1, 99999);
			%pcmd = ParseBlockData(%cmd, %clientId, %killerid);
			$EventCommand[%clientId, %i] = "";
			schedule("remoteSay(" @ %cl @ ", 0, \"" @ %pcmd @ "\", \"" @ %name @ "\");", 2);
		}
		ClearEvents(%clientId);
	}

	storeData(%clientId, "noDropLootbagFlag", "");

	storeData(%clientId, "SpellCastStep", "");
	%clientId.sleepMode = "";
	refreshHPREGEN(%clientId);
	refreshMANAREGEN(%clientId);

	Client::setControlObject(%clientId, %clientId);
	storeData(%clientId, "dumbAIflag", "");

	//remember the last zone the player was in.
	storeData(%clientId, "lastzone", fetchData(%clientId, "zone"));

	PlaySound(RandomRaceSound(fetchData(%clientId, "RACE"), Death), GameBase::getPosition(%clientId));

	//========================================================================================================================

	%clientId.dead = 1;
	if($AutoRespawn > 0)
	schedule("Game::autoRespawn(" @ %clientId @ ");",$AutoRespawn,%clientId);

	if(fetchData(%clientId, "flashMode"))
		Player::setDamageFlash(%this, 0.75);

	if(%clientId != -1)
	{
		if(%this.vehicle != "")
		{
			if(%this.driver != "")
			{
				%this.driver = "";
				Client::setControlObject(Player::getClient(%this), %this);
				Player::setMountObject(%this, -1, 0);
			}
			else
			{
				%this.vehicle.Seat[%this.vehicleSlot-2] = "";
				%this.vehicleSlot = "";
			}
			%this.vehicle = "";
		}
		schedule("GameBase::startFadeOut(" @ %this @ ");", $CorpseTimeoutValue, %this);
		Client::setOwnedObject(%clientId, -1);
		Client::setControlObject(%clientId, Client::getObserverCamera(%clientId));
		Observer::setOrbitObject(%clientId, %this, 15, 15, 15);
		schedule("deleteObject(" @ %this @ ");", $CorpseTimeoutValue + 2.5, %this);
		%clientId.observerMode = "dead";
		%clientId.dieTime = getSimTime();
	}
}

function Player::onDamage(%this,%type,%value,%pos,%vec,%mom,%vertPos,%rweapon,%object,%weapon,%preCalcMiss)
{
	dbecho($dbechoMode, "Player::onDamage(" @ %this @ ", " @ %type @ ", " @ %value @ ", " @ %pos @ ", " @ %vec @ ", " @ %mom @ ", " @ %vertPos @ ", " @ %rweapon @ ", " @ %object @ ", " @ %weapon @ ", " @ %preCalcMiss @ ")");

	%skilltype = $SkillType[%weapon];

	if(%object != -1 && %type != $NullDamageType && !Player::IsDead(%this))
	{	
		%damagedClient = Player::getClient(%this);
		%shooterClient = %object;

		%damagedClientPos = GameBase::getPosition(%damagedClient);
		%shooterClientPos = GameBase::getPosition(%shooterClient);

		%damagedCurrentArmor = GetCurrentlyWearingArmor(%damagedClient);

		//==============
		//PROCESS STATS
		//==============
		%isMiss = false;
		%Pierce = false;
		%Bash = false;
		%Cleave = false;
		%sameTeamNull = false;

		//------------- CREATE DAMAGE VALUE -------------
		if(%type == $SpellDamageType)
		{
			//For the case of SPELLS, the initial damage has already been determined before calling this function

			%dmg = %value;
			%skillValue = $PlayerSkill[%shooterClient, %skilltype];
			if(%skillValue == "" || %skillValue == -1)
				%skillValue = 1000; // Default skill value if not set (for NPCs or edge cases)
			
			%value = round((%dmg * %skillValue) / 1000);

			%ab = (getRandom() * (fetchData(%damagedClient, "MDEF") / 10)) + 1;
			%value = Cap(%value - %ab, 0, "inf");

			%value = (%value / $TribesDamageToNumericDamage);
			
		}
		else if(%type != $LandingDamageType)
		{
			%multi = 1;

			if(fetchData(%damagedClient, "invisible"))
			{
				UnHide(%damagedClient);
			}			

			//Bash
			if(fetchData(%shooterClient, "NextHitBash"))
			{
				if(%skilltype == $SkillBludgeoning)
				{
					%multi += $PlayerSkill[%shooterClient, $SkillCombat] / 470;
					%b = GameBase::getRotation(%shooterClient);
					%c = $PlayerSkill[%shooterClient, $SkillCombat] / 15;
					%Bash = true;
				}

				%delay = Cap(360 - ($PlayerSkill[%shooterClient, $SkillCombat] / 100), 30, 360);
				schedule("storeData(" @ %shooterClient @ ", \"blockBash\", \"\");", %delay);
				storeData(%shooterClient, "NextHitBash", "");
			}
	
			//Pierce
			if(fetchData(%shooterClient, "NextHitPierce"))
			{
				if(%skilltype == $SkillPiercing)
				{
					%multi += $PlayerSkill[%shooterClient, $SkillCombat] / 175;
					%Pierce = true;
				}
				
				%delay = Cap(360 - ($PlayerSkill[%shooterClient, $SkillCombat] / 100), 30, 360);
				schedule("storeData(" @ %shooterClient @ ", \"blockPierce\", \"\");", %delay);
				storeData(%shooterClient, "NextHitPierce", "");				
			}
			
			//Cleave
			if(fetchData(%shooterClient, "NextHitCleave"))
			{
				if(%skilltype == $SkillSlashing)
				{
					%multi += $PlayerSkill[%shooterClient, $SkillCombat] / 940;
					%Cleave = true;
				}

				%delay = Cap(360 - ($PlayerSkill[%shooterClient, $SkillCombat] / 100), 30, 360);
				schedule("storeData(" @ %shooterClient @ ", \"blockCleave\", \"\");", %delay);
				storeData(%shooterClient, "NextHitCleave", "");
			}			

			if(%rweapon != "")
				%rweapondamage = GetRoll(GetWord(GetAccessoryVar(%rweapon, $SpecialVar), 1));
			else
				%rweapondamage = 0;
			%weapondamage = GetRoll(GetWord(GetAccessoryVar(%weapon, $SpecialVar), 1));

			%playerattack = fetchData(%shooterClient, "ATK") - %weapondamage;
			%skillValue = $PlayerSkill[%shooterClient, %skilltype];
			if(%skillValue == "" || %skillValue == -1)
				%skillValue = 1000; // Default skill value if not set (for NPCs or edge cases)
			%value = round((( (%weapondamage + (%playerattack + %rweapondamage)) / 1000) * %skillValue) * %multi);

			%ab = (getRandom() * (fetchData(%damagedClient, "DEF") / 10)) + 1;
			%value = Cap(%value - %ab, 1, "inf");

			%a = (%value * 0.15);
			%r = round((getRandom() * (%a*2)) - %a);
			%value += %r;
			if(%value < 1)
			%value = 1;

			if(%Bash)	//i'm doing this condition here because %mom is dependant on %value
			{
				%c1 = ( %c / 15 * %value );
				%c2 = %c2 / 10;
				%mom = Vector::getFromRot( %b, %c1, %c2 );
			}

			%value = (%value / $TribesDamageToNumericDamage);
		}

		//------------- DETERMINE MISS OR HIT -------------
		if(%preCalcMiss == "")
		{
			if(%type != $LandingDamageType && %shooterClient != %damagedClient && %shooterClient != 0)
			{
				if(%type == $SpellDamageType)
				%x = (fetchData(%damagedClient, "MDEF") / 5) + $PlayerSkill[%damagedClient, $SkillSpellResistance] + 5;
				else
				%x = (fetchData(%damagedClient, "DEF") / 5) + $PlayerSkill[%damagedClient, $SkillDodging] + 5;
				%y = $PlayerSkill[%shooterClient, %skilltype] + 5;
				
				%n = %x + %y;
				
				%r = floor(getRandom() * %n) + 1;
				
				if(%r <= %x)
					%isMiss = true;
				else if(getRandom() <= (AddPoints(%damagedClient, 2) / 100))
					%isMiss = true;
			}
		}
		//------------- CHECK FOR A CRITICAL HIT -------------
		if(getRandom() > 0.5)
		{
			%norm = 1.000;
			%critskill = $PlayerSkill[%shooterClient, $SkillCriticals] / 3000;
			%critchance = %norm - %critskill;
			%critchance -= (AddPoints(%shooterClient, 1) / 100);
			if(%critchance < 0.1)
				%critchance = 0.1;
			if(getRandom() > %critchance)
				%criticalAttack = true;
		}
		
		//=======================================|WATER CHECKS|=========================================
		//------------------------------------
		// CHECK IF PLAYER LANDED ON WATER
		//------------------------------------
		if(%damagedClient == %shooterClient && %type == $LandingDamageType)
		{
			%object = "";
			for(%i = 0; %i >= -3.15; %i -= 1.57)
			{
				if(GameBase::getLOSInfo(Client::getOwnedObject(%damagedClient), 5, %i @ " 0 0"))
				{
					if(getObjectType($los::object) == "InteriorShape" && String::getSubStr(Object::getName($los::object), 0, 5) == "water")
					{
						%object = $los::object;
						break;
					}
				}
			}
			
			if(%object != "")
			{
				%value *= $waterDamageAmp;
				playSound(SoundSplash1, %damagedClientPos);
			}
		}

		//---------------------------------------
		// CHECK IF PLAYER LANDED WHILE IN WATER
		//---------------------------------------
		if(%damagedClient == %shooterClient && %type == $LandingDamageType)
		{
			if(Zone::getType(fetchData(%damagedClient, "zone")) == "WATER")
			%value *= $waterDamageAmp;
		}
		else if(%damagedClient != %shooterClient && %type == $LandingDamageType)
			%value = (fetchData(%damagedClient, "MaxHP") * (%value / 100) / 100);
		//============================================================================================

		//------------------------------------------------
		// SAME TEAM CHECKS
		//------------------------------------------------
		// AI mobs can always attack players, skip all same-team checks for AI attackers
		if(!Duel::isDueling(%damagedClient) && !Duel::isDueling(%shooterClient) && !RPG::isAiControlled(%shooterClient))
		{
			if(Client::getTeam(%damagedClient) == Client::getTeam(%shooterClient) && %shooterClient != %damagedClient)
			{
				if(!HasTheftFlag(%damagedClient))
				{
					if(Zone::getType(fetchData(%damagedClient, "zone")) == "PROTECTED" && Zone::getType(fetchData(%shooterClient, "zone")) != "PROTECTED")
					{
						%value = 0;
						%isMiss = false;
						%noImpulse = true;
						%sameTeamNull = true;
					}
					else if(Zone::getType(fetchData(%damagedClient, "zone")) == "PROTECTED" && Zone::getType(fetchData(%shooterClient, "zone")) == "PROTECTED")
					{
						%value = 0;
						%isMiss = false;
						%noImpulse = true;
						%sameTeamNull = true;
					}
					
					///no target-list involved
					if(!(IsInCommaList(fetchData(%damagedClient, "targetlist"), Client::getName(%shooterClient)) || IsInCommaList(fetchData(%shooterClient, "targetlist"), Client::getName(%damagedClient))) )
					{	
						%dhn = $House::Index[fetchData(%damagedClient, "MyHouse")];
						%shn = $House::Index[fetchData(%shooterClient, "MyHouse")];
						if(%dhn == %shn)
						{
							%value = 0;
							%isMiss = false;
							%noImpulse = true;
							%sameTeamNull = true;
						}
						else
						{
							if(%dhn == "" || %shn == "")
							{
								//one of the people involved is not in a house, so no damage occurs
								%value = 0;
								%isMiss = false;
								%noImpulse = true;
								%sameTeamNull = true;
							}
						}
					}

					if(Zone::getType(fetchData(%damagedClient, "zone")) != "PROTECTED" && Zone::getType(fetchData(%shooterClient, "zone")) != "PROTECTED")
					{
						if(fetchData(%damagedClient, "partyOwned"))
						{
							if(IsInCommaList(fetchData(%damagedClient, "partylist"), Client::getName(%shooterClient)))
							{
								%value = 0;
								%isMiss = false;
								%noImpulse = true;
								%sameTeamNull = true;
							}
						}
						else if(fetchData(%shooterClient, "partyOwned"))
						{
							if(IsInCommaList(fetchData(%shooterClient, "partylist"), Client::getName(%damagedClient)))
							{
								%value = 0;
								%isMiss = false;
								%noImpulse = true;
								%sameTeamNull = true;
							}
						}
					}
				}
				else
				{
					//one of the people involved has the other one on his/her target-list.
					//so let damage go thru
				}
			}
		}
		//-------------------------------------------------
		// SAME PLAYER CHECKS
		//-------------------------------------------------
		if(%damagedClient == %shooterClient)
		{
			if(RPG::isAiControlled(%damagedClient))
				%value = 0;
			else if(Zone::getType(fetchData(%damagedClient, "zone")) == "PROTECTED")
				%value = 0;
			else if(%type == $SpellDamageType)
				%value = %value / 3;
		}

		if(!IsDead(%this))
		{
			%armor = Player::getArmor(%this);
			storeData(%damagedClient, "tmpkillerid", %shooterClient);

			%hitby = Client::getName(%shooterClient);
			%msgcolor = "";

			if(%isMiss)
			{
				%msgcolor = $MsgRed;
				%value = 0;
			}
			else if(!%isMiss && %value == 0 && %shooterClient != %damagedClient)
			{
				%msgcolor = $MsgWhite;
			}
			if(%msgcolor != "")
			{
				// Default damageMode to true if not set (for backwards compatibility)
				%shooterDamageMode = fetchData(%shooterClient, "damageMode");
				if(%shooterDamageMode == "")
					%shooterDamageMode = true;
				%damagedDamageMode = fetchData(%damagedClient, "damageMode");
				if(%damagedDamageMode == "")
					%damagedDamageMode = true;
				
				%isAI = RPG::isAiControlled(%shooterClient);
				
				if(%type != $SpellDamageType)
				{
					// Only send message to shooter if they're a player (not AI)
					if(!%isAI && %shooterDamageMode)
						Client::sendMessage(%shooterClient, %msgcolor, "You try to hit " @ Client::getName(%damagedClient) @ ", but miss!");

					// Always send miss message to damaged player
					if(%damagedDamageMode)
					{
						%time = getIntegerTime(true) >> 5;
						if(%time - %damagedClient.lastMissMessage > 2)
						{
							%damagedClient.lastMissMessage = %time;
							Client::sendMessage(%damagedClient, %msgcolor, %hitby @ " tries to hit you, but misses!");
						}
					}
				}
				else
				{
					// Only send message to shooter if they're a player (not AI)
					if(!%isAI && %shooterDamageMode)
						Client::sendMessage(%shooterClient, %msgcolor, Client::getName(%damagedClient) @ " resists your spell!");
					if(%damagedDamageMode)
						Client::sendMessage(%damagedClient, %msgcolor, "You resist " @ %hitby @ "'s spell!");
				}
			}

			//-------------------------------------------------
			// SKILLS
			//-------------------------------------------------
			if(%skilltype >= 1 && !%sameTeamNull && %shooterClient != %damagedClient)
			{
				%base1 = Cap(35 + (fetchData(%shooterClient, "LVL") - fetchData(%damagedClient, "LVL")), 1, "inf");
				%base2 = Cap(35 + (fetchData(%damagedClient, "LVL") - fetchData(%shooterClient, "LVL")), 1, "inf");
				if(%isMiss)
				{
					UseSkill(%shooterClient, %skilltype, false, true);
					UseSkill(%damagedClient, $SkillEndurance, false, true, 60);
					
					if(%type == $SpellDamageType)
						UseSkill(%damagedClient, $SkillSpellResistance, true, true, %base2);
					else
						UseSkill(%damagedClient, $SkillDodging, true, true, %base2 * (3/5));
				}
				else if(!%isMiss && %value == 0)
				{
					UseSkill(%shooterClient, %skilltype, false, true);
					UseSkill(%damagedClient, $SkillEndurance, false, true, 60);
					
					if(%type == $SpellDamageType)
						UseSkill(%damagedClient, $SkillSpellResistance, true, true, %base2);
					else
						UseSkill(%damagedClient, $SkillDodging, true, true, %base2 * (3/5));
				}
				else
				{
					UseSkill(%shooterClient, %skilltype, true, true, %base1);
					UseSkill(%damagedClient, $SkillEndurance, true, true, 60);

					if(%type == $SpellDamageType)
						UseSkill(%damagedClient, $SkillSpellResistance, true, true, %base2);
				}

				if(%Bash || %Cleave || %Pierce)
					UseSkill(%shooterClient, $SkillCombat, true, true);
			}

			// Ensure %value is numeric before processing
			if(%value == "" || %value == -1)
				%value = 0;
			
			if(%value)
			{
				if(%value < 0)
					%value = 0;
				if(%criticalAttack)
					%value *= 2;
				
				// Offensive stance: doubles damage dealt and received (all damage types, including spells)
				if(fetchData(%shooterClient, "Stance") == "Offensive")
					%value *= 2;
				if(fetchData(%damagedClient, "Stance") == "Offensive")
					%value *= 2;
				
				// Defensive stance: halves damage dealt and received (all damage types)
				if(fetchData(%shooterClient, "Stance") == "Defensive")
					%value /= 2;
				if(fetchData(%damagedClient, "Stance") == "Defensive")
					%value /= 2;
				
				// Glass Cannon stance: 2.5x spell damage dealt, -50% max HP and -50% max mana (handled in rpgstats.cs)
				if(fetchData(%shooterClient, "Stance") == "Glass Cannon" && %type == $SpellDamageType)
					%value *= 2.5;

				// MageBane: nullifies magic damage received, doubles physical damage received
				if(fetchData(%damagedClient, "MANA") > 0)
				{
					if(%type == $SpellDamageType && fetchData(%damagedClient, "Stance") == "MageBane") 
						%value = 0;
					if(%type != $SpellDamageType && fetchData(%damagedClient, "Stance") == "MageBane")
						%value *= 2;
				}
				
				// BladeBane: nullifies physical damage received, doubles magic damage received
				if(fetchData(%damagedClient, "MANA") > 0)
				{
					if(%type != $SpellDamageType && fetchData(%damagedClient, "Stance") == "BladeBane")
						%value = 0;
					if(%type == $SpellDamageType && fetchData(%damagedClient, "Stance") == "BladeBane")
						%value *= 2;
				}
				
				// Ensure value doesn't become 0 or negative after stance modifiers
				if(%value < 0)
					%value = 0;						
				
				if(%Pierce)
				{
					//Not really any way to code this using a player's skill that won't
					// end up being too powerful at one point (ultimate pk anyone?)
					// instead let's just go with a 5% chance!

					//%regular = 1.0;
					//%chance = $PlayerSkill[%shooterClient, $SkillCombat] / 50000;
					//%special = %regular - %chance;
				
					//if(%special < 0.5)
					//	%special = 0.5;

					//if(getRandom() > %special)
					if(getRandom() > 0.95)
						$lckBypass[%damagedClient] = true;
				}
				
				%backupValue = %value;

				%rhp = refreshHP(%damagedClient, %value);

				%lckMiss = false;
				if(%rhp == -1)
				{
					%value = -1;	//There was an LCK miss
					%lckMiss = true;
				}
				else
				{
					if(!%noImpulse) Player::applyImpulse(%this,%mom);
						%noImpulse = "";

					if(%damagedCurrentArmor != "")
						%ahs = $ArmorHitSound[%damagedCurrentArmor];
					else
						%ahs = SoundHitFlesh;
					if(%skilltype == $SkillSlashing)
						PlaySound(%ahs, %damagedClientPos);
					else if(%skilltype == $SkillBludgeoning)
						PlaySound(%ahs, %damagedClientPos);
					else if(%skilltype == $SkillPiercing)
						PlaySound(%ahs, %damagedClientPos);
					else if(%skilltype == $SkillArchery)
						PlaySound(SoundArrowHit2, %damagedClientPos);
				}

				if(RPG::isAiControlled(%damagedClient) && fetchData(%damagedClient, "SpawnBotInfo") != "")
				{
					if(!IsDead(%damagedClient))
					{
						if(AI::getTarget(fetchData(%damagedClient, "BotInfoAiName")) != %shooterClient)
							AI::SelectMovement(fetchData(%damagedClient, "BotInfoAiName"));
					}

					PlaySound(RandomRaceSound(fetchData(%damagedClient, "RACE"), Hit), %damagedClientPos);
				}

			//display amount of damage caused
			// Check for LCK miss first before converting -1 to 0
			if(%lckMiss)
			{
				// Handle LCK miss message (this will be handled in the else if block below)
				%convValue = -1; // Keep as -1 to trigger LCK miss message
			}
			else
			{
				if(%value == "" || %value == -1)
					%value = 0;
				%convValue = round(%value * $TribesDamageToNumericDamage);
			}

				if(%convValue > 0)
				{
					if(%shooterClient == %damagedClient)
					{
						if(%type == $CrushDamageType)
							%hitby = "moving object";
						else if(%type == $DebrisDamageType)
							%hitby = "debris";
						else if(%type == $SpellDamageType)
							%hitby = "your " @ $Spell::name[$Spell::index[%weapon]];
						else
							%hitby = "yourself";
					}
					else if(%shooterClient == 0)
					{
						if(%type == $SpellDamageType && %weapon != "")
						{
							%spellIndex = $Spell::index[%weapon];
							if(%spellIndex != "")
								%hitby = $Spell::name[%spellIndex];
							else
							{
								echo("DEBUG: Spell index not found for weapon='" @ %weapon @ "'");
								%hitby = "a powerful force";
							}
						}
						else
							%hitby = "a powerful force";
					}
					else
					{
						if(fetchData(%shooterClient, "invisible"))
							%hitby = "an unknown assailant";
						else if(%type == $SpellDamageType && %weapon != "")
						{
							%spellIndex = $Spell::index[%weapon];
							if(%spellIndex != "")
								%hitby = Client::getName(%shooterClient) @ "'s " @ $Spell::name[%spellIndex];
							else
							{
								echo("DEBUG: Spell index not found for weapon='" @ %weapon @ "', shooter=" @ %shooterClient);
								%hitby = Client::getName(%shooterClient);
							}
						}
						else
							%hitby = Client::getName(%shooterClient);
					}

					if(%Pierce)
					{
						%daction = "pierced";
						%saction = "pierced";
					}
					else if(%Bash)
					{
						%daction = "bashed";
						%saction = "bashed";
					}
					else if(%Cleave)
					{
						%daction = "cleaved";
						%saction = "cleaved";
					}					
					else
					{
						%daction = "damaged";
						%saction = "damaged";
					}

					//--------------------
					//display to involved
					//--------------------
					// Default damageMode to true if not set (for backwards compatibility)
					%shooterDamageMode = fetchData(%shooterClient, "damageMode");
					if(%shooterDamageMode == "")
						%shooterDamageMode = true;
					%damagedDamageMode = fetchData(%damagedClient, "damageMode");
					if(%damagedDamageMode == "")
						%damagedDamageMode = true;
					
					if(%shooterClient != %damagedClient)
						if(%shooterDamageMode)
						{
							%spellName = "";
							if(%type == $SpellDamageType && %weapon != "")
							{
								%spellIndex = $Spell::index[%weapon];
								if(%spellIndex != "")
									%spellName = " with " @ $Spell::name[%spellIndex];
							}
							if(%criticalAttack)
								Client::sendMessage(%shooterClient, $MsgRed, "You critically " @ %saction @ " " @ Client::getName(%damagedClient) @ %spellName @ " for " @ %convValue @ " points of damage!");
							else
								Client::sendMessage(%shooterClient, $MsgRed, "You " @ %saction @ " " @ Client::getName(%damagedClient) @ %spellName @ " for " @ %convValue @ " points of damage!");
						}
					
					if(%damagedDamageMode)
						if(%criticalAttack)
							Client::sendMessage(%damagedClient, $MsgRed, "You were critically " @ %daction @ " by " @ %hitby @ " for " @ %convValue @ " points of damage!");
						else
							Client::sendMessage(%damagedClient, $MsgRed, "You were " @ %daction @ " by " @ %hitby @ " for " @ %convValue @ " points of damage!");

					//--------------------
					//display to radius
					//--------------------
					if(%shooterClient == 0)
					{
						if(%type == $SpellDamageType && %weapon != "")
						{
							%spellIndex = $Spell::index[%weapon];
							if(%spellIndex != "")
								%sname = $Spell::name[%spellIndex];
							else
							{
								echo("DEBUG: Spell index not found for weapon='" @ %weapon @ "' in radius message");
								%sname = "A powerful force";
							}
						}
						else
							%sname = "A powerful force";
						%dname = Client::getName(%damagedClient);
					}
					else if(%shooterClient == %damagedClient)
					{
						%sname = Client::getName(%shooterClient);
						if(String::ICompare(Client::getGender(%damagedClient), "Male") == 0)
							%dname = "himself";
						else if(String::ICompare(Client::getGender(%damagedClient), "Female") == 0)
							%dname = "herself";
						else
							%dname = "itself";
					}
					else
					{
						if(fetchData(%shooterClient, "invisible"))
							%sname = "An unknown assailant";
						else if(%type == $SpellDamageType && %weapon != "")
						{
							%spellIndex = $Spell::index[%weapon];
							if(%spellIndex != "")
								%sname = Client::getName(%shooterClient) @ "'s " @ $Spell::name[%spellIndex];
							else
							{
								echo("DEBUG: Spell index not found for weapon='" @ %weapon @ "' in radius message, shooter=" @ %shooterClient);
								%sname = Client::getName(%shooterClient);
							}
						}
						else
							%sname = Client::getName(%shooterClient);
						
						%dname = Client::getName(%damagedClient);
					}

					if(%criticalAttack)
						radiusAllExcept(%damagedClient, %shooterClient, %sname @ " critically hits " @ %dname @ " for " @ %convValue @ " points of damage!");
					else
						radiusAllExcept(%damagedClient, %shooterClient, %sname @ " hits " @ %dname @ " for " @ %convValue @ " points of damage!");
				}
				else if(%convValue < 0)
				{
					//this happens when there's a LCK consequence as miss

					if(%shooterClient == 0)
					{
						if(%type == $SpellDamageType && %weapon != "")
							%hitby = $Spell::name[$Spell::index[%weapon]];
						else
							%hitby = "A powerful force";
					}
					else
					{
						if(%type == $SpellDamageType && %weapon != "")
							%hitby = Client::getName(%shooterClient) @ "'s " @ $Spell::name[$Spell::index[%weapon]];
						else
							%hitby = Client::getName(%shooterClient);
					}

					// Default damageMode to true if not set (for backwards compatibility)
					%shooterDamageMode = fetchData(%shooterClient, "damageMode");
					if(%shooterDamageMode == "")
						%shooterDamageMode = true;
					%damagedDamageMode = fetchData(%damagedClient, "damageMode");
					if(%damagedDamageMode == "")
						%damagedDamageMode = true;
					
					if(%shooterDamageMode)
						Client::sendMessage(%shooterClient, $MsgRed, "You try to hit " @ Client::getName(%damagedClient) @ ", but miss! (LCK)");
					if(%damagedDamageMode)
						Client::sendMessage(%damagedClient, $MsgRed, %hitby @ " tries to hit you, but misses! (LCK)");
				}

				//-------------------------------------------
				//add entry to damagedClient's damagedBy list
				//-------------------------------------------

				//make new entry with shooter's name
				if( %shooterClient != 0 && !%isMiss)
				{
					if(%shooterClient == 0)
						%sname = "A powerful force";
					else
						%sname = Client::getName(%shooterClient);

					%dname = Client::getName(%damagedClient);
					if(%shooterClient != %damagedClient)
					{
						%index = "";
						for(%i = 1; %i <= $maxDamagedBy; %i++)
						{
							if($damagedBy[%dname, %i] == "" && %index == "")
							%index = %i;
						}
						if(%index != "")
						{
							$damagedBy[%dname, %index] = %sname @ " " @ %backupValue;
							schedule("$damagedBy[\"" @ %dname @ "\", " @ %index @ "] = \"\";", $damagedByEraseDelay);
						}
						else
						{
							//too many hits on waiting list, he doesn't get in on exp.
						}
					}
				}

				if(fetchData(%damagedClient, "flashMode"))
				{
					%flash = Player::getDamageFlash(%this) + %value * 2;
					if(%flash > 0.75)
						%flash = 0.75;
					Player::setDamageFlash(%this,%flash);
				}

				//If player not dead then play a random hurt sound
				if(!Player::IsDead(%this))
				{
					if(%damagedClient.lastDamage < getSimTime())
					{
						%sound = radnomItems(3,injure1,injure2,injure3);
						playVoice(%damagedClient,%sound);
						%damagedClient.lastdamage = getSimTime() + 1.5;
					}
				}
				else		//player died
				{
					if(RPG::isAiControlled(%shooterClient))
					{
						RemotePlayAnim(%shooterClient, 8);
						PlaySound(RandomRaceSound(fetchData(%shooterClient, "RACE"), Taunt), %shooterClientPos);
					}

					if( Player::isCrouching(%this) )
					%curDie = $PlayerAnim::Crouching;
					else
					%curDie = radnomItems(3, $PlayerAnim::DieLeftSide, $PlayerAnim::DieChest, $PlayerAnim::DieForwardKneel);

					Player::setAnimation(%this, %curDie);

					if(%type == $ImpactDamageType && %object.clLastMount != "")
					%shooterClient = %object.clLastMount;

					Client::onKilled(%damagedClient, %shooterClient, %type);
				}
			}

			if(%isMiss)
			{
				if(fetchData(%damagedClient, "isBonused"))
				{
					GameBase::activateShield(%this, "0 0 1.57", 1.47);
					PlaySound(SoundHitShield, %damagedClientPos);
				}
			}
		}
	}
}

function remoteKill(%clientId)
{
	dbecho($dbechoMode, "remoteKill(" @ %clientId @ ")");

	if(!$matchStarted)
		return;
	if(%clientId.isJailed || Duel::isDueling(%clientId))
		return;
	
	%player = Client::getOwnedObject(%clientId);
	if(%player != -1 && getObjectType(%player) == "Player" && !IsDead(%clientId))
	{
		storeData(%clientId, "LCK", 1, "dec");

		if(fetchData(%clientId, "LCK") >= 0)
			Client::sendMessage(%clientId, $MsgRed, "You have permanently lost an LCK point!");

		playNextAnim(%clientId);
		Player::kill(%clientId);
	}
}