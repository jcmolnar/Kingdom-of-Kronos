$Belt::Count["QuestItems"] = 0;
$Belt::Count["KeyItems"] = 0;
$Belt::Count["Deployables"] = 0;
$Belt::Count["Consumables"] = 0;
$Belt::Count["Armor"] = 0;
$Belt::Count["Accessories"] = 0;
$Belt::Count["Other"] = 0;

$Belt::Categories[1] = "QuestItems";
$Belt::Categories[2] = "KeyItems";
$Belt::Categories[3] = "Deployables";
$Belt::Categories[4] = "Consumables";
$Belt::Categories[5] = "Armor";
$Belt::Categories[6] = "Accessories";
$Belt::Categories[7] = "Other";

// Alias function for backward compatibility - code may still reference isBackpackItem
function isBackpackItem(%item)
{
	return isBeltItem(%item);
}

function Belt::BankStorageConversion(%clientId)
{
	// Use BeltStorage as single source of truth, derive separate categories from it for backwards compatibility
	// On character load, ALWAYS rebuild BeltStorage from loaded stored categories to ensure sync
	// This ensures BeltStorage matches what was saved in funk::var fields 38, 39, 42, 43, 45, 46
	
	// First, get the loaded stored categories (these were loaded from funk::var in rpgfunk.cs)
	%storedQuest = fetchData(%clientId, "StoredQuestItems");
	%storedKey = fetchData(%clientId, "StoredKeyItems");
	%storedConsumables = fetchData(%clientId, "StoredConsumables");
	%storedArmor = fetchData(%clientId, "StoredArmor");
	%storedAccessories = fetchData(%clientId, "StoredAccessories");
	%storedOther = fetchData(%clientId, "StoredOther");
	
	//echo("DEBUG Belt::BankStorageConversion: Loaded categories - Quest='" @ %storedQuest @ "', Key='" @ %storedKey @ "', Consumables='" @ %storedConsumables @ "'");
	
	// Normalize "0" to empty string
	if(%storedQuest == "0" || %storedQuest == " ")
		%storedQuest = "";
	if(%storedKey == "0" || %storedKey == " ")
		%storedKey = "";
	if(%storedConsumables == "0" || %storedConsumables == " ")
		%storedConsumables = "";
	if(%storedArmor == "0" || %storedArmor == " ")
		%storedArmor = "";
	if(%storedAccessories == "0" || %storedAccessories == " ")
		%storedAccessories = "";
	if(%storedOther == "0" || %storedOther == " ")
		%storedOther = "";
	
	// Clean and combine separate categories into BeltStorage
	%cleanedQuest = "";
	%removedQuest = 0;
	for(%i = 0; GetWord(%storedQuest, %i) != -1; %i += 2)
	{
		%item = GetWord(%storedQuest, %i);
		%count = GetWord(%storedQuest, %i + 1);
		// Convert count to numeric to properly handle negative values like "-1" or "-0"
		%countNum = %count * 1;
		if(%item != "" && %item != -1 && %item != "0" && %count != "" && %count != -1 && %count != "-1" && %count != "0" && %countNum > 0)
		{
			%cleanedQuest = %cleanedQuest @ %item @ " " @ %count @ " ";
		}
		else
		{
			%removedQuest++;
		}
	}
	// Remove trailing space and update if cleaned
	if(%cleanedQuest != %storedQuest)
	{
		%len = String::len(%cleanedQuest);
		if(%len > 0 && String::getSubStr(%cleanedQuest, %len-1, 1) == " ")
			%cleanedQuest = String::getSubStr(%cleanedQuest, 0, %len-1);
		storeData(%clientId, "StoredQuestItems", %cleanedQuest);
		%storedQuest = %cleanedQuest;
	}
	
	// Clean up invalid entries from StoredKeyItems
	%cleanedKey = "";
	%removedKey = 0;
	for(%i = 0; GetWord(%storedKey, %i) != -1; %i += 2)
	{
		%item = GetWord(%storedKey, %i);
		%count = GetWord(%storedKey, %i + 1);
		// Convert count to numeric to properly handle negative values like "-1" or "-0"
		%countNum = %count * 1;
		if(%item != "" && %item != -1 && %item != "0" && %count != "" && %count != -1 && %count != "-1" && %count != "0" && %countNum > 0)
		{
			%cleanedKey = %cleanedKey @ %item @ " " @ %count @ " ";
		}
		else
		{
			%removedKey++;
		}
	}
	// Remove trailing space and update if cleaned
	if(%cleanedKey != %storedKey)
	{
		%len = String::len(%cleanedKey);
		if(%len > 0 && String::getSubStr(%cleanedKey, %len-1, 1) == " ")
			%cleanedKey = String::getSubStr(%cleanedKey, 0, %len-1);
		storeData(%clientId, "StoredKeyItems", %cleanedKey);
		%storedKey = %cleanedKey;
	}
	
	// Clean up invalid entries from StoredConsumables
	%cleanedConsumables = "";
	%removedConsumables = 0;
	for(%i = 0; GetWord(%storedConsumables, %i) != -1; %i += 2)
	{
		%item = GetWord(%storedConsumables, %i);
		%count = GetWord(%storedConsumables, %i + 1);
		// Convert count to numeric to properly handle negative values like "-1" or "-0"
		%countNum = %count * 1;
		if(%item != "" && %item != -1 && %item != "0" && %count != "" && %count != -1 && %count != "-1" && %count != "0" && %countNum > 0)
		{
			%cleanedConsumables = %cleanedConsumables @ %item @ " " @ %count @ " ";
		}
		else
		{
			%removedConsumables++;
		}
	}
	// Remove trailing space and update if cleaned
	if(%cleanedConsumables != %storedConsumables)
	{
		%len = String::len(%cleanedConsumables);
		if(%len > 0 && String::getSubStr(%cleanedConsumables, %len-1, 1) == " ")
			%cleanedConsumables = String::getSubStr(%cleanedConsumables, 0, %len-1);
		storeData(%clientId, "StoredConsumables", %cleanedConsumables);
		%storedConsumables = %cleanedConsumables;
	}
	
	// Clean up invalid entries from StoredArmor
	%cleanedArmor = "";
	%removedArmor = 0;
	for(%i = 0; GetWord(%storedArmor, %i) != -1; %i += 2)
	{
		%item = GetWord(%storedArmor, %i);
		%count = GetWord(%storedArmor, %i + 1);
		// Convert count to numeric to properly handle negative values like "-1" or "-0"
		%countNum = %count * 1;
		if(%item != "" && %item != -1 && %item != "0" && %count != "" && %count != -1 && %count != "-1" && %count != "0" && %countNum > 0)
		{
			%cleanedArmor = %cleanedArmor @ %item @ " " @ %count @ " ";
		}
		else
		{
			%removedArmor++;
			}
		}
		// Remove trailing space and update if cleaned
	if(%cleanedArmor != %storedArmor)
	{
		%len = String::len(%cleanedArmor);
		if(%len > 0 && String::getSubStr(%cleanedArmor, %len-1, 1) == " ")
			%cleanedArmor = String::getSubStr(%cleanedArmor, 0, %len-1);
		storeData(%clientId, "StoredArmor", %cleanedArmor);
		%storedArmor = %cleanedArmor;
	}
	
	// Clean up invalid entries from StoredAccessories
	%cleanedAccessories = "";
	%removedAccessories = 0;
	for(%i = 0; GetWord(%storedAccessories, %i) != -1; %i += 2)
	{
		%item = GetWord(%storedAccessories, %i);
		%count = GetWord(%storedAccessories, %i + 1);
		// Convert count to numeric to properly handle negative values like "-1" or "-0"
		%countNum = %count * 1;
		if(%item != "" && %item != -1 && %item != "0" && %count != "" && %count != -1 && %count != "-1" && %count != "0" && %countNum > 0)
		{
			%cleanedAccessories = %cleanedAccessories @ %item @ " " @ %count @ " ";
		}
		else
		{
			%removedAccessories++;
		}
	}
	// Remove trailing space and update if cleaned
	if(%cleanedAccessories != %storedAccessories)
	{
		%len = String::len(%cleanedAccessories);
		if(%len > 0 && String::getSubStr(%cleanedAccessories, %len-1, 1) == " ")
			%cleanedAccessories = String::getSubStr(%cleanedAccessories, 0, %len-1);
		storeData(%clientId, "StoredAccessories", %cleanedAccessories);
		%storedAccessories = %cleanedAccessories;
	}
	
	// Clean up invalid entries from StoredOther
	%cleanedOther = "";
	%removedOther = 0;
	for(%i = 0; GetWord(%storedOther, %i) != -1; %i += 2)
	{
		%item = GetWord(%storedOther, %i);
		%count = GetWord(%storedOther, %i + 1);
		// Convert count to numeric to properly handle negative values like "-1" or "-0"
		%countNum = %count * 1;
		if(%item != "" && %item != -1 && %item != "0" && %count != "" && %count != -1 && %count != "-1" && %count != "0" && %countNum > 0)
		{
			%cleanedOther = %cleanedOther @ %item @ " " @ %count @ " ";
		}
		else
		{
			%removedOther++;
		}
	}
	// Remove trailing space and update if cleaned
	if(%cleanedOther != %storedOther)
	{
		%len = String::len(%cleanedOther);
		if(%len > 0 && String::getSubStr(%cleanedOther, %len-1, 1) == " ")
			%cleanedOther = String::getSubStr(%cleanedOther, 0, %len-1);
		storeData(%clientId, "StoredOther", %cleanedOther);
		%storedOther = %cleanedOther;
	}
	
		// Combine StoredQuestItems, StoredKeyItems, StoredConsumables, StoredArmor, StoredAccessories, and StoredOther into BeltStorage
		%beltStorage = "";
		if(%storedQuest != "")
			%beltStorage = %storedQuest;
		if(%storedKey != "")
		{
			if(%beltStorage != "")
				%beltStorage = %beltStorage @ " " @ %storedKey;
			else
				%beltStorage = %storedKey;
		}
		if(%storedConsumables != "")
		{
			if(%beltStorage != "")
				%beltStorage = %beltStorage @ " " @ %storedConsumables;
			else
				%beltStorage = %storedConsumables;
		}
		if(%storedArmor != "")
		{
			if(%beltStorage != "")
				%beltStorage = %beltStorage @ " " @ %storedArmor;
			else
				%beltStorage = %storedArmor;
		}
		if(%storedAccessories != "")
		{
			if(%beltStorage != "")
				%beltStorage = %beltStorage @ " " @ %storedAccessories;
			else
				%beltStorage = %storedAccessories;
		}
		if(%storedOther != "")
		{
			if(%beltStorage != "")
				%beltStorage = %beltStorage @ " " @ %storedOther;
			else
				%beltStorage = %storedOther;
		}
		
		// Final cleanup pass on BeltStorage to remove any invalid entries (item "0", count 0, etc.)
		// This prevents "0 0" entries from persisting in BeltStorage
		%finalCleaned = "";
		for(%i = 0; GetWord(%beltStorage, %i) != -1; %i += 2)
		{
			%item = GetWord(%beltStorage, %i);
			%count = GetWord(%beltStorage, %i + 1);
			// Convert count to numeric to properly handle negative values like "-1" or "-0"
			%countNum = %count * 1;
			if(%item != "" && %item != -1 && %item != "0" && %count != "" && %count != -1 && %count != "-1" && %count != "0" && %countNum > 0)
			{
				%finalCleaned = %finalCleaned @ %item @ " " @ %count @ " ";
			}
		}
	// Remove trailing space if present
	if(%finalCleaned != "")
	{
		%len = String::len(%finalCleaned);
		if(%len > 0 && String::getSubStr(%finalCleaned, %len-1, 1) == " ")
			%finalCleaned = String::getSubStr(%finalCleaned, 0, %len-1);
	}
	%beltStorage = %finalCleaned;
	
	// Always update BeltStorage from saved data on load to ensure it matches
	// This fixes cases where BeltStorage might be out of sync
	storeData(%clientId, "BeltStorage", %beltStorage);
	//echo("DEBUG Belt::BankStorageConversion: Rebuilt BeltStorage='" @ %beltStorage @ "'");
	
	// Update stored categories to match the cleaned versions we just processed
	// This ensures they stay in sync with BeltStorage
	storeData(%clientId, "StoredQuestItems", %storedQuest);
	storeData(%clientId, "StoredKeyItems", %storedKey);
	storeData(%clientId, "StoredConsumables", %storedConsumables);
	storeData(%clientId, "StoredArmor", %storedArmor);
	storeData(%clientId, "StoredAccessories", %storedAccessories);
	storeData(%clientId, "StoredOther", %storedOther);
	//echo("DEBUG Belt::BankStorageConversion: Updated StoredQuestItems='" @ %storedQuest @ "'");
	
	// Also clean up equipped categories (QuestItems, KeyItems) to remove corrupted entries
	// Skip GetNS cleanup during early load to avoid "Unknown command" errors
	// GetNS will be called later when functions are fully loaded
	// For now, just do basic validation
	for(%i = 1; $Belt::Categories[%i] != ""; %i++)
	{
		%category = $Belt::Categories[%i];
		%equipped = fetchData(%clientId, %category);
		
		// Basic cleanup: normalize "0" to empty string
		if(%equipped == "0" || %equipped == " ")
			%equipped = "";
		
		// Simple validation: remove invalid entries (item "0", count 0, etc.)
		%cleanedEquipped = "";
		for(%j = 0; GetWord(%equipped, %j) != -1; %j += 2)
		{
			%item = GetWord(%equipped, %j);
			%count = GetWord(%equipped, %j + 1);
			%countNum = %count * 1;
			if(%item != "" && %item != -1 && %item != "0" && %count != "" && %count != -1 && %count != "-1" && %count != "0" && %countNum > 0)
				%cleanedEquipped = %cleanedEquipped @ %item @ " " @ %count @ " ";
		}
		%len = String::len(%cleanedEquipped);
		if(%len > 0 && String::getSubStr(%cleanedEquipped, %len-1, 1) == " ")
			%cleanedEquipped = String::getSubStr(%cleanedEquipped, 0, %len-1);
		
		if(%cleanedEquipped != %equipped)
		{
			storeData(%clientId, %category, %cleanedEquipped);
		}
	}
	
	// Force refresh to update any open menus
	RefreshAll(%clientId);
}

function MenuViewBackpack(%clientId, %page)
{
	MenuViewBelt(%clientId, %page);
}

function MenuViewBelt(%clientId, %page)
{
	Client::buildMenu(%clientId, ".:(Backpack):.", "ViewBelt", true);
	
	%cnt = 1; // Initialize menu counter
	for(%i = 1; %i < Belt::GetLastItem(); %i++)
	{
		if(!Belt::isEmpty(%clientId, $Belt::Categories[%i]))
			Client::addMenuItem(%clientId, %cnt++ @ ". " @ Belt::Display($Belt::Categories[%i]), $Belt::Categories[%i]);
	}

	Client::addMenuItem(%clientId, "xDone", "done");
	return;
}

function processMenuViewBelt(%clientId, %opt)
{
	%o = GetWord(%opt, 0);
	%p = GetWord(%opt, 1);

	if($Belt::Count[%o] > 0)
	{
		MenuBeltGear(%clientId, %o, 1);
		return;
	}

	if(%o != "done")
	MenuViewBelt(%clientId, %p);

	return;
}

function MenuBeltGear(%clientId, %type, %page)
{
	%disp = Belt::Display(%type);

	%msg = "<jc><f2>To drop 'bulk' " @ %disp @ ", please enter your desired 'bulk' number now!\n\n'Bulk' numbers must be greater than 0 and less than 500";
	bottomprint(%clientId, %msg, floor(String::len(%msg) / 20));
	
	Client::buildMenu(%clientId, %disp @ ":", "BeltGear", true);
	%clientId.bulkNum = "";

	%cnt = 1; // Initialize menu counter
	%l = 6;
	%nx = $Belt::Count[%type];
	%nf = Belt::GetNS(%clientId, %type);
	%ns = GetWord(%nf, 0);
	%np = floor(%ns / %l);
	%lb = (%page * %l) - (%l-1);
	%ub = %lb + (%l-1);
	if(%ub > %ns)
	%ub = %ns;

	%x = %lb - 1;
	for(%i = %lb; %i <= %ub; %i++)
	{
		%x++;
		%item = getword(%nf, %x);
		%amnt = Belt::HasThisStuff(%clientId, %item);
		Client::addMenuItem(%clientId, %cnt++ @ ": " @ %amnt @ " " @ $BeltItem[%item, "Name"], %item @ " " @ %page @ " " @ %type);
	}

	if(%page == 1)
	{
		if(%ns > 6) Client::addMenuItem(%clientId, "nNext >>", "page " @ %page+1 @ " " @ %type);
		Client::addMenuItem(%clientId, "bBack", "back " @ %type);
		Client::addMenuItem(%clientId, "xDone", "done");
	}
	else if(%page == %np+1)
	{
		Client::addMenuItem(%clientId, "p<< Prev", "page " @ %page-1 @ " " @ %type);
		Client::addMenuItem(%clientId, "bBack", "back " @ %type);
		Client::addMenuItem(%clientId, "xDone", "done");
	}
	else
	{
		Client::addMenuItem(%clientId, "nNext >>", "page " @ %page+1 @ " " @ %type);
		Client::addMenuItem(%clientId, "p<< Prev", "page " @ %page-1 @ " " @ %type);
		Client::addMenuItem(%clientId, "bBack", "back " @ %type);
	}

	return;
}

function processMenuBeltGear(%clientId, %opt)
{
	%o = GetWord(%opt, 0);
	%p = GetWord(%opt, 1);
	%t = GetWord(%opt, 2);

	if(%o == "back")
	{
		MenuViewBelt(%clientId, 1);
		return;
	}

	if(%o != "page" && %o != "done")
	{
		if(%clientId.bulkNum < 1)
		%clientId.bulkNum = 1;
		if(%clientId.bulkNum > 500)
		%clientId.bulkNum = 500;

		MenuBeltDrop(%clientId, %o, %t);
		return;
	}

	if(%o != "done")
	MenuBeltGear(%clientId, %t, %p);

	return;
}

function MenuBeltDrop(%clientId, %item, %type)
{
	%name = $BeltItem[%item, "Name"];
	%amnt = %clientId.bulkNum;
	%cmnt = Belt::HasThisStuff(%clientId, %item);

	if(%amnt > %cmnt)
	%amnt = %cmnt;

	Client::buildMenu(%clientId, %name @ " (" @ %cmnt @ ")", "BeltDrop", true);
	
	%cnt = 1; // Initialize menu counter
	
	// Check if item is consumable (potions are in Consumables category)
	// Also check if the item itself is a known potion (in case type isn't passed correctly)
	%isConsumable = (%type == "Consumables" || %item == "BluePotion" || %item == "CrystalBluePotion" || %item == "EnergyVial" || %item == "CrystalEnergyVial");
	
	if(%isConsumable)
	{
		Client::addMenuItem(%clientId, %cnt++ @ ": Use", %type @ " use " @ %item);
	}
	
	// Check if item is deployable (DepBasePack has onDeploy callback)
	if(%item == "DepBasePack")
	{
		Client::addMenuItem(%clientId, %cnt++ @ "Deploy", %type @ " deploy " @ %item);
	}
	
	Client::addMenuItem(%clientId, %cnt++ @ "Drop (" @ %amnt @ ")", %type @ " drop " @ %item @ " " @ %amnt);
	Client::addMenuItem(%clientId, %cnt++ @ "Examine", %type @ " examine " @ %item);
	Client::addMenuItem(%clientId, "xDone", "done");
	return;
}

function processMenuBeltDrop(%clientId, %opt)
{
	%type = GetWord(%opt, 0);
	%option = GetWord(%opt, 1);
	%item = GetWord(%opt, 2);
	%amnt = GetWord(%opt, 3);

	if(%amnt <= 0) %amnt = 1;

	if(%amnt != %clientId.bulkNum)
	{
		if(%clientId.bulkNum < 1)	%clientId.bulkNum = 1;
		if(%clientId.bulkNum > 500)	%clientId.bulkNum = 500;
		MenuBeltDrop(%clientId, %item, %type);
	}
	else if(%option == "use")
	{
		// Use consumable item (potions, etc.)
		Belt::UseItem(%clientId, %item, %type);
	}
	else if(%option == "deploy")
	{
		Belt::DeployItem(%clientId, %item, %type);
	}
	else if(%option == "drop")
	{
		Belt::DropItem(%clientId, %item, %amnt, %type);
	}
	else if(%option == "examine")
	{
		Belt::WhatIs(%clientId, %item);
	}
	return;
}

function MenuSellBelt(%clientId)
{
	Client::buildMenu(%clientId, "Pack Sell:", "SellBelt", true);

	for(%i = 1; %i < Belt::GetLastItem(); %i++)
	if(!Belt::isEmpty(%clientId, $Belt::Categories[%i]))
	Client::addMenuItem(%clientId, %cnt++ @ Belt::Display($Belt::Categories[%i]), $Belt::Categories[%i]);
	
	Client::addMenuItem(%clientId, "xFinished", "done");
	return;
}

function processMenuSellBelt(%clientId, %opt)
{
	if($Belt::Count[%opt] > 0)
	{
		MenuSellBeltItem(%clientId, %opt, 1);
		return;
	}

	if(%opt == "done")
	{
		// Clear the belt sell flag and stored order when menu is closed
		%clientId.currentBeltSell = "";
		// Clear stored orders for all belt types
		for(%i = 1; $Belt::Categories[%i] != ""; %i++)
		{
			%clientId.beltItemOrder[$Belt::Categories[%i]] = "";
			%clientId.beltStoredItemOrder[$Belt::Categories[%i]] = "";
		}
		Client::cancelMenu(%clientId);
		return;
	}

	if(%opt != "done")
	MenuSellBelt(%clientId);

	return;
}

function MenuSellBeltItem(%clientId, %type, %page)
{
	%disp = Belt::Display(%type);

	// Store the original order when first opening the menu (page 1)
	if(%page == 1 && %clientId.beltItemOrder[%type] == "")
	{
		%stuff = fetchData(%clientId, %type);
		%orderList = "";
		for(%i = 0; (%item = getWord(%stuff, %i)) != -1; %i+=2)
		{
			%amnt = getWord(%stuff, %i + 1);
			if(%amnt > 0)
			{
				%orderList = %orderList @ " " @ %item;
			}
		}
		%clientId.beltItemOrder[%type] = String::NEWgetSubStr(%orderList, 1, 99999);
	}

	Client::buildMenu(%clientId, %disp @ " Sell:", "SellBeltItem", true);

	%l = 6;
	%nx = $Belt::Count[%type];
	%nf = Belt::GetNS(%clientId, %type);
	%ns = GetWord(%nf, 0);
	%np = floor(%ns / %l);
	%lb = (%page * %l) - (%l-1);
	%ub = %lb + (%l-1);
	if(%ub > %ns)
	%ub = %ns;

	%x = %lb - 1;
	for(%i = %lb; %i <= %ub; %i++)
	{
		%x++;
		%item = getword(%nf, %x);
		%amnt = Belt::HasThisStuff(%clientId, %item);
		Client::addMenuItem(%clientId, %cnt++ @ %amnt @ " " @ $BeltItem[%item, "Name"], %item @ " " @ %page @ " " @ %type);
	}

	if(%page == 1)
	{
		if(%ns > 6) Client::addMenuItem(%clientId, "nNext >>", "page " @ %page+1 @ " " @ %type);
		Client::addMenuItem(%clientId, "xDone", "done");
	}
	else if(%page == %np+1)
	{
		Client::addMenuItem(%clientId, "p<< Prev", "page " @ %page-1 @ " " @ %type);
		Client::addMenuItem(%clientId, "xDone", "done");
	}
	else
	{
		Client::addMenuItem(%clientId, "nNext >>", "page " @ %page+1 @ " " @ %type);
		Client::addMenuItem(%clientId, "p<< Prev", "page " @ %page-1 @ " " @ %type);
	}

	return;
}

function processMenuSellBeltItem(%clientId, %opt)
{
	%o = GetWord(%opt, 0);
	%p = GetWord(%opt, 1);
	%t = GetWord(%opt, 2);

	if(%o == "back")
	{
		MenuSellBelt(%clientId);
		return;
	}

	if(%o != "page" && %o != "done")
	{
		MenuSellBeltItemFinal(%clientId, %o, %t, "sell");
		return;
	}

	if(%o != "done")
	MenuSellBeltItem(%clientId, %t, %p);

	return;
}

function MenuSellBeltItemFinal(%clientId, %item, %type, %mode)
{
	// Validate item parameter
	if(%item == "" || %item == -1 || %item == "0")
	{
		%clientName = Client::getName(%clientId);
		echo("ERROR: MenuSellBeltItemFinal - Invalid item parameter: '" @ %item @ "' type: '" @ %type @ "' mode: '" @ %mode @ "' ClientId: " @ %clientId @ " (" @ %clientName @ ")");
		return;
	}
	
	%name = $BeltItem[%item, "Name"];
	if(%name == "")
	{
		// Fallback to AccessoryVar for non-belt items or items without BeltItem registration
		%name = $AccessoryVar[%item, $Name];
	if(%name == "")
		%name = %item;
	}
	
	%cnt = 1; // Initialize menu counter
	
	// Get available count based on mode
	if(%mode == "withdraw")
	{
		// Check if withdrawing from banker (BeltStorage) or from belt storage (StoredQuestItems/StoredKeyItems)
		if(%clientId.currentBeltBank != "")
			%cmnt = Belt::ItemCount(%item, fetchData(%clientId, "BeltStorage"));
		else
			%cmnt = Belt::ItemCount(%item, fetchData(%clientId, "Stored" @ %type));
	}
	else if(%mode == "store" || %mode == "sell")
		%cmnt = Belt::ItemCount(%item, fetchData(%clientId, %type));
	else
		%cmnt = 0;

	Client::buildMenu(%clientId, %name @ " (" @ %cmnt @ ")", "SellBeltItemFinal", true);

	// Show Sell/Withdraw/Store 1 button if player has 1 or more (always show if count > 0)
	if(%cmnt >= 1)
	{
		if(%mode == "sell")
		{
			%cost1 = Belt::GetSellCost(%clientId, %item) * 1;
			Client::addMenuItem(%clientId, %cnt++ @ "Sell 1 ($" @ %cost1 @ ")", %type @ " sell " @ %item @ " 1");
		}
		else if(%mode == "withdraw")
		{
			Client::addMenuItem(%clientId, %cnt++ @ "Withdraw 1", %type @ " withdraw " @ %item @ " 1");
		}
		else if(%mode == "store")
		{
			Client::addMenuItem(%clientId, %cnt++ @ "Store 1", %type @ " store " @ %item @ " 1");
		}
	}

	// Show Sell/Withdraw/Store 5 button if player has 5 or more
	if(%cmnt >= 5)
	{
		if(%mode == "sell")
		{
			%cost5 = Belt::GetSellCost(%clientId, %item) * 5;
			Client::addMenuItem(%clientId, %cnt++ @ "Sell 5 ($" @ %cost5 @ ")", %type @ " sell " @ %item @ " 5");
		}
		else if(%mode == "withdraw")
		{
			Client::addMenuItem(%clientId, %cnt++ @ "Withdraw 5", %type @ " withdraw " @ %item @ " 5");
		}
		else if(%mode == "store")
		{
			Client::addMenuItem(%clientId, %cnt++ @ "Store 5", %type @ " store " @ %item @ " 5");
		}
	}

	// Show Sell/Withdraw/Store 10 button if player has 10 or more
	if(%cmnt >= 10)
	{
		if(%mode == "sell")
		{
			%cost10 = Belt::GetSellCost(%clientId, %item) * 10;
			Client::addMenuItem(%clientId, %cnt++ @ "Sell 10 ($" @ %cost10 @ ")", %type @ " sell " @ %item @ " 10");
		}
		else if(%mode == "withdraw")
		{
			Client::addMenuItem(%clientId, %cnt++ @ "Withdraw 10", %type @ " withdraw " @ %item @ " 10");
		}
		else if(%mode == "store")
		{
			Client::addMenuItem(%clientId, %cnt++ @ "Store 10", %type @ " store " @ %item @ " 10");
		}
	}

	// Always show Sell/Withdraw/Store All button
	if(%mode == "sell")
	{
		%costAll = Belt::GetSellCost(%clientId, %item) * %cmnt;
		Client::addMenuItem(%clientId, %cnt++ @ "Sell All (" @ %cmnt @ ") ($" @ %costAll @ ")", %type @ " sell " @ %item @ " " @ %cmnt);
	}
	else if(%mode == "withdraw")
	{
		Client::addMenuItem(%clientId, %cnt++ @ "Withdraw All (" @ %cmnt @ ")", %type @ " withdraw " @ %item @ " " @ %cmnt);
	}
	else if(%mode == "store")
	{
		Client::addMenuItem(%clientId, %cnt++ @ "Store All (" @ %cmnt @ ")", %type @ " store " @ %item @ " " @ %cmnt);
	}

	Client::addMenuItem(%clientId, "bBack", %type @ " back " @ %item @ " " @ %mode);
	Client::addMenuItem(%clientId, "xFinished", "ineedanextrawordsothisisithaha done");
	return;
}

function processMenuSellBeltItemFinal(%clientId, %opt)
{
	%type = GetWord(%opt, 0);
	%option = GetWord(%opt, 1);
	
	// Check for menu closure option first, before validating other parameters
	if(%type == "ineedanextrawordsothisisithaha" || %option == "done")
	{
		// Clear the belt sell flag and stored order when menu is closed
		%clientId.currentBeltSell = "";
		// Clear stored orders for all belt types
		for(%i = 1; $Belt::Categories[%i] != ""; %i++)
		{
			%clientId.beltItemOrder[$Belt::Categories[%i]] = "";
			%clientId.beltStoredItemOrder[$Belt::Categories[%i]] = "";
		}
		Client::CancelMenu(%clientId);
		return;
	}
	
	%item = GetWord(%opt, 2);
	%amnt = GetWord(%opt, 3);
	
	// Validate parameters
	if(%item == "" || %item == -1)
	{
		%clientName = Client::getName(%clientId);
		echo("ERROR: processMenuSellBeltItemFinal - Invalid item parameter: '" @ %item @ "' from option: '" @ %opt @ "' ClientId: " @ %clientId @ " (" @ %clientName @ ")");
		return;
	}
	if(%amnt == "" || %amnt == -1)
	{
		%clientName = Client::getName(%clientId);
		echo("ERROR: processMenuSellBeltItemFinal - Invalid amount parameter: '" @ %amnt @ "' from option: '" @ %opt @ "' ClientId: " @ %clientId @ " (" @ %clientName @ ")");
		return;
	}
	%amnt = floor(%amnt); // Ensure %amnt is a number
	
	if(%option == "back")
	{
		%mode = GetWord(%opt, 3);
		if(%mode == "sell")
			MenuSellBeltItem(%clientId, %type, 1);
		else if(%mode == "store")
		{
			// Check if storing to banker or belt storage
			if(%clientId.currentBeltBank != "")
				Belt::ShowDepositMenu(%clientId);
			else
				MenuBeltStoreThisItem(%clientId, %type, 1, %mode);
		}
		else if(%mode == "withdraw")
		{
			// Check if withdrawing from banker or belt storage
			if(%clientId.currentBeltBank != "")
				Belt::ShowWithdrawMenu(%clientId);
			else
				MenuBeltWithdrawThisItem(%clientId, %type, 1, %mode);
		}
		return;
	}
	else if(%option == "sell")
	{
		%cmnt = Belt::HasThisStuff(%clientId, %item);
		if(%cmnt >= %amnt)
		{
			%cost = Belt::GetSellCost(%clientId, %item) * %amnt;
			Client::sendMessage(%clientId, $MsgWhite, "You sold " @ %amnt @ " " @ %item @ " for " @ %cost @ " coins.");
			UseSkill(%clientId, $SkillHaggling, true, true);
			storeData(%clientId, "COINS", %cost, "inc");
			Belt::TakeThisStuff(%clientId, %item, %amnt);
			RefreshAll(%clientId);
			%clientId.bulkNum = 1;
			// Save character after selling to ensure coins and item changes are persisted
			SaveCharacter(%clientId);
			// Return to sell menu after selling
			MenuSellBeltItem(%clientId, %type, 1);
		}
	}
	else if(%option == "store")
	{
		// Get the registered item name (what's actually stored in the equipped category)
		%registeredItem = $BeltItem[%item, "Item"];
		if(%registeredItem == "")
		{
			%clientName = Client::getName(%clientId);
			echo("ERROR: Belt deposit - Item '" @ %item @ "' not found in belt item registry! ClientId: " @ %clientId @ " (" @ %clientName @ ")");
			return;
		}
		
		%cmnt = Belt::HasThisStuff(%clientId, %item);
		if(%cmnt >= %amnt)
		{
			// Check if storing to banker (BeltStorage) or to belt storage (old system)
			if(%clientId.currentBeltBank != "")
			{
				// Storing to banker - work directly with BeltStorage as single source of truth
				%beltStorage = fetchData(%clientId, "BeltStorage");
				
				// Normalize "0" to empty string
				if(%beltStorage == "0" || %beltStorage == " ")
					%beltStorage = "";
				
				// Clean BeltStorage before adding to remove any invalid entries
				%cleanedStorage = "";
				for(%i = 0; GetWord(%beltStorage, %i) != -1; %i += 2)
				{
					%itemName = GetWord(%beltStorage, %i);
					%itemCount = GetWord(%beltStorage, %i + 1);
					%countNum = %itemCount * 1;
					if(%itemName != "" && %itemName != -1 && %itemName != "0" && %itemCount != "" && %itemCount != -1 && %itemCount != "-1" && %itemCount != "0" && %countNum > 0)
						%cleanedStorage = %cleanedStorage @ %itemName @ " " @ %itemCount @ " ";
				}
				%len = String::len(%cleanedStorage);
				if(%len > 0 && String::getSubStr(%cleanedStorage, %len-1, 1) == " ")
					%cleanedStorage = String::getSubStr(%cleanedStorage, 0, %len-1);
				%beltStorage = %cleanedStorage;
				
				// Count unique items in BeltStorage
				%currentStorageCount = 0;
				for(%i = 0; GetWord(%beltStorage, %i) != -1; %i += 2)
				{
					%itemName = GetWord(%beltStorage, %i);
					if(%itemName != "" && %itemName != -1 && %itemName != "0")
						%currentStorageCount++;
				}
				
				if(%currentStorageCount < 25)
				{
					// Add item directly to BeltStorage (single source of truth)
					%newBeltStorage = SetStuffString(%beltStorage, %registeredItem, %amnt);
					
					// Clean result after SetStuffString to remove any "0" entries
					%cleanedResult = "";
					for(%i = 0; GetWord(%newBeltStorage, %i) != -1; %i += 2)
					{
						%itemName = GetWord(%newBeltStorage, %i);
						%itemCount = GetWord(%newBeltStorage, %i + 1);
						%countNum = %itemCount * 1;
						if(%itemName != "" && %itemName != -1 && %itemName != "0" && %itemCount != "" && %itemCount != -1 && %itemCount != "-1" && %itemCount != "0" && %countNum > 0)
							%cleanedResult = %cleanedResult @ %itemName @ " " @ %itemCount @ " ";
					}
					%len = String::len(%cleanedResult);
					if(%len > 0 && String::getSubStr(%cleanedResult, %len-1, 1) == " ")
						%cleanedResult = String::getSubStr(%cleanedResult, 0, %len-1);
					
					// Save cleaned BeltStorage
					storeData(%clientId, "BeltStorage", %cleanedResult);
					
					// Remove from equipped belt
					Belt::TakeThisStuff(%clientId, %item, %amnt);
					
					%clientId.bulkNum = 1;
					RefreshAll(%clientId);
					SaveCharacter(%clientId);
					
					%itemName = $BeltItem[%registeredItem, "Name"];
					if(%itemName == "")
					{
						// Fallback to AccessoryVar for non-belt items
						%itemName = $AccessoryVar[%registeredItem, $Name];
						if(%itemName == "")
							%itemName = %registeredItem;
					}
					Client::sendMessage(%clientId, $MsgGreen, "Deposited " @ %amnt @ " " @ %itemName @ " into backpack storage.");
					
					// Clear stored order so menu rebuilds with current items
					%clientId.beltDepositItemOrder = "";
					
					// Return to deposit menu
					Belt::ShowDepositMenu(%clientId);
				}
				else
				{
					Client::sendMessage(%clientId, $MsgRed, "You can only place 25 different items into backpack storage.~wC_BuySell.wav");
				}
			}
			else
			{
				// Storing to belt storage (old system)
				if(CountObjInList(fetchData(%clientId, "Stored" @ %type)) / 2 < 25)
				{		
					storeData(%clientId, "Stored" @ %type, SetStuffString(fetchData(%clientId, "Stored" @ %type), %registeredItem, %amnt));
					Belt::TakeThisStuff(%clientId, %item, %amnt);
					%clientId.bulkNum = 1;
					RefreshAll(%clientId);
					SaveCharacter(%clientId);
					MenuBeltStoreThisItem(%clientId, %type, 1, "store");
				}
				else
				{
					Client::sendMessage(%clientId, $MsgRed, "You can only place 25 different items into the " @ Belt::Display(%type) @ " storage.~wC_BuySell.wav");
				}
			}
		}
	}
	else if(%option == "withdraw")
	{
		// Get the registered item name (what's actually stored in BeltStorage)
		%registeredItem = $BeltItem[%item, "Item"];
		if(%registeredItem == "")
		{
			// Try using %item directly - it might already be the registered name from BeltStorage
			%registeredItem = %item;
		}
		
		// Check if withdrawing from banker (BeltStorage) or from belt storage (old system)
		if(%clientId.currentBeltBank != "")
		{
			// Withdrawing from banker - work directly with BeltStorage as single source of truth
			%beltStorage = fetchData(%clientId, "BeltStorage");
			
			// Normalize "0" to empty string
			if(%beltStorage == "0" || %beltStorage == " ")
				%beltStorage = "";
			
			// Clean BeltStorage before checking count
			%cleanedStorage = "";
			for(%i = 0; GetWord(%beltStorage, %i) != -1; %i += 2)
			{
				%itemName = GetWord(%beltStorage, %i);
				%itemCount = GetWord(%beltStorage, %i + 1);
				%countNum = %itemCount * 1;
				if(%itemName != "" && %itemName != -1 && %itemName != "0" && %itemCount != "" && %itemCount != -1 && %itemCount != "-1" && %itemCount != "0" && %countNum > 0)
					%cleanedStorage = %cleanedStorage @ %itemName @ " " @ %itemCount @ " ";
			}
			%len = String::len(%cleanedStorage);
			if(%len > 0 && String::getSubStr(%cleanedStorage, %len-1, 1) == " ")
				%cleanedStorage = String::getSubStr(%cleanedStorage, 0, %len-1);
			%beltStorage = %cleanedStorage;
			
			// Check count in BeltStorage
			%cmnt = Belt::ItemCount(%registeredItem, %beltStorage);
			
			if(%cmnt >= %amnt)
			{
				// Remove item directly from BeltStorage
				%newBeltStorage = SetStuffString(%beltStorage, %registeredItem, -%amnt);
				
				// Clean result after SetStuffString to remove any "0" entries
				%cleanedResult = "";
				for(%i = 0; GetWord(%newBeltStorage, %i) != -1; %i += 2)
				{
					%itemName = GetWord(%newBeltStorage, %i);
					%itemCount = GetWord(%newBeltStorage, %i + 1);
					%countNum = %itemCount * 1;
					if(%itemName != "" && %itemName != -1 && %itemName != "0" && %itemCount != "" && %itemCount != -1 && %itemCount != "-1" && %itemCount != "0" && %countNum > 0)
						%cleanedResult = %cleanedResult @ %itemName @ " " @ %itemCount @ " ";
				}
				%len = String::len(%cleanedResult);
				if(%len > 0 && String::getSubStr(%cleanedResult, %len-1, 1) == " ")
					%cleanedResult = String::getSubStr(%cleanedResult, 0, %len-1);
				
				// Save cleaned BeltStorage
				storeData(%clientId, "BeltStorage", %cleanedResult);
				
				// Add to equipped belt
				Belt::GiveThisStuff(%clientId, %item, %amnt, 1);
				
				%clientId.bulkNum = 1;
				RefreshAll(%clientId);
				SaveCharacter(%clientId);
				
				%itemName = $BeltItem[%registeredItem, "Name"];
				if(%itemName == "")
				{
					// Fallback to AccessoryVar for non-belt items
					%itemName = $AccessoryVar[%registeredItem, $Name];
					if(%itemName == "")
						%itemName = %registeredItem;
				}
				Client::sendMessage(%clientId, $MsgGreen, "Withdrew " @ %amnt @ " " @ %itemName @ " from backpack storage.");
				
				// Clear stored order so menu rebuilds with current items
				%clientId.beltWithdrawItemOrder = "";
				
				// Return to withdraw menu
				Belt::ShowWithdrawMenu(%clientId);
			}
			else
			{
				Client::sendMessage(%clientId, $MsgRed, "You don't have enough " @ $BeltItem[%registeredItem, "Name"] @ " in storage.");
			}
		}
		else
		{
			// Withdrawing from belt storage (old system)
			%cmnt = Belt::GetStored(%clientId, %opt);
			if(%cmnt >= %amnt)
			{
				Belt::GiveThisStuff(%clientId, %item, %amnt, 1);
				storeData(%clientId, "Stored" @ %type, SetStuffString(fetchData(%clientId, "Stored" @ %type), %item, -%amnt));
				%clientId.bulkNum = 1;
				RefreshAll(%clientId);
				SaveCharacter(%clientId);
				MenuBeltWithdrawThisItem(%clientId, %opt, 1, "withdraw");
			}
		}
	}
	return;
}

function MenuSellBeltItemFinal(%clientId, %item, %type, %mode)
{
	// Validate item parameter
	if(%item == "" || %item == -1 || %item == "0")
	{
		%clientName = Client::getName(%clientId);
		echo("ERROR: MenuSellBeltItemFinal - Invalid item parameter: '" @ %item @ "' type: '" @ %type @ "' mode: '" @ %mode @ "' ClientId: " @ %clientId @ " (" @ %clientName @ ")");
		return;
	}
	
	%name = $BeltItem[%item, "Name"];
	if(%name == "")
	{
		// Fallback to AccessoryVar for non-belt items or items without BeltItem registration
		%name = $AccessoryVar[%item, $Name];
		if(%name == "")
			%name = %item;
	}
	
	%cnt = 1; // Initialize menu counter
	
	// Get available count based on mode
	if(%mode == "withdraw")
	{
		// Check if withdrawing from banker (BeltStorage) or from belt storage (StoredQuestItems/StoredKeyItems)
		if(%clientId.currentBeltBank != "")
			%cmnt = Belt::ItemCount(%item, fetchData(%clientId, "BeltStorage"));
		else
			%cmnt = Belt::ItemCount(%item, fetchData(%clientId, "Stored" @ %type));
	}
	else if(%mode == "store" || %mode == "sell")
		%cmnt = Belt::ItemCount(%item, fetchData(%clientId, %type));
	else
		%cmnt = 0;

	Client::buildMenu(%clientId, %name @ " (" @ %cmnt @ ")", "SellBeltItemFinal", true);

	// Show Sell/Withdraw/Store 1 button if player has 1 or more (always show if count > 0)
	if(%cmnt >= 1)
	{
		if(%mode == "sell")
		{
			%cost1 = Belt::GetSellCost(%clientId, %item) * 1;
			Client::addMenuItem(%clientId, %cnt++ @ "Sell 1 ($" @ %cost1 @ ")", %type @ " sell " @ %item @ " 1");
		}
		else if(%mode == "withdraw")
		{
			Client::addMenuItem(%clientId, %cnt++ @ "Withdraw 1", %type @ " withdraw " @ %item @ " 1");
		}
		else if(%mode == "store")
		{
			Client::addMenuItem(%clientId, %cnt++ @ "Store 1", %type @ " store " @ %item @ " 1");
		}
	}

	// Show Sell/Withdraw/Store 5 button if player has 5 or more
	if(%cmnt >= 5)
	{
		if(%mode == "sell")
		{
			%cost5 = Belt::GetSellCost(%clientId, %item) * 5;
			Client::addMenuItem(%clientId, %cnt++ @ "Sell 5 ($" @ %cost5 @ ")", %type @ " sell " @ %item @ " 5");
		}
		else if(%mode == "withdraw")
		{
			Client::addMenuItem(%clientId, %cnt++ @ "Withdraw 5", %type @ " withdraw " @ %item @ " 5");
		}
		else if(%mode == "store")
		{
			Client::addMenuItem(%clientId, %cnt++ @ "Store 5", %type @ " store " @ %item @ " 5");
		}
	}

	// Show Sell/Withdraw/Store 10 button if player has 10 or more
	if(%cmnt >= 10)
	{
		if(%mode == "sell")
		{
			%cost10 = Belt::GetSellCost(%clientId, %item) * 10;
			Client::addMenuItem(%clientId, %cnt++ @ "Sell 10 ($" @ %cost10 @ ")", %type @ " sell " @ %item @ " 10");
		}
		else if(%mode == "withdraw")
		{
			Client::addMenuItem(%clientId, %cnt++ @ "Withdraw 10", %type @ " withdraw " @ %item @ " 10");
		}
		else if(%mode == "store")
		{
			Client::addMenuItem(%clientId, %cnt++ @ "Store 10", %type @ " store " @ %item @ " 10");
		}
	}

	// Always show Sell/Withdraw/Store All button
	if(%mode == "sell")
	{
		%costAll = Belt::GetSellCost(%clientId, %item) * %cmnt;
		Client::addMenuItem(%clientId, %cnt++ @ "Sell All (" @ %cmnt @ ") ($" @ %costAll @ ")", %type @ " sell " @ %item @ " " @ %cmnt);
	}
	else if(%mode == "withdraw")
	{
		Client::addMenuItem(%clientId, %cnt++ @ "Withdraw All (" @ %cmnt @ ")", %type @ " withdraw " @ %item @ " " @ %cmnt);
	}
	else if(%mode == "store")
	{
		Client::addMenuItem(%clientId, %cnt++ @ "Store All (" @ %cmnt @ ")", %type @ " store " @ %item @ " " @ %cmnt);
	}

	Client::addMenuItem(%clientId, "bBack", %type @ " back " @ %item @ " " @ %mode);
	Client::addMenuItem(%clientId, "xFinished", "ineedanextrawordsothisisithaha done");
	return;
}

function processMenuSellBeltItemFinal(%clientId, %opt)
{
	%type = GetWord(%opt, 0);
	%option = GetWord(%opt, 1);
	
	// Check for menu closure option first, before validating other parameters
	if(%type == "ineedanextrawordsothisisithaha" || %option == "done")
	{
		// Clear the belt sell flag and stored order when menu is closed
		%clientId.currentBeltSell = "";
		// Clear stored orders for all belt types
		for(%i = 1; $Belt::Categories[%i] != ""; %i++)
		{
			%clientId.beltItemOrder[$Belt::Categories[%i]] = "";
			%clientId.beltStoredItemOrder[$Belt::Categories[%i]] = "";
		}
		Client::CancelMenu(%clientId);
		return;
	}
	
	%item = GetWord(%opt, 2);
	%amnt = GetWord(%opt, 3);
	
	// Validate parameters
	if(%item == "" || %item == -1)
	{
		%clientName = Client::getName(%clientId);
		echo("ERROR: processMenuSellBeltItemFinal - Invalid item parameter: '" @ %item @ "' from option: '" @ %opt @ "' ClientId: " @ %clientId @ " (" @ %clientName @ ")");
		return;
	}
	if(%amnt == "" || %amnt == -1)
	{
		%clientName = Client::getName(%clientId);
		echo("ERROR: processMenuSellBeltItemFinal - Invalid amount parameter: '" @ %amnt @ "' from option: '" @ %opt @ "' ClientId: " @ %clientId @ " (" @ %clientName @ ")");
		return;
	}
	%amnt = floor(%amnt); // Ensure %amnt is a number
	
	if(%option == "back")
	{
		%mode = GetWord(%opt, 3);
		if(%mode == "sell")
			MenuSellBeltItem(%clientId, %type, 1);
		else if(%mode == "store")
		{
			// Check if storing to banker or belt storage
			if(%clientId.currentBeltBank != "")
				Belt::ShowDepositMenu(%clientId);
			else
				MenuBeltStoreThisItem(%clientId, %type, 1, %mode);
		}
		else if(%mode == "withdraw")
		{
			// Check if withdrawing from banker or belt storage
			if(%clientId.currentBeltBank != "")
				Belt::ShowWithdrawMenu(%clientId);
			else
				MenuBeltWithdrawThisItem(%clientId, %type, 1, %mode);
		}
		return;
	}
	else if(%option == "sell")
	{
		%cmnt = Belt::HasThisStuff(%clientId, %item);
		if(%cmnt >= %amnt)
		{
			%cost = Belt::GetSellCost(%clientId, %item) * %amnt;
			Client::sendMessage(%clientId, $MsgWhite, "You sold " @ %amnt @ " " @ %item @ " for " @ %cost @ " coins.");
			UseSkill(%clientId, $SkillHaggling, true, true);
			storeData(%clientId, "COINS", %cost, "inc");
			Belt::TakeThisStuff(%clientId, %item, %amnt);
			RefreshAll(%clientId);
			%clientId.bulkNum = 1;
			// Save character after selling to ensure coins and item changes are persisted
			SaveCharacter(%clientId);
			// Return to sell menu after selling
			MenuSellBeltItem(%clientId, %type, 1);
		}
	}
	else if(%option == "store")
	{
		// Get the registered item name (what's actually stored in the equipped category)
		%registeredItem = $BeltItem[%item, "Item"];
		if(%registeredItem == "")
		{
			%clientName = Client::getName(%clientId);
			echo("ERROR: Belt deposit - Item '" @ %item @ "' not found in belt item registry! ClientId: " @ %clientId @ " (" @ %clientName @ ")");
			return;
		}
		
		%cmnt = Belt::HasThisStuff(%clientId, %item);
		if(%cmnt >= %amnt)
		{
			// Check if storing to banker (BeltStorage) or to belt storage (old system)
			if(%clientId.currentBeltBank != "")
			{
				// Storing to banker - work directly with BeltStorage as single source of truth
				%beltStorage = fetchData(%clientId, "BeltStorage");
				
				// Normalize "0" to empty string
				if(%beltStorage == "0" || %beltStorage == " ")
					%beltStorage = "";
				
				// Clean BeltStorage before adding to remove any invalid entries
				%cleanedStorage = "";
				for(%i = 0; GetWord(%beltStorage, %i) != -1; %i += 2)
				{
					%itemName = GetWord(%beltStorage, %i);
					%itemCount = GetWord(%beltStorage, %i + 1);
					%countNum = %itemCount * 1;
					if(%itemName != "" && %itemName != -1 && %itemName != "0" && %itemCount != "" && %itemCount != -1 && %itemCount != "-1" && %itemCount != "0" && %countNum > 0)
						%cleanedStorage = %cleanedStorage @ %itemName @ " " @ %itemCount @ " ";
				}
				%len = String::len(%cleanedStorage);
				if(%len > 0 && String::getSubStr(%cleanedStorage, %len-1, 1) == " ")
					%cleanedStorage = String::getSubStr(%cleanedStorage, 0, %len-1);
				%beltStorage = %cleanedStorage;
				
				// Count unique items in BeltStorage
				%currentStorageCount = 0;
				for(%i = 0; GetWord(%beltStorage, %i) != -1; %i += 2)
				{
					%itemName = GetWord(%beltStorage, %i);
					if(%itemName != "" && %itemName != -1 && %itemName != "0")
						%currentStorageCount++;
				}
				
				if(%currentStorageCount < 25)
				{
					// Add item directly to BeltStorage (single source of truth)
					%newBeltStorage = SetStuffString(%beltStorage, %registeredItem, %amnt);
					
					// Clean result after SetStuffString to remove any "0" entries
					%cleanedResult = "";
					for(%i = 0; GetWord(%newBeltStorage, %i) != -1; %i += 2)
					{
						%itemName = GetWord(%newBeltStorage, %i);
						%itemCount = GetWord(%newBeltStorage, %i + 1);
						%countNum = %itemCount * 1;
						if(%itemName != "" && %itemName != -1 && %itemName != "0" && %itemCount != "" && %itemCount != -1 && %itemCount != "-1" && %itemCount != "0" && %countNum > 0)
							%cleanedResult = %cleanedResult @ %itemName @ " " @ %itemCount @ " ";
					}
					%len = String::len(%cleanedResult);
					if(%len > 0 && String::getSubStr(%cleanedResult, %len-1, 1) == " ")
						%cleanedResult = String::getSubStr(%cleanedResult, 0, %len-1);
					
					// Save cleaned BeltStorage
					storeData(%clientId, "BeltStorage", %cleanedResult);
					
					// Remove from equipped belt
					Belt::TakeThisStuff(%clientId, %item, %amnt);
					
					%clientId.bulkNum = 1;
					RefreshAll(%clientId);
					SaveCharacter(%clientId);
					
					%itemName = $BeltItem[%registeredItem, "Name"];
					if(%itemName == "")
					{
						// Fallback to AccessoryVar for non-belt items
						%itemName = $AccessoryVar[%registeredItem, $Name];
						if(%itemName == "")
							%itemName = %registeredItem;
					}
					Client::sendMessage(%clientId, $MsgGreen, "Deposited " @ %amnt @ " " @ %itemName @ " into backpack storage.");
					
					// Clear stored order so menu rebuilds with current items
					%clientId.beltDepositItemOrder = "";
					
					// Return to deposit menu
					Belt::ShowDepositMenu(%clientId);
				}
				else
				{
					Client::sendMessage(%clientId, $MsgRed, "You can only place 25 different items into backpack storage.~wC_BuySell.wav");
				}
			}
			else
			{
				// Storing to belt storage (old system)
				if(CountObjInList(fetchData(%clientId, "Stored" @ %type)) / 2 < 25)
				{		
					storeData(%clientId, "Stored" @ %type, SetStuffString(fetchData(%clientId, "Stored" @ %type), %registeredItem, %amnt));
					Belt::TakeThisStuff(%clientId, %item, %amnt);
					%clientId.bulkNum = 1;
					RefreshAll(%clientId);
					SaveCharacter(%clientId);
					MenuBeltStoreThisItem(%clientId, %type, 1, "store");
				}
				else
				{
					Client::sendMessage(%clientId, $MsgRed, "You can only place 25 different items into the " @ Belt::Display(%type) @ " storage.~wC_BuySell.wav");
				}
			}
		}
	}
	else if(%option == "withdraw")
	{
		// Get the registered item name (what's actually stored in BeltStorage)
		%registeredItem = $BeltItem[%item, "Item"];
		if(%registeredItem == "")
		{
			// Try using %item directly - it might already be the registered name from BeltStorage
			%registeredItem = %item;
		}
		
		// Check if withdrawing from banker (BeltStorage) or from belt storage (old system)
		if(%clientId.currentBeltBank != "")
		{
			// Withdrawing from banker - work directly with BeltStorage as single source of truth
			%beltStorage = fetchData(%clientId, "BeltStorage");
			
			// Normalize "0" to empty string
			if(%beltStorage == "0" || %beltStorage == " ")
				%beltStorage = "";
			
			// Clean BeltStorage before checking count
			%cleanedStorage = "";
			for(%i = 0; GetWord(%beltStorage, %i) != -1; %i += 2)
			{
				%itemName = GetWord(%beltStorage, %i);
				%itemCount = GetWord(%beltStorage, %i + 1);
				%countNum = %itemCount * 1;
				if(%itemName != "" && %itemName != -1 && %itemName != "0" && %itemCount != "" && %itemCount != -1 && %itemCount != "-1" && %itemCount != "0" && %countNum > 0)
					%cleanedStorage = %cleanedStorage @ %itemName @ " " @ %itemCount @ " ";
			}
			%len = String::len(%cleanedStorage);
			if(%len > 0 && String::getSubStr(%cleanedStorage, %len-1, 1) == " ")
				%cleanedStorage = String::getSubStr(%cleanedStorage, 0, %len-1);
			%beltStorage = %cleanedStorage;
			
			// Check count in BeltStorage
			%cmnt = Belt::ItemCount(%registeredItem, %beltStorage);
			
			if(%cmnt >= %amnt)
			{
				// Remove item directly from BeltStorage
				%newBeltStorage = SetStuffString(%beltStorage, %registeredItem, -%amnt);
				
				// Clean result after SetStuffString to remove any "0" entries
				%cleanedResult = "";
				for(%i = 0; GetWord(%newBeltStorage, %i) != -1; %i += 2)
				{
					%itemName = GetWord(%newBeltStorage, %i);
					%itemCount = GetWord(%newBeltStorage, %i + 1);
					%countNum = %itemCount * 1;
					if(%itemName != "" && %itemName != -1 && %itemName != "0" && %itemCount != "" && %itemCount != -1 && %itemCount != "-1" && %itemCount != "0" && %countNum > 0)
						%cleanedResult = %cleanedResult @ %itemName @ " " @ %itemCount @ " ";
				}
				%len = String::len(%cleanedResult);
				if(%len > 0 && String::getSubStr(%cleanedResult, %len-1, 1) == " ")
					%cleanedResult = String::getSubStr(%cleanedResult, 0, %len-1);
				
				// Save cleaned BeltStorage
				storeData(%clientId, "BeltStorage", %cleanedResult);
				
				// Add to equipped belt
				Belt::GiveThisStuff(%clientId, %item, %amnt, 1);
				
				%clientId.bulkNum = 1;
				RefreshAll(%clientId);
				SaveCharacter(%clientId);
				
				%itemName = $BeltItem[%registeredItem, "Name"];
				if(%itemName == "")
				{
					// Fallback to AccessoryVar for non-belt items
					%itemName = $AccessoryVar[%registeredItem, $Name];
					if(%itemName == "")
						%itemName = %registeredItem;
				}
				Client::sendMessage(%clientId, $MsgGreen, "Withdrew " @ %amnt @ " " @ %itemName @ " from backpack storage.");
				
				// Clear stored order so menu rebuilds with current items
				%clientId.beltWithdrawItemOrder = "";
				
				// Return to withdraw menu
				Belt::ShowWithdrawMenu(%clientId);
			}
			else
			{
				Client::sendMessage(%clientId, $MsgRed, "You don't have enough " @ $BeltItem[%registeredItem, "Name"] @ " in storage.");
			}
		}
		else
		{
			// Withdrawing from belt storage (old system)
			%cmnt = Belt::GetStored(%clientId, %opt);
			if(%cmnt >= %amnt)
			{
				Belt::GiveThisStuff(%clientId, %item, %amnt, 1);
				storeData(%clientId, "Stored" @ %type, SetStuffString(fetchData(%clientId, "Stored" @ %type), %item, -%amnt));
				%clientId.bulkNum = 1;
				RefreshAll(%clientId);
				SaveCharacter(%clientId);
				MenuBeltWithdrawThisItem(%clientId, %opt, 1, "withdraw");
			}
		}
	}
	return;
}

function MenuSellBeltItemFinal(%clientId, %item, %type, %mode)
{
	// Validate item parameter
	if(%item == "" || %item == -1 || %item == "0")
	{
		%clientName = Client::getName(%clientId);
		echo("ERROR: MenuSellBeltItemFinal - Invalid item parameter: '" @ %item @ "' type: '" @ %type @ "' mode: '" @ %mode @ "' ClientId: " @ %clientId @ " (" @ %clientName @ ")");
		return;
	}
	
	%name = $BeltItem[%item, "Name"];
	if(%name == "")
	{
		// Fallback to AccessoryVar for non-belt items or items without BeltItem registration
		%name = $AccessoryVar[%item, $Name];
		if(%name == "")
			%name = %item;
	}
	
	%cnt = 1; // Initialize menu counter
	
	// Get available count based on mode
	if(%mode == "withdraw")
	{
		// Check if withdrawing from banker (BeltStorage) or from belt storage (StoredQuestItems/StoredKeyItems)
		if(%clientId.currentBeltBank != "")
			%cmnt = Belt::ItemCount(%item, fetchData(%clientId, "BeltStorage"));
		else
			%cmnt = Belt::ItemCount(%item, fetchData(%clientId, "Stored" @ %type));
	}
	else if(%mode == "store" || %mode == "sell")
		%cmnt = Belt::ItemCount(%item, fetchData(%clientId, %type));
	else
		%cmnt = 0;

	Client::buildMenu(%clientId, %name @ " (" @ %cmnt @ ")", "SellBeltItemFinal", true);

	// Show Sell/Withdraw/Store 1 button if player has 1 or more (always show if count > 0)
	if(%cmnt >= 1)
	{
		if(%mode == "sell")
		{
			%cost1 = Belt::GetSellCost(%clientId, %item) * 1;
			Client::addMenuItem(%clientId, %cnt++ @ "Sell 1 ($" @ %cost1 @ ")", %type @ " sell " @ %item @ " 1");
		}
		else if(%mode == "withdraw")
		{
			Client::addMenuItem(%clientId, %cnt++ @ "Withdraw 1", %type @ " withdraw " @ %item @ " 1");
		}
		else if(%mode == "store")
		{
			Client::addMenuItem(%clientId, %cnt++ @ "Store 1", %type @ " store " @ %item @ " 1");
		}
	}

	// Show Sell/Withdraw/Store 5 button if player has 5 or more
	if(%cmnt >= 5)
	{
		if(%mode == "sell")
		{
			%cost5 = Belt::GetSellCost(%clientId, %item) * 5;
			Client::addMenuItem(%clientId, %cnt++ @ "Sell 5 ($" @ %cost5 @ ")", %type @ " sell " @ %item @ " 5");
		}
		else if(%mode == "withdraw")
		{
			Client::addMenuItem(%clientId, %cnt++ @ "Withdraw 5", %type @ " withdraw " @ %item @ " 5");
		}
		else if(%mode == "store")
		{
			Client::addMenuItem(%clientId, %cnt++ @ "Store 5", %type @ " store " @ %item @ " 5");
		}
	}

	// Show Sell/Withdraw/Store 10 button if player has 10 or more
	if(%cmnt >= 10)
	{
		if(%mode == "sell")
		{
			%cost10 = Belt::GetSellCost(%clientId, %item) * 10;
			Client::addMenuItem(%clientId, %cnt++ @ "Sell 10 ($" @ %cost10 @ ")", %type @ " sell " @ %item @ " 10");
		}
		else if(%mode == "withdraw")
		{
			Client::addMenuItem(%clientId, %cnt++ @ "Withdraw 10", %type @ " withdraw " @ %item @ " 10");
		}
		else if(%mode == "store")
		{
			Client::addMenuItem(%clientId, %cnt++ @ "Store 10", %type @ " store " @ %item @ " 10");
		}
	}

	// Always show Sell/Withdraw/Store All button
	if(%mode == "sell")
	{
		%costAll = Belt::GetSellCost(%clientId, %item) * %cmnt;
		Client::addMenuItem(%clientId, %cnt++ @ "Sell All (" @ %cmnt @ ") ($" @ %costAll @ ")", %type @ " sell " @ %item @ " " @ %cmnt);
	}
	else if(%mode == "withdraw")
	{
		Client::addMenuItem(%clientId, %cnt++ @ "Withdraw All (" @ %cmnt @ ")", %type @ " withdraw " @ %item @ " " @ %cmnt);
	}
	else if(%mode == "store")
		{
			Client::addMenuItem(%clientId, %cnt++ @ "Store All (" @ %cmnt @ ")", %type @ " store " @ %item @ " " @ %cmnt);
		}

	Client::addMenuItem(%clientId, "bBack", %type @ " back " @ %item @ " " @ %mode);
	Client::addMenuItem(%clientId, "xFinished", "ineedanextrawordsothisisithaha done");
	return;
}

function processMenuSellBeltItemFinal(%clientId, %opt)
{
	%type = GetWord(%opt, 0);
	%option = GetWord(%opt, 1);
	
	// Check for menu closure option first, before validating other parameters
	if(%type == "ineedanextrawordsothisisithaha" || %option == "done")
	{
		// Clear the belt sell flag and stored order when menu is closed
		%clientId.currentBeltSell = "";
		// Clear stored orders for all belt types
		for(%i = 1; $Belt::Categories[%i] != ""; %i++)
		{
			%clientId.beltItemOrder[$Belt::Categories[%i]] = "";
			%clientId.beltStoredItemOrder[$Belt::Categories[%i]] = "";
		}
		Client::CancelMenu(%clientId);
		return;
	}
	
	%item = GetWord(%opt, 2);
	%amnt = GetWord(%opt, 3);
	
	// Validate parameters
	if(%item == "" || %item == -1)
	{
		%clientName = Client::getName(%clientId);
		echo("ERROR: processMenuSellBeltItemFinal - Invalid item parameter: '" @ %item @ "' from option: '" @ %opt @ "' ClientId: " @ %clientId @ " (" @ %clientName @ ")");
		return;
	}
	if(%amnt == "" || %amnt == -1)
	{
		%clientName = Client::getName(%clientId);
		echo("ERROR: processMenuSellBeltItemFinal - Invalid amount parameter: '" @ %amnt @ "' from option: '" @ %opt @ "' ClientId: " @ %clientId @ " (" @ %clientName @ ")");
		return;
	}
	%amnt = floor(%amnt); // Ensure %amnt is a number
	
	if(%option == "back")
	{
		%mode = GetWord(%opt, 3);
		if(%mode == "sell")
			MenuSellBeltItem(%clientId, %type, 1);
		else if(%mode == "store")
		{
			// Check if storing to banker or belt storage
			if(%clientId.currentBeltBank != "")
				Belt::ShowDepositMenu(%clientId);
			else
				MenuBeltStoreThisItem(%clientId, %type, 1, %mode);
		}
		else if(%mode == "withdraw")
		{
			// Check if withdrawing from banker or belt storage
			if(%clientId.currentBeltBank != "")
				Belt::ShowWithdrawMenu(%clientId);
			else
				MenuBeltWithdrawThisItem(%clientId, %type, 1, %mode);
		}
		return;
	}
	else if(%option == "sell")
	{
		%cmnt = Belt::HasThisStuff(%clientId, %item);
		if(%cmnt >= %amnt)
		{
			%cost = Belt::GetSellCost(%clientId, %item) * %amnt;
			Client::sendMessage(%clientId, $MsgWhite, "You sold " @ %amnt @ " " @ %item @ " for " @ %cost @ " coins.");
			UseSkill(%clientId, $SkillHaggling, true, true);
			storeData(%clientId, "COINS", %cost, "inc");
			Belt::TakeThisStuff(%clientId, %item, %amnt);
			RefreshAll(%clientId);
			%clientId.bulkNum = 1;
			// Save character after selling to ensure coins and item changes are persisted
			SaveCharacter(%clientId);
			// Return to sell menu after selling
			MenuSellBeltItem(%clientId, %type, 1);
		}
	}
	else if(%option == "store")
	{
		// Get the registered item name (what's actually stored in the equipped category)
		%registeredItem = $BeltItem[%item, "Item"];
		if(%registeredItem == "")
		{
			%clientName = Client::getName(%clientId);
			echo("ERROR: Belt deposit - Item '" @ %item @ "' not found in belt item registry! ClientId: " @ %clientId @ " (" @ %clientName @ ")");
			return;
		}
		
		%cmnt = Belt::HasThisStuff(%clientId, %item);
		if(%cmnt >= %amnt)
		{
			// Check if storing to banker (BeltStorage) or to belt storage (old system)
			if(%clientId.currentBeltBank != "")
			{
				// Storing to banker - work directly with BeltStorage as single source of truth
				%beltStorage = fetchData(%clientId, "BeltStorage");
				
				// Normalize "0" to empty string
				if(%beltStorage == "0" || %beltStorage == " ")
					%beltStorage = "";
				
				// Clean BeltStorage before adding to remove any invalid entries
				%cleanedStorage = "";
				for(%i = 0; GetWord(%beltStorage, %i) != -1; %i += 2)
				{
					%itemName = GetWord(%beltStorage, %i);
					%itemCount = GetWord(%beltStorage, %i + 1);
					%countNum = %itemCount * 1;
					if(%itemName != "" && %itemName != -1 && %itemName != "0" && %itemCount != "" && %itemCount != -1 && %itemCount != "-1" && %itemCount != "0" && %countNum > 0)
						%cleanedStorage = %cleanedStorage @ %itemName @ " " @ %itemCount @ " ";
				}
				%len = String::len(%cleanedStorage);
				if(%len > 0 && String::getSubStr(%cleanedStorage, %len-1, 1) == " ")
					%cleanedStorage = String::getSubStr(%cleanedStorage, 0, %len-1);
				%beltStorage = %cleanedStorage;
				
				// Count unique items in BeltStorage
				%currentStorageCount = 0;
				for(%i = 0; GetWord(%beltStorage, %i) != -1; %i += 2)
				{
					%itemName = GetWord(%beltStorage, %i);
					if(%itemName != "" && %itemName != -1 && %itemName != "0")
						%currentStorageCount++;
				}
				
				if(%currentStorageCount < 25)
				{
					// Add item directly to BeltStorage (single source of truth)
					%newBeltStorage = SetStuffString(%beltStorage, %registeredItem, %amnt);
					
					// Clean result after SetStuffString to remove any "0" entries
					%cleanedResult = "";
					for(%i = 0; GetWord(%newBeltStorage, %i) != -1; %i += 2)
					{
						%itemName = GetWord(%newBeltStorage, %i);
						%itemCount = GetWord(%newBeltStorage, %i + 1);
						%countNum = %itemCount * 1;
						if(%itemName != "" && %itemName != -1 && %itemName != "0" && %itemCount != "" && %itemCount != -1 && %itemCount != "-1" && %itemCount != "0" && %countNum > 0)
							%cleanedResult = %cleanedResult @ %itemName @ " " @ %itemCount @ " ";
					}
					%len = String::len(%cleanedResult);
					if(%len > 0 && String::getSubStr(%cleanedResult, %len-1, 1) == " ")
						%cleanedResult = String::getSubStr(%cleanedResult, 0, %len-1);
					
					// Save cleaned BeltStorage
					storeData(%clientId, "BeltStorage", %cleanedResult);
					
					// Remove from equipped belt
					Belt::TakeThisStuff(%clientId, %item, %amnt);
					
					%clientId.bulkNum = 1;
					RefreshAll(%clientId);
					SaveCharacter(%clientId);
					
					%itemName = $BeltItem[%registeredItem, "Name"];
					if(%itemName == "")
					{
						// Fallback to AccessoryVar for non-belt items
						%itemName = $AccessoryVar[%registeredItem, $Name];
						if(%itemName == "")
							%itemName = %registeredItem;
					}
					Client::sendMessage(%clientId, $MsgGreen, "Deposited " @ %amnt @ " " @ %itemName @ " into backpack storage.");
					
					// Clear stored order so menu rebuilds with current items
					%clientId.beltDepositItemOrder = "";
					
					// Return to deposit menu
					Belt::ShowDepositMenu(%clientId);
				}
				else
				{
					Client::sendMessage(%clientId, $MsgRed, "You can only place 25 different items into backpack storage.~wC_BuySell.wav");
				}
			}
			else
			{
				// Storing to belt storage (old system)
				if(CountObjInList(fetchData(%clientId, "Stored" @ %type)) / 2 < 25)
				{		
					storeData(%clientId, "Stored" @ %type, SetStuffString(fetchData(%clientId, "Stored" @ %type), %registeredItem, %amnt));
					Belt::TakeThisStuff(%clientId, %item, %amnt);
					%clientId.bulkNum = 1;
					RefreshAll(%clientId);
					SaveCharacter(%clientId);
					MenuBeltStoreThisItem(%clientId, %type, 1, "store");
				}
				else
				{
					Client::sendMessage(%clientId, $MsgRed, "You can only place 25 different items into the " @ Belt::Display(%type) @ " storage.~wC_BuySell.wav");
				}
			}
		}
	}
	else if(%option == "withdraw")
	{
		// Get the registered item name (what's actually stored in BeltStorage)
		%registeredItem = $BeltItem[%item, "Item"];
		if(%registeredItem == "")
		{
			// Try using %item directly - it might already be the registered name from BeltStorage
			%registeredItem = %item;
		}
		
		// Check if withdrawing from banker (BeltStorage) or from belt storage (old system)
		if(%clientId.currentBeltBank != "")
		{
			// Withdrawing from banker - work directly with BeltStorage as single source of truth
			%beltStorage = fetchData(%clientId, "BeltStorage");
			
			// Normalize "0" to empty string
			if(%beltStorage == "0" || %beltStorage == " ")
				%beltStorage = "";
			
			// Clean BeltStorage before checking count
			%cleanedStorage = "";
			for(%i = 0; GetWord(%beltStorage, %i) != -1; %i += 2)
			{
				%itemName = GetWord(%beltStorage, %i);
				%itemCount = GetWord(%beltStorage, %i + 1);
				%countNum = %itemCount * 1;
				if(%itemName != "" && %itemName != -1 && %itemName != "0" && %itemCount != "" && %itemCount != -1 && %itemCount != "-1" && %itemCount != "0" && %countNum > 0)
					%cleanedStorage = %cleanedStorage @ %itemName @ " " @ %itemCount @ " ";
			}
			%len = String::len(%cleanedStorage);
			if(%len > 0 && String::getSubStr(%cleanedStorage, %len-1, 1) == " ")
				%cleanedStorage = String::getSubStr(%cleanedStorage, 0, %len-1);
			%beltStorage = %cleanedStorage;
			
			// Check count in BeltStorage
			%cmnt = Belt::ItemCount(%registeredItem, %beltStorage);
			
			if(%cmnt >= %amnt)
			{
				// Remove item directly from BeltStorage
				%newBeltStorage = SetStuffString(%beltStorage, %registeredItem, -%amnt);
				
				// Clean result after SetStuffString to remove any "0" entries
				%cleanedResult = "";
				for(%i = 0; GetWord(%newBeltStorage, %i) != -1; %i += 2)
				{
					%itemName = GetWord(%newBeltStorage, %i);
					%itemCount = GetWord(%newBeltStorage, %i + 1);
					%countNum = %itemCount * 1;
					if(%itemName != "" && %itemName != -1 && %itemName != "0" && %itemCount != "" && %itemCount != -1 && %itemCount != "-1" && %itemCount != "0" && %countNum > 0)
						%cleanedResult = %cleanedResult @ %itemName @ " " @ %itemCount @ " ";
				}
				%len = String::len(%cleanedResult);
				if(%len > 0 && String::getSubStr(%cleanedResult, %len-1, 1) == " ")
					%cleanedResult = String::getSubStr(%cleanedResult, 0, %len-1);
				
				// Save cleaned BeltStorage
				storeData(%clientId, "BeltStorage", %cleanedResult);
				
				// Add to equipped belt
				Belt::GiveThisStuff(%clientId, %item, %amnt, 1);
				
				%clientId.bulkNum = 1;
				RefreshAll(%clientId);
				SaveCharacter(%clientId);
				
				%itemName = $BeltItem[%registeredItem, "Name"];
				if(%itemName == "")
				{
					// Fallback to AccessoryVar for non-belt items
					%itemName = $AccessoryVar[%registeredItem, $Name];
					if(%itemName == "")
						%itemName = %registeredItem;
				}
				Client::sendMessage(%clientId, $MsgGreen, "Withdrew " @ %amnt @ " " @ %itemName @ " from backpack storage.");
				
				// Clear stored order so menu rebuilds with current items
				%clientId.beltWithdrawItemOrder = "";
				
				// Return to withdraw menu
				Belt::ShowWithdrawMenu(%clientId);
			}
			else
			{
				Client::sendMessage(%clientId, $MsgRed, "You don't have enough " @ $BeltItem[%registeredItem, "Name"] @ " in storage.");
			}
		}
		else
		{
			// Withdrawing from belt storage (old system)
			%cmnt = Belt::GetStored(%clientId, %opt);
			if(%cmnt >= %amnt)
			{
				Belt::GiveThisStuff(%clientId, %item, %amnt, 1);
				storeData(%clientId, "Stored" @ %type, SetStuffString(fetchData(%clientId, "Stored" @ %type), %item, -%amnt));
				%clientId.bulkNum = 1;
				RefreshAll(%clientId);
				SaveCharacter(%clientId);
				MenuBeltWithdrawThisItem(%clientId, %opt, 1, "withdraw");
			}
		}
	}
	return;
}
						
function MenuStoreBelt(%clientId, %mode)
{
	Client::buildMenu(%clientId, "Backpack " @ %mode @ ":", "StoreBelt", true);
	if(%mode == "store")
	{
		for(%i = 1; %i < Belt::GetLastItem(); %i++)
		if(!Belt::isEmpty(%clientId, $Belt::Categories[%i]))
		Client::addMenuItem(%clientId, %cnt++ @ Belt::Display($Belt::Categories[%i]), $Belt::Categories[%i] @ " " @ %mode);
		
		Client::addMenuItem(%clientId, "nWithdraw Items", "mode store change");
		Client::addMenuItem(%clientId, "xFinished", "done");
	}
	else
	{
		%mode="withdraw";
		for(%i = 1; %i < Belt::GetLastItem(); %i++)
		{
			%fix = getWord(fetchData(%clientId, "Stored" @ $Belt::Categories[%i]), 2);
			if(%fix != -1)
				Client::addMenuItem(%clientId, %cnt++ @ Belt::Display($Belt::Categories[%i]), $Belt::Categories[%i] @ " " @ %mode);
		}
		
		Client::addMenuItem(%clientId, "nStore Items", "mode withdraw change");
		Client::addMenuItem(%clientId, "xFinished", "done");
	}
	return;
}

function processMenuStoreBelt(%clientId, %opt)
{
	%o = getword(%opt, 0);
	%m = getword(%opt, 1);
	%c = getword(%opt, 2);
	if(%c == "change")
	{
		if(%m == "store")
		MenuStoreBelt(%clientId, "withdraw");
		if(%m == "withdraw")
		MenuStoreBelt(%clientId, "store");
		return;
	}
	if(%m == "store")
	{
		MenuBeltStoreThisItem(%clientId, %o, 1, "store");
		return;
	}
	if(%m == "withdraw")
	{
		MenuBeltWithdrawThisItem(%clientId, %o, 1, "withdraw");
		return;
	}
	return;
}

function Belt::StorageConversion(%clientId)
{
	for(%i=0; getword(fetchData(%clientId, "StorageTruce"), %i) != -1; %i+=2)
	{
		%item = getword(fetchData(%clientId, "StorageTruce"), %i);
		if(isBeltItem(%item))
		{
			%itemcount = getword(fetchData(%clientId, "StorageTruce"), %i+1);
			%a = String::replace(fetchData(%clientId, "StorageTruce"), " " @ %item @ " " @ %itemcount, "");
			%list = String::NEWgetSubStr(%a, 0, 99999);
			storeData(%clientId, "StorageTruce", %list);
			Client::sendMessage(%clientId, $MsgBeige, "Now converting " @ %itemcount @ " " @ %item @ "s to your backpack storage.");
			%type = $BeltItem[%item, "Type"];
			if(%type == "")
				%type = "Other";
			storeData(%clientId, "Stored" @ %type, SetStuffString(fetchData(%clientId, "Stored" @ %type), %item, %itemcount));
		}
	}
}

function Belt::ItemsOnThemConversion(%clientId)
{
	for(%i=0; getword(fetchData(%clientId, "SpawnStuff"), %i) != -1; %i+=2)
	{
		%item = getword(fetchData(%clientId, "SpawnStuff"), %i);
		if(isBeltItem(%item))
		{
			%itemcount = getword(fetchData(%clientId, "SpawnStuff"), %i+1);
			%a = String::replace(fetchData(%clientId, "SpawnStuff"), " " @ %item @ " " @ %itemcount, "");
			%list = String::NEWgetSubStr(%a, 0, 99999);
			storeData(%clientId, "SpawnStuff", %list);
			Client::sendMessage(%clientId, $MsgBeige, "Now converting " @ %itemcount @ " " @ %item @ "s to your backpack storage.");
			%type = $BeltItem[%item, "Type"];
			if(%type == "")
				%type = "Other";
			storeData(%clientId, "Stored" @ %type, SetStuffString(fetchData(%clientId, "Stored" @ %type), %item, %itemcount));
		}
	}
}

function Belt::GetWeight(%clientId)
{
	//== HELPS REDUCE LAG WHEN THERE ARE SIMULTANEOUS CALLS ======
	%time = getIntegerTime(true);
	if(%time - %clientId.lastGetBeltWeight <= 1 && fetchData(%clientId, "tmpBeltWeight") != "")
	{
		%cached = fetchData(%clientId, "tmpBeltWeight");
		return %cached;
	}
	%clientId.lastGetBeltWeight = %time;
	//============================================================
	
	%weight = 0;
	for(%i = 1; $Belt::Categories[%i] != ""; %i++)
	{
		%category = $Belt::Categories[%i];
		%string = fetchData(%clientId, %category);
		for(%j = 0; (%item = GetWord(%string, %j)) != -1; %j+=2)
		{
			%count = GetWord(%string, %j+1);
			if(%item == "" || %item == -1 || %item == "0")
			{
				continue;
			}
			
			%itemWeight = $AccessoryVar[%item, $Weight];
			%addWeight = %itemWeight * %count;
			%weight += %addWeight;
		}
	}
	storeData(%clientId, "tmpBeltWeight", %weight);
	return %weight;
}

function Belt::GetNS(%clientId, %type)
{
	%count = 0;
	%stuff = fetchData(%clientId, %type);
	
	// CRITICAL FIX: Detect and fix missing spaces between count and item
	// Corrupted data like "2AlienSpine Enchanted Stone" needs to be fixed
	// Pattern: If a word starts with a digit and contains letters immediately after, it's corrupted
	// IMPORTANT: Only process words that actually start with a digit (0-9), not letters
	// This must be very strict to avoid false positives (e.g., "EnchantedStone" should NEVER be processed)
	%wasCorrupted = false;
	%fixedStuff = "";
	
	// Process words in pairs (item name, count)
	// Belt storage format is: "item1 count1 item2 count2 ..."
	for(%i = 0; GetWord(%stuff, %i) != -1; %i += 2)
	{
		%item = GetWord(%stuff, %i);
		%count = GetWord(%stuff, %i + 1);
		
		// If count is missing (end of string), item is corrupted or malformed
		if(%count == -1 || %count == "")
		{
			// Check if the item word itself looks corrupted (starts with digit + has letters)
			%firstChar = String::getSubStr(%item, 0, 1);
			if(%firstChar >= "0" && %firstChar <= "9" && String::len(%item) > 1)
			{
				// Try to split count from item (e.g., "2AlienSpine" -> "2" and "AlienSpine")
				%splitPoint = -1;
				for(%j = 1; %j < String::len(%item); %j++)
				{
					%char = String::getSubStr(%item, %j, 1);
				if((%char >= "a" && %char <= "z") || (%char >= "A" && %char <= "Z"))
				{
						%splitPoint = %j;
					break;
				}
					// Stop if we hit a non-digit
					if(%char < "0" || %char > "9")
						break;
				}
				
				if(%splitPoint > 0)
				{
					%countPart = String::getSubStr(%item, 0, %splitPoint);
					%itemPart = String::getSubStr(%item, %splitPoint, 99999);
					
					// Validate count part is numeric
					%countNumeric = %countPart * 1;
					if(%countNumeric == %countPart && %countPart != "")
					{
						// Valid corruption - separate count and item
				if(%fixedStuff != "")
					%fixedStuff = %fixedStuff @ " ";
						%fixedStuff = %fixedStuff @ %itemPart @ " " @ %countPart;
						%wasCorrupted = true;
						continue;
					}
				}
			}
			// Not corrupted or couldn't split - skip this malformed entry
			continue;
		}
		
		// Check if count looks like it might be merged with next item (count is non-numeric but item-like)
		%countNumeric = %count * 1;
		if(%countNumeric != %count && %count != "" && %count != -1)
		{
			// Count is non-numeric - might be corrupted
			// Try to split count from next item if it starts with digit
			%nextItem = GetWord(%stuff, %i + 2);
			if(%nextItem != -1 && %nextItem != "")
			{
				%firstChar = String::getSubStr(%nextItem, 0, 1);
				if(%firstChar >= "0" && %firstChar <= "9")
				{
					// Next word starts with digit - might be count merged with item after that
					// This is complex corruption, skip for now
				}
			}
		}
		
		// Normal entry - add item and count as-is
			if(%fixedStuff != "")
				%fixedStuff = %fixedStuff @ " ";
		%fixedStuff = %fixedStuff @ %item @ " " @ %count;
	}
	
	// If corruption was fixed, use the fixed list and log it
	if(%wasCorrupted)
	{
		%clientName = Client::getName(%clientId);
		echo("CRITICAL: Belt::GetNS - Fixed corrupted data in " @ %type @ " (missing spaces between count and item). ClientId: " @ %clientId @ " (" @ %clientName @ ")");
		echo("  Original: '" @ %stuff @ "'");
		echo("  Fixed: '" @ %fixedStuff @ "'");
		%stuff = %fixedStuff;
	}
	
	// Clean up invalid entries (item "0", empty items, count 0 or negative)
	// Handle corrupted lists by iterating word-by-word and properly pairing items with counts
	%cleanedStuff = "";
	%hasInvalidEntries = false;
	for(%i = 0; GetWord(%stuff, %i) != -1; %i += 2)
	{
		%item = GetWord(%stuff, %i);
		%itemCount = GetWord(%stuff, %i + 1);
		
		// Skip invalid entries
		if(%item == "" || %item == -1 || %item == "0" || %itemCount == "" || %itemCount == -1 || %itemCount == "0" || %itemCount == "-1" || (%itemCount * 1) <= 0)
		{
			%hasInvalidEntries = true;
			continue;
		}
		
		// Add valid entry
		if(%cleanedStuff != "")
			%cleanedStuff = %cleanedStuff @ " ";
		%cleanedStuff = %cleanedStuff @ %item @ " " @ %itemCount;
	}
	
	// If we cleaned invalid entries, save the cleaned version back
	if(%hasInvalidEntries)
	{
		%len = String::len(%cleanedStuff);
		if(%len > 0 && String::getSubStr(%cleanedStuff, %len-1, 1) == " ")
			%cleanedStuff = String::getSubStr(%cleanedStuff, 0, %len-1);
		storeData(%clientId, %type, %cleanedStuff);
		%stuff = %cleanedStuff;
	}
	else
	{
		// Use original stuff if no cleaning was needed
		%cleanedStuff = %stuff;
	}
	
	// Build list from cleaned stuff (items that passed validation)
	%list = "";
	%count = 0;
	for(%i = 0; GetWord(%cleanedStuff, %i) != -1; %i+=2)
	{
		%item = GetWord(%cleanedStuff, %i);
		%itemCount = GetWord(%cleanedStuff, %i+1);
		// Only add valid entries (already validated in cleanup loop above)
		if(%item != "" && %item != -1 && %item != "0" && %itemCount > 0)
		{
			%list = %list @ " " @ %item;
			%count++;
		}
	}
	
	return %count @ " " @ %list;
}

function Belt::GetSellCost(%clientId, %item)
{
	%p = $HardcodedItemCost[%item];
	%cost = round(%p * ($resalePercentage/100));

	%p = round($PlayerSkill[%clientId, $SkillHaggling] / 11) / 100;
	%x = round(%cost * Cap(%p, 0.0, 1.0) );
	%cost += %x;

	return %cost;
}

function Belt::HasThisStuff(%clientId, %item)
{
	%item = $BeltItem[%item, "Item"];
	%type = $BeltItem[%item, "Type"];
	%list = fetchData(%clientId, %type);
	%amnt = Belt::ItemCount(%item, %list);
	return %amnt;
}

//==========================//
//====== MUG BELT END ======//
//==========================//

function Belt::GiveThisStuff(%clientId, %item, %amnt, %echo)
{
	// Check if this is an enemy bot early - bots need optimized path with fewer checks
	%isBot = isRPGAI(%clientId);
	
	if(%amnt > 0)
	{
		%originalItem = %item;
		%item = $BeltItem[%item, "Item"];
		%type = $BeltItem[%item, "Type"];
		
		// Validate that the item was found in the belt item registry (for all players, not just AI)
		if(%item == "" || %type == "")
		{
			if(!%isBot)
			{
				%clientName = Client::getName(%clientId);
				echo("ERROR: Belt::GiveThisStuff - Item '" @ %originalItem @ "' not found in belt item registry for " @ %clientName @ " (ClientId: " @ %clientId @ ")");
				echo("  Lookup result: item='" @ %item @ "', type='" @ %type @ "'");
			}
			return;
		}
		
		%list = fetchData(%clientId, %type);
		
		// For enemy bots: Skip corruption checks and GetNS to reduce load
		// Bots are controlled by server, corruption is unlikely, and GetNS causes race conditions
		if(%isBot)
		{
			// Fast path for bots: minimal validation, skip GetNS, skip most debug output
			// Only handle basic "0" entry cleanup
			if(GetWord(%list, 0) == "0" && GetWord(%list, 1) == "")
			{
				%list = "";
				storeData(%clientId, %type, "");
			}
		}
		else
		{
			// Full path for players: corruption checks, GetNS cleanup, full debug output
			// Clean up corrupted entries before processing (items starting with "0", empty, invalid counts, etc.)
			%testItem = GetWord(%list, 0);
			%testCount = GetWord(%list, 1);
			%isCorrupted = False;
			if(%testItem != "" && %testItem != -1)
			{
				// Try to get count for the first item - if it's non-numeric, the list is corrupted
				%testLookup = Belt::ItemCount(%testItem, %list);
				%testNumeric = %testLookup * 1;
				if(%testLookup != "" && %testNumeric != %testLookup && %testLookup != "0")
				{
					// Count is non-numeric - list is severely corrupted
					%clientName = Client::getName(%clientId);
					echo("CRITICAL: Belt::GiveThisStuff - List for " @ %type @ " is severely corrupted (non-numeric count: '" @ %testLookup @ "'). Resetting category.");
					echo("  Corrupted list: '" @ %list @ "'");
					%isCorrupted = True;
					%list = "";
					storeData(%clientId, %type, "");
				}
			}
			
			// For players: Use Belt::GetNS to clean and rebuild
			if(!%isCorrupted)
			{
				%nsResult = Belt::GetNS(%clientId, %type);
				%itemCount = GetWord(%nsResult, 0);
				
				// Use the cleaned list that Belt::GetNS just saved
				%cleanedList = fetchData(%clientId, %type);
				
				// If the cleaned list is just "0" or invalid, treat it as empty
				if(%cleanedList == "0" || (GetWord(%cleanedList, 0) == "0" && GetWord(%cleanedList, 1) == ""))
				{
					%cleanedList = "";
					storeData(%clientId, %type, "");
				}
				
				%list = %cleanedList;
			}
		}
		
		%count = Belt::ItemCount(%item, %list);
		
		// If items exist in equipped category when picking up from lootbag,
		// consolidate them normally with the picked up items.
		// This is normal if picking up an enemy lootbag while alive.
		// Only log a warning if count is suspiciously high (> 100) to flag potential duplication issues,
		// but still consolidate normally (don't erase items)
		if(%count > 0 && !%isBot)
		{
			if(%count > 100)
			{
				// Suspiciously high count - log a warning but still consolidate
			%clientName = Client::getName(%clientId);
				echo("WARNING: Belt::GiveThisStuff - Item '" @ %item @ "' has suspiciously high count (" @ %count @ ") in " @ %type @ " when picking up from lootbag! ClientId: " @ %clientId @ " (" @ %clientName @ ")");
				echo("  This may indicate duplication/corruption, but items will still be consolidated normally.");
			echo("  Current list: '" @ %list @ "'");
			}
		}

		if(%echo && !%isBot) Client::sendMessage(%clientId, 0, "You received " @ %amnt @ " " @ $BeltItem[%item, "Name"] @ ".");

		if(%count > 0)
		{
			%list = Belt::RemoveFromList(%list, %item @ " " @ %count);
			%amnt = %amnt + %count;
		}
		%list = Belt::AddToList(%list, %item @ " " @ %amnt);
		
		// Remove trailing space that Belt::AddToList adds
		%len = String::len(%list);
		if(%len > 0 && String::getSubStr(%list, %len-1, 1) == " ")
			%list = String::getSubStr(%list, 0, %len-1);

		storeData(%clientId, %type, %list);
		%allBelt = fetchData(%clientId, "QuestItems") @ fetchData(%clientId, "KeyItems");
		storeData(%clientId, "AllBelt", %allBelt);
	}
}

//==========================//
//======MUG BELT START======//
//==========================//
// TEMPORARILY DISABLED - Belt::Mug functions
//function Belt::Mug(%clientId, %id)
//{
//	%clientId.MugID=%id;
//	Belt::MugBeltMain(%clientId, %id);
//	client::sendmessage(%clientId, "You are belt mugging");
//}
//function Belt::MugBeltMain(%clientId, %id)
//{
//	Client::buildMenu(%clientId, client::getname(%id) @ "'s Belt:", "MugBeltMain", true);
//	for(%i = 1; %i < Belt::GetLastItem(); %i++)
//	if(!Belt::isEmpty(%clientId, $Belt::Categories[%i]) > 0)
//	Client::addMenuItem(%clientId, %cnt++ @ Belt::Display($Belt::Categories[%i]), $Belt::Categories[%i]);	
//	Client::addMenuItem(%clientId, "xDone", "done");
//	return;
//}
//function processMenuMugBeltMain(%clientId, %opt)
//{
//	%o = GetWord(%opt, 0);
//	%p = GetWord(%opt, 1);
//
//	if($Belt::Count[%o] > 0)
//	{
//		MenuBelt::MugThisType(%clientId, %o, 1);
//		return;
//	}
//	return;
//}
//function MenuBelt::MugThisType(%clientId, %type, %page)
//{
//	%id=%clientId.MugId;
//	%disp = Belt::Display(%type);
//
//	Client::buildMenu(%clientId, %disp @ ":", "Belt::MugThisType", true);
//	%clientId.bulkNum = "";
//
//	%l = 6;
//	%nx = $Belt::Count[%type];
//	%nf = Belt::GetNS(%id, %type);
//	%ns = GetWord(%nf, 0);
//	%np = floor(%ns / %l);
//	%lb = (%page * %l) - (%l-1);
//	%ub = %lb + (%l-1);
//	if(%ub > %ns)
//	%ub = %ns;
//
//	%x = %lb - 1;
//	for(%i = %lb; %i <= %ub; %i++)
//	{
//		%x++;
//		%item = getword(%nf, %x);
//		%amnt = Belt::HasThisStuff(%id, %item);
//		Client::addMenuItem(%clientId, %cnt++ @ %amnt @ " " @ $BeltItem[%item, "Name"], %item @ " " @ %page @ " " @ %type);
//	}
//
//	if(%page == 1)
//	{
//		if(%ns > 6) Client::addMenuItem(%clientId, "nNext >>", "page " @ %page+1 @ " " @ %type);
//		Client::addMenuItem(%clientId, "xDone", "done");
//	}
//	else if(%page == %np+1)
//	{
//		Client::addMenuItem(%clientId, "p<< Prev", "page " @ %page-1 @ " " @ %type);
//		Client::addMenuItem(%clientId, "xDone", "done");
//	}
//	else
//	{
//		Client::addMenuItem(%clientId, "nNext >>", "page " @ %page+1 @ " " @ %type);
//		Client::addMenuItem(%clientId, "p<< Prev", "page " @ %page-1 @ " " @ %type);
//	}
//
//	return;
//}
//function processMenuBelt::MugThisType(%clientId, %opt)
//{
//	%o = GetWord(%opt, 0);
//	%p = GetWord(%opt, 1);
//	%t = GetWord(%opt, 2);
//
//	if(%o != "page" && %o != "done")
//	{
//		%clientId.bulkNum = 1;
//
//		MenuBelt::MugChoose(%clientId, %o, %t);
//		return;
//	}
//
//	return;
//}
//function MenuBelt::MugChoose(%clientId, %item, %type)
//{
//	%id=%clientId.MugId;
//	%name = $BeltItem[%item, "Name"];
//	%amnt = %clientId.bulkNum;
//	%cmnt = Belt::HasThisStuff(%id, %item);
//
//	if(%amnt > %cmnt)
//	%amnt = %cmnt;
//
//	Client::buildMenu(%clientId, %name @ " (" @ %cmnt @ ")", "Belt::MugChoose", true);
//
//	Client::addMenuItem(%clientId, %cnt++ @ "Mug " @ %item, %type @ " MUG " @ %item @ " 1");
//	Client::addMenuItem(%clientId, %cnt++ @ "Examine", %type @ " examine " @ %item);
//	Client::addMenuItem(%clientId, %cnt++ @ "Back", %type @ " back " @ %item);
//	Client::addMenuItem(%clientId, "xDone", "done");
//	return;
//}
//
//function processMenuBelt::MugChoose(%clientId, %opt)
//{
//	%type = GetWord(%opt, 0);
//	%option = GetWord(%opt, 1);
//	%item = GetWord(%opt, 2);
//
//	if(%option == "MUG")
//	{
//		Client::sendMessage(%clientId, $MsgBeige, "Attempting to Mug " @ client::getName(%clientId.MugId) @ "'s belt...");
//		schedule("Belt::MugItem(" @ %clientId @ ", " @ %item @ ", " @ %type @ ");", 5);
//	}
//	else if(%option == "examine")
//	{
//		%msg = WhatIs(%item);
//		bottomprint(%clientId, %msg, floor(String::len(%msg) / 20));
//		MenuBelt::MugChoose(%clientId, %item, %type);
//	}
//	else if(%option == "back")
//	{
//		MenuBelt::MugThisType(%clientId, %option, 1);
//	}
//	return;
//}
//function Belt::MugItem(%clientId, %item, %type)
//{
//	%cl=%clientId.MugId;
//	%list = fetchData(%cl, %type);
//	%victimName = Client::getName(%cl);
//	%stealerName = Client::getName(%clientId);
//
//	for(%i=0; getword(fetchData(%cl, %type), %i) != -1; %i+=2)
//	{
//		if(getword(fetchData(%cl, %type), %i) == %item)
//		%icnt = getword(fetchData(%cl, %type), %i+1);
//	}
//	%clientId.TryingToSteal = "";
//
//	//weights
//	%itemweight = GetAccessoryVar(%item, $Weight);
//	%wweight = 10;
//	if(Player::getMountedItem(%clientId, $WeaponSlot) == %item || %item.className == Equipped)
//	%handweight = 5.0;
//	else
//	%handweight = 1.0;
//	%FailWeight = (%itemweight * %wweight) * %handweight;
//
//	if(Vector::getDistance(GameBase::getPosition(%clientId), GameBase::getPosition(%cl)) > 2)
//	Client::sendMessage(%clientId, $MsgWhite, "Your target has wandered off...");
//	else
//	{
//		%r1 = GetRoll("1d" @ $PlayerSkill[%clientId, $SkillStealing]);
//		%r2 = GetRoll("1d" @ ($PlayerSkill[%cl, $SkillStealing] + $PlayerSkill[%cl, $SkillDodging]));
//		%b = %r1 - %r2;
//		%a = %b - %FailWeight;
//		if(%a > 0 && %icnt > 0)
//		{
//			%newcnt = %icnt-1;
//			Client::sendMessage(%clientId, $MsgBeige, "You successfully stole a " @ %item @ " from " @ %victimName @ "!");
//			Belt::TakeThisStuff(%cl, %item, 1);
//			Belt::GiveThisStuff(%clientId, %item, 1);
//			PerhapsPlayStealSound(%clientId, %clientId.stealType);
//
//			if(%newcnt > 0)
//			MenuBelt::MugChoose(%clientId, %item, %type);
//
//			RefreshAll(%clientId);
//			RefreshAll(%cl);
//
//			UseSkill(%clientId, $SkillStealing, true, true);
//			PostSteal(%clientId, true, %clientId.stealType);
//
//			return true;
//		}
//		else
//		{
//			Client::CancelMenu(%clientId);
//			Client::sendMessage(%clientId, $MsgRed, "You failed to mug " @ %victimName @ "'s belt!");
//			Client::sendMessage(%cl, $MsgRed, %stealerName @ " just failed to mug your belt!");
//
//			UseSkill(%clientId, $SkillStealing, false, true);
//			PostSteal(%clientId, false, %clientId.stealType);
//		}
//	}
//
//	//force kick from Inv Screen
//	remotePlayMode(%clientId);
//
//	return false;
//}
//==========================//
//====== MUG BELT END ======//
//==========================//

// ------------------- //
// Non Menu Functions  //
// ------------------- //

//==========================//
//======MUG BELT START======//
//==========================//
// TEMPORARILY DISABLED - Belt::Mug functions
//function Belt::Mug(%clientId, %id)
//{
//	%clientId.MugID=%id;
//	Belt::MugBeltMain(%clientId, %id);
//	client::sendmessage(%clientId, "You are belt mugging");
//}
//function Belt::MugBeltMain(%clientId, %id)
//{
//	Client::buildMenu(%clientId, client::getname(%id) @ "'s Belt:", "MugBeltMain", true);
//	for(%i = 1; %i < Belt::GetLastItem(); %i++)
//	if(!Belt::isEmpty(%clientId, $Belt::Categories[%i]) > 0)
//	Client::addMenuItem(%clientId, %cnt++ @ Belt::Display($Belt::Categories[%i]), $Belt::Categories[%i]);	
//	Client::addMenuItem(%clientId, "xDone", "done");
//	return;
//}
//function processMenuMugBeltMain(%clientId, %opt)
//{
//	%o = GetWord(%opt, 0);
//	%p = GetWord(%opt, 1);
//
//	if($Belt::Count[%o] > 0)
//	{
//		MenuBelt::MugThisType(%clientId, %o, 1);
//		return;
//	}
//	return;
//}
//function MenuBelt::MugThisType(%clientId, %type, %page)
//{
//	%id=%clientId.MugId;
//	%disp = Belt::Display(%type);
//
//	Client::buildMenu(%clientId, %disp @ ":", "Belt::MugThisType", true);
//	%clientId.bulkNum = "";
//
//	%l = 6;
//	%nx = $Belt::Count[%type];
//	%nf = Belt::GetNS(%id, %type);
//	%ns = GetWord(%nf, 0);
//	%np = floor(%ns / %l);
//	%lb = (%page * %l) - (%l-1);
//	%ub = %lb + (%l-1);
//	if(%ub > %ns)
//	%ub = %ns;
//
//	%x = %lb - 1;
//	for(%i = %lb; %i <= %ub; %i++)
//	{
//		%x++;
//		%item = getword(%nf, %x);
//		%amnt = Belt::HasThisStuff(%id, %item);
//		Client::addMenuItem(%clientId, %cnt++ @ %amnt @ " " @ $BeltItem[%item, "Name"], %item @ " " @ %page @ " " @ %type);
//	}
//
//	if(%page == 1)
//	{
//		if(%ns > 6) Client::addMenuItem(%clientId, "nNext >>", "page " @ %page+1 @ " " @ %type);
//		Client::addMenuItem(%clientId, "xDone", "done");
//	}
//	else if(%page == %np+1)
//	{
//		Client::addMenuItem(%clientId, "p<< Prev", "page " @ %page-1 @ " " @ %type);
//		Client::addMenuItem(%clientId, "xDone", "done");
//	}
//	else
//	{
//		Client::addMenuItem(%clientId, "nNext >>", "page " @ %page+1 @ " " @ %type);
//		Client::addMenuItem(%clientId, "p<< Prev", "page " @ %page-1 @ " " @ %type);
//	}
//
//	return;
//}
//function processMenuBelt::MugThisType(%clientId, %opt)
//{
//	%o = GetWord(%opt, 0);
//	%p = GetWord(%opt, 1);
//	%t = GetWord(%opt, 2);
//
//	if(%o != "page" && %o != "done")
//	{
//		%clientId.bulkNum = 1;
//
//		MenuBelt::MugChoose(%clientId, %o, %t);
//		return;
//	}
//
//	return;
//}
//function MenuBelt::MugChoose(%clientId, %item, %type)
//{
//	%id=%clientId.MugId;
//	%name = $BeltItem[%item, "Name"];
//	%amnt = %clientId.bulkNum;
//	%cmnt = Belt::HasThisStuff(%id, %item);
//
//	if(%amnt > %cmnt)
//	%amnt = %cmnt;
//
//	Client::buildMenu(%clientId, %name @ " (" @ %cmnt @ ")", "Belt::MugChoose", true);
//
//	Client::addMenuItem(%clientId, %cnt++ @ "Mug " @ %item, %type @ " MUG " @ %item @ " 1");
//	Client::addMenuItem(%clientId, %cnt++ @ "Examine", %type @ " examine " @ %item);
//	Client::addMenuItem(%clientId, %cnt++ @ "Back", %type @ " back " @ %item);
//	Client::addMenuItem(%clientId, "xDone", "done");
//	return;
//}
//
//function processMenuBelt::MugChoose(%clientId, %opt)
//{
//	%type = GetWord(%opt, 0);
//	%option = GetWord(%opt, 1);
//	%item = GetWord(%opt, 2);
//
//	if(%option == "MUG")
//	{
//		Client::sendMessage(%clientId, $MsgBeige, "Attempting to Mug " @ client::getName(%clientId.MugId) @ "'s belt...");
//		schedule("Belt::MugItem(" @ %clientId @ ", " @ %item @ ", " @ %type @ ");", 5);
//	}
//	else if(%option == "examine")
//	{
//		%msg = WhatIs(%item);
//		bottomprint(%clientId, %msg, floor(String::len(%msg) / 20));
//		MenuBelt::MugChoose(%clientId, %item, %type);
//	}
//	else if(%option == "back")
//	{
//		MenuBelt::MugThisType(%clientId, %option, 1);
//	}
//	return;
//}
//function Belt::MugItem(%clientId, %item, %type)
//{
//	%cl=%clientId.MugId;
//	%list = fetchData(%cl, %type);
//	%victimName = Client::getName(%cl);
//	%stealerName = Client::getName(%clientId);
//
//	for(%i=0; getword(fetchData(%cl, %type), %i) != -1; %i+=2)
//	{
//		if(getword(fetchData(%cl, %type), %i) == %item)
//		%icnt = getword(fetchData(%cl, %type), %i+1);
//	}
//	%clientId.TryingToSteal = "";
//
//	//weights
//	%itemweight = GetAccessoryVar(%item, $Weight);
//	%wweight = 10;
//	if(Player::getMountedItem(%clientId, $WeaponSlot) == %item || %item.className == Equipped)
//	%handweight = 5.0;
//	else
//	%handweight = 1.0;
//	%FailWeight = (%itemweight * %wweight) * %handweight;
//
//	if(Vector::getDistance(GameBase::getPosition(%clientId), GameBase::getPosition(%cl)) > 2)
//	Client::sendMessage(%clientId, $MsgWhite, "Your target has wandered off...");
//	else
//	{
//		%r1 = GetRoll("1d" @ $PlayerSkill[%clientId, $SkillStealing]);
//		%r2 = GetRoll("1d" @ ($PlayerSkill[%cl, $SkillStealing] + $PlayerSkill[%cl, $SkillDodging]));
//		%b = %r1 - %r2;
//		%a = %b - %FailWeight;
//		if(%a > 0 && %icnt > 0)
//		{
//			%newcnt = %icnt-1;
//			Client::sendMessage(%clientId, $MsgBeige, "You successfully stole a " @ %item @ " from " @ %victimName @ "!");
//			Belt::TakeThisStuff(%cl, %item, 1);
//			Belt::GiveThisStuff(%clientId, %item, 1);
//			PerhapsPlayStealSound(%clientId, %clientId.stealType);
//
//			if(%newcnt > 0)
//			MenuBelt::MugChoose(%clientId, %item, %type);
//
//			RefreshAll(%clientId);
//			RefreshAll(%cl);
//
//			UseSkill(%clientId, $SkillStealing, true, true);
//			PostSteal(%clientId, true, %clientId.stealType);
//
//			return true;
//		}
//		else
//		{
//			Client::CancelMenu(%clientId);
//			Client::sendMessage(%clientId, $MsgRed, "You failed to mug " @ %victimName @ "'s belt!");
//			Client::sendMessage(%cl, $MsgRed, %stealerName @ " just failed to mug your belt!");
//
//			UseSkill(%clientId, $SkillStealing, false, true);
//			PostSteal(%clientId, false, %clientId.stealType);
//		}
//	}
//
//	//force kick from Inv Screen
//	remotePlayMode(%clientId);
//
//	return false;
//}
//==========================//
//====== MUG BELT END ======//
//==========================//

function MenuBeltWithdrawThisItem(%clientId, %type, %page, %mode)
{
	%type = getword(%type, 0);
	%disp = Belt::Display(%type);
	
	// Store the original order when first opening the menu (page 1)
	if(%page == 1 && %clientId.beltStoredItemOrder[%type] == "")
	{
		%storedStuff = fetchdata(%clientId, "Stored" @ %type);
		%orderList = "";
		for(%i = 0; (%item = getWord(%storedStuff, %i)) != -1; %i+=2)
		{
			%amnt = getWord(%storedStuff, %i + 1);
			if(%amnt > 0)
			{
				%orderList = %orderList @ " " @ %item;
			}
		}
		%clientId.beltStoredItemOrder[%type] = String::NEWgetSubStr(%orderList, 1, 99999);
	}
	
	Client::buildMenu(%clientId, %disp @ ":", "BeltWithdrawThisItem", true);

	%l = 6;
	%nx = $Belt::Count[%type];
	%nf = fetchdata(%clientId, "Stored" @ %type);
	
	// Use stored order if available
	if(%clientId.beltStoredItemOrder[%type] != "")
	{
		%storedOrder = %clientId.beltStoredItemOrder[%type];
		%orderedList = "";
		%count = 0;
		
		// Build ordered list based on stored order
		for(%i = 0; (%item = getWord(%storedOrder, %i)) != -1; %i++)
		{
			%amnt = Belt::ItemCount(%item, %nf);
			if(%amnt > 0)
			{
				%orderedList = %orderedList @ " " @ %item @ " " @ %amnt;
				%count++;
			}
		}
		%nf = String::NEWgetSubStr(%orderedList, 1, 99999);
		%ns = %count - 1;
	}
	else
	{
		%ns = (CountObjInList(%nf) / 2) - 1;
	}
	
	%np = floor(%ns / %l);
	%lb = (%page * %l) - (%l-1);
	%ub = %lb + (%l-1);
	if(%ub > %ns)
		%ub = %ns;

	%x = (%lb - 1) * 2 + 2;
	for(%i = %lb; %i <= %ub; %i++)
	{	
		%item = getword(%nf, %x);
		%amnt = getword(%nf, %x + 1);
		Client::addMenuItem(%clientId, %cnt++ @ %amnt @ " " @ %item, %item @ " " @ %page @ " " @ %type @ " " @ %mode);
		%x+=2;
	}

	if(%page == 1)
	{
		if(%ns > 6) Client::addMenuItem(%clientId, "nNext >>", "page " @ %page+1 @ " " @ %type @ " " @ %mode);
		Client::addMenuItem(%clientId, "bBack", "back " @ %type @ " " @ %mode);
		Client::addMenuItem(%clientId, "xDone", "done");
	}
	else if(%page == %np+1)
	{
		Client::addMenuItem(%clientId, "p<< Prev", "page " @ %page-1 @ " " @ %type @ " " @ %mode);
		Client::addMenuItem(%clientId, "bBack", "back " @ %type @ " " @ %mode);
		Client::addMenuItem(%clientId, "xDone", "done");
	}
	else
	{
		Client::addMenuItem(%clientId, "nNext >>", "page " @ %page+1 @ " " @ %type @ " " @ %mode);
		Client::addMenuItem(%clientId, "p<< Prev", "page " @ %page-1 @ " " @ %type @ " " @ %mode);
		Client::addMenuItem(%clientId, "bBack", "back " @ %type @ " " @ %mode);
	}

	return;
}
function processMenuBeltWithdrawThisItem(%clientId, %opt)
{
	%o = GetWord(%opt, 0);
	%p = GetWord(%opt, 1);
	%t = GetWord(%opt, 2);
	%mode = getword(%opt, 3);

	if(%o == "back")
	{
		MenuStoreBelt(%clientId, %mode);
		return;
	}

	if(%o != "page" && %o != "done")
	{
		MenuSellBeltItemFinal(%clientId, %o, %t, %mode);
		return;
	}

	if(%o != "done")
	MenuBeltWithdrawThisItem(%clientId, %t, %p, %mode);

	return;
}

function MenuBeltStoreThisItem(%clientId, %type, %page, %mode)
{
	%type = getword(%type, 0);
	%disp = Belt::Display(%type);
	
	%msg = "<jc><f2>To store 'bulk' " @ %disp @ ", please enter your desired 'bulk' number now!\n\n'Bulk' numbers must be greater than 0 and less than 500";
	bottomprint(%clientId, %msg, floor(String::len(%msg) / 20));
	
	// Store the original order when first opening the menu (page 1)
	if(%page == 1 && %clientId.beltItemOrder[%type] == "")
	{
		%stuff = fetchData(%clientId, %type);
		%orderList = "";
		for(%i = 0; (%item = getWord(%stuff, %i)) != -1; %i+=2)
		{
			%amnt = getWord(%stuff, %i + 1);
			if(%amnt > 0)
			{
				%orderList = %orderList @ " " @ %item;
			}
		}
		%clientId.beltItemOrder[%type] = String::NEWgetSubStr(%orderList, 1, 99999);
	}
	
	Client::buildMenu(%clientId, %disp @ ":", "BeltStoreThisItem", true);
	%clientId.bulkNum = "";

	%l = 6;
	%nx = $Belt::Count[%type];
	%nf = Belt::GetNS(%clientId, %type);
	%ns = GetWord(%nf, 0);
	%np = floor(%ns / %l);
	%lb = (%page * %l) - (%l-1);
	%ub = %lb + (%l-1);
	if(%ub > %ns)
	%ub = %ns;

	%x = %lb;
	for(%i = %lb; %i <= %ub; %i++)
	{
		%item = getword(%nf, %x);
		%amnt = Belt::HasThisStuff(%clientId, %item);
		Client::addMenuItem(%clientId, %cnt++ @ %amnt @ " " @ $BeltItem[%item, "Name"], %item @ " " @ %page @ " " @ %type @ " " @ %mode);
		%x++;
	}

	if(%page == 1)
	{
		if(%ns > 6) Client::addMenuItem(%clientId, "nNext >>", "page " @ %page+1 @ " " @ %type @ " " @ %mode);
		Client::addMenuItem(%clientId, "bBack", "back " @ %type @ " " @ %mode);
		Client::addMenuItem(%clientId, "xDone", "done");
	}
	else if(%page == %np+1)
	{
		Client::addMenuItem(%clientId, "p<< Prev", "page " @ %page-1 @ " " @ %type @ " " @ %mode);
		Client::addMenuItem(%clientId, "bBack", "back " @ %type @ " " @ %mode);
		Client::addMenuItem(%clientId, "xDone", "done");
	}
	else
	{
		Client::addMenuItem(%clientId, "nNext >>", "page " @ %page+1 @ " " @ %type @ " " @ %mode);
		Client::addMenuItem(%clientId, "p<< Prev", "page " @ %page-1 @ " " @ %type @ " " @ %mode);
		Client::addMenuItem(%clientId, "bBack", "back " @ %type @ " " @ %mode);
	}

	return;
}
function processMenuBeltStoreThisItem(%clientId, %opt)
{
	%o = GetWord(%opt, 0);
	%p = GetWord(%opt, 1);
	%t = GetWord(%opt, 2);
	%mode = getword(%opt, 3);

	if(%o == "back")
	{
		MenuStoreBelt(%clientId, %mode);
		return;
	}

	if(%o != "page" && %o != "done")
	{
		MenuSellBeltItemFinal(%clientId, %o, %t, %mode);
		return;
	}

	if(%o != "done")
	MenuBeltStoreThisItem(%clientId, %t, %p, %mode);

	return;
}

// ------------------- //
// Non Menu Functions  //
// ------------------- //

//==========================//
//======MUG BELT START======//
//==========================//
// TEMPORARILY DISABLED - Belt::Mug functions
//function Belt::Mug(%clientId, %id)
//{
//	%clientId.MugID=%id;
//	Belt::MugBeltMain(%clientId, %id);
//	client::sendmessage(%clientId, "You are belt mugging");
//}
//function Belt::MugBeltMain(%clientId, %id)
//{
//	Client::buildMenu(%clientId, client::getname(%id) @ "'s Belt:", "MugBeltMain", true);
//	for(%i = 1; %i < Belt::GetLastItem(); %i++)
//	if(!Belt::isEmpty(%clientId, $Belt::Categories[%i]) > 0)
//	Client::addMenuItem(%clientId, %cnt++ @ Belt::Display($Belt::Categories[%i]), $Belt::Categories[%i]);	
//	Client::addMenuItem(%clientId, "xDone", "done");
//	return;
//}
//function processMenuMugBeltMain(%clientId, %opt)
//{
//	%o = GetWord(%opt, 0);
//	%p = GetWord(%opt, 1);
//
//	if($Belt::Count[%o] > 0)
//	{
//		MenuBelt::MugThisType(%clientId, %o, 1);
//		return;
//	}
//	return;
//}
//function MenuBelt::MugThisType(%clientId, %type, %page)
//{
//	%id=%clientId.MugId;
//	%disp = Belt::Display(%type);
//
//	Client::buildMenu(%clientId, %disp @ ":", "Belt::MugThisType", true);
//	%clientId.bulkNum = "";
//
//	%l = 6;
//	%nx = $Belt::Count[%type];
//	%nf = Belt::GetNS(%id, %type);
//	%ns = GetWord(%nf, 0);
//	%np = floor(%ns / %l);
//	%lb = (%page * %l) - (%l-1);
//	%ub = %lb + (%l-1);
//	if(%ub > %ns)
//	%ub = %ns;
//
//	%x = %lb - 1;
//	for(%i = %lb; %i <= %ub; %i++)
//	{
//		%x++;
//		%item = getword(%nf, %x);
//		%amnt = Belt::HasThisStuff(%id, %item);
//		Client::addMenuItem(%clientId, %cnt++ @ %amnt @ " " @ $BeltItem[%item, "Name"], %item @ " " @ %page @ " " @ %type);
//	}
//
//	if(%page == 1)
//	{
//		if(%ns > 6) Client::addMenuItem(%clientId, "nNext >>", "page " @ %page+1 @ " " @ %type);
//		Client::addMenuItem(%clientId, "xDone", "done");
//	}
//	else if(%page == %np+1)
//	{
//		Client::addMenuItem(%clientId, "p<< Prev", "page " @ %page-1 @ " " @ %type);
//		Client::addMenuItem(%clientId, "xDone", "done");
//	}
//	else
//	{
//		Client::addMenuItem(%clientId, "nNext >>", "page " @ %page+1 @ " " @ %type);
//		Client::addMenuItem(%clientId, "p<< Prev", "page " @ %page-1 @ " " @ %type);
//	}
//
//	return;
//}
//function processMenuBelt::MugThisType(%clientId, %opt)
//{
//	%o = GetWord(%opt, 0);
//	%p = GetWord(%opt, 1);
//	%t = GetWord(%opt, 2);
//
//	if(%o != "page" && %o != "done")
//	{
//		%clientId.bulkNum = 1;
//
//		MenuBelt::MugChoose(%clientId, %o, %t);
//		return;
//	}
//
//	return;
//}
//function MenuBelt::MugChoose(%clientId, %item, %type)
//{
//	%id=%clientId.MugId;
//	%name = $BeltItem[%item, "Name"];
//	%amnt = %clientId.bulkNum;
//	%cmnt = Belt::HasThisStuff(%id, %item);
//
//	if(%amnt > %cmnt)
//	%amnt = %cmnt;
//
//	Client::buildMenu(%clientId, %name @ " (" @ %cmnt @ ")", "Belt::MugChoose", true);
//
//	Client::addMenuItem(%clientId, %cnt++ @ "Mug " @ %item, %type @ " MUG " @ %item @ " 1");
//	Client::addMenuItem(%clientId, %cnt++ @ "Examine", %type @ " examine " @ %item);
//	Client::addMenuItem(%clientId, %cnt++ @ "Back", %type @ " back " @ %item);
//	Client::addMenuItem(%clientId, "xDone", "done");
//	return;
//}
//
//function processMenuBelt::MugChoose(%clientId, %opt)
//{
//	%type = GetWord(%opt, 0);
//	%option = GetWord(%opt, 1);
//	%item = GetWord(%opt, 2);
//
//	if(%option == "MUG")
//	{
//		Client::sendMessage(%clientId, $MsgBeige, "Attempting to Mug " @ client::getName(%clientId.MugId) @ "'s belt...");
//		schedule("Belt::MugItem(" @ %clientId @ ", " @ %item @ ", " @ %type @ ");", 5);
//	}
//	else if(%option == "examine")
//	{
//		%msg = WhatIs(%item);
//		bottomprint(%clientId, %msg, floor(String::len(%msg) / 20));
//		MenuBelt::MugChoose(%clientId, %item, %type);
//	}
//	else if(%option == "back")
//	{
//		MenuBelt::MugThisType(%clientId, %option, 1);
//	}
//	return;
//}
//function Belt::MugItem(%clientId, %item, %type)
//{
//	%cl=%clientId.MugId;
//	%list = fetchData(%cl, %type);
//	%victimName = Client::getName(%cl);
//	%stealerName = Client::getName(%clientId);
//
//	for(%i=0; getword(fetchData(%cl, %type), %i) != -1; %i+=2)
//	{
//		if(getword(fetchData(%cl, %type), %i) == %item)
//		%icnt = getword(fetchData(%cl, %type), %i+1);
//	}
//	%clientId.TryingToSteal = "";
//
//	//weights
//	%itemweight = GetAccessoryVar(%item, $Weight);
//	%wweight = 10;
//	if(Player::getMountedItem(%clientId, $WeaponSlot) == %item || %item.className == Equipped)
//	%handweight = 5.0;
//	else
//	%handweight = 1.0;
//	%FailWeight = (%itemweight * %wweight) * %handweight;
//
//	if(Vector::getDistance(GameBase::getPosition(%clientId), GameBase::getPosition(%cl)) > 2)
//	Client::sendMessage(%clientId, $MsgWhite, "Your target has wandered off...");
//	else
//	{
//		%r1 = GetRoll("1d" @ $PlayerSkill[%clientId, $SkillStealing]);
//		%r2 = GetRoll("1d" @ ($PlayerSkill[%cl, $SkillStealing] + $PlayerSkill[%cl, $SkillDodging]));
//		%b = %r1 - %r2;
//		%a = %b - %FailWeight;
//		if(%a > 0 && %icnt > 0)
//		{
//			%newcnt = %icnt-1;
//			Client::sendMessage(%clientId, $MsgBeige, "You successfully stole a " @ %item @ " from " @ %victimName @ "!");
//			Belt::TakeThisStuff(%cl, %item, 1);
//			Belt::GiveThisStuff(%clientId, %item, 1);
//			PerhapsPlayStealSound(%clientId, %clientId.stealType);
//
//			if(%newcnt > 0)
//			MenuBelt::MugChoose(%clientId, %item, %type);
//
//			RefreshAll(%clientId);
//			RefreshAll(%cl);
//
//			UseSkill(%clientId, $SkillStealing, true, true);
//			PostSteal(%clientId, true, %clientId.stealType);
//
//			return true;
//		}
//		else
//		{
//			Client::CancelMenu(%clientId);
//			Client::sendMessage(%clientId, $MsgRed, "You failed to mug " @ %victimName @ "'s belt!");
//			Client::sendMessage(%cl, $MsgRed, %stealerName @ " just failed to mug your belt!");
//
//			UseSkill(%clientId, $SkillStealing, false, true);
//			PostSteal(%clientId, false, %clientId.stealType);
//		}
//	}
//
//	//force kick from Inv Screen
//	remotePlayMode(%clientId);
//
//	return false;
//}
//==========================//
//====== MUG BELT END ======//
//==========================//

function Belt::TakeThisStuff(%clientId, %item, %amnt)
{
	if(%amnt > 0)
	{
		%originalItem = %item;
		%item = $BeltItem[%item, "Item"];
		%type = $BeltItem[%item, "Type"];
		
		// Validate item was found
		if(%item == "" || %type == "")
		{
			%clientName = Client::getName(%clientId);
			echo("ERROR: Belt::TakeThisStuff - Item '" @ %originalItem @ "' not found in belt item registry for " @ %clientName @ " (ClientId: " @ %clientId @ ")");
			return;
		}
		
		%list = fetchData(%clientId, %type);
		
		// Clean up corrupted entries before processing (items starting with "0", empty, invalid counts, etc.)
		// Check if list is severely corrupted (non-numeric counts indicate corruption)
		%testItem = GetWord(%list, 0);
		%testCount = GetWord(%list, 1);
		%isCorrupted = False;
		if(%testItem != "" && %testItem != -1)
		{
			// Try to get count for the first item - if it's non-numeric, the list is corrupted
			%testLookup = Belt::ItemCount(%testItem, %list);
			%testNumeric = %testLookup * 1;
			if(%testLookup != "" && %testNumeric != %testLookup && %testLookup != "0")
			{
				// Count is non-numeric - list is severely corrupted
				echo("CRITICAL: Belt::TakeThisStuff - List for " @ %type @ " is severely corrupted (non-numeric count: '" @ %testLookup @ "'). Resetting category.");
				echo("  Corrupted list: '" @ %list @ "'");
				%isCorrupted = True;
				%list = "";
				storeData(%clientId, %type, "");
			}
		}
		
		// If not corrupted, use Belt::GetNS to clean and rebuild
		if(!%isCorrupted)
		{
			%nsResult = Belt::GetNS(%clientId, %type);
			%itemCount = GetWord(%nsResult, 0);
			
			// Use the cleaned list that Belt::GetNS just saved
			%cleanedList = fetchData(%clientId, %type);
			
			// If the cleaned list is just "0" or invalid, treat it as empty
			if(%cleanedList == "0" || (GetWord(%cleanedList, 0) == "0" && GetWord(%cleanedList, 1) == ""))
			{
				%cleanedList = "";
				storeData(%clientId, %type, "");
			}
			
			%list = %cleanedList;
		}
		
		%count = Belt::ItemCount(%item, %list);
		
		if(%count < %amnt)
	{
		%clientName = Client::getName(%clientId);
			echo("WARNING: Belt::TakeThisStuff - Attempting to remove " @ %amnt @ " of item '" @ %item @ "', but only " @ %count @ " available. ClientId: " @ %clientId @ " (" @ %clientName @ ")");
			%amnt = %count; // Only remove what's available
		}
		
		%remainingAmnt = %count - %amnt;

		%list = Belt::RemoveFromList(%list, %item @ " " @ %count);
		
		if(%remainingAmnt > 0)
		{
			%list = Belt::AddToList(%list, %item @ " " @ %remainingAmnt);
		}

		// Normalize empty lists - store as empty string, not "0"
		if(%list == "" || %list == "0")
		{
			%list = "";
		}
		
		storeData(%clientId, %type, %list);
		
		// Build AllBelt - ensure each category is normalized (empty or "0" becomes "")
		%questItems = fetchData(%clientId, "QuestItems");
		if(%questItems == "0")
			%questItems = "";
		
		%keyItems = fetchData(%clientId, "KeyItems");
		if(%keyItems == "0")
			%keyItems = "";
		
		%allBelt = %questItems @ %keyItems;
		storeData(%clientId, "AllBelt", %allBelt);
	}
}

function Belt::ItemCount(%item, %list)
{
	%count = GetStuffStringCount(%list, %item);
	return %count;
}

function Belt::isEmpty(%clientId, %type)
{
	%stuff = fetchData(%clientId, %type);
	if(getWord(%stuff, 0) != -1 && getWord(%stuff, 1) != -1)
		return False;
	else
		return True;
}

function MenuBeltStoreThisItem(%clientId, %type, %page, %mode)
{
	%type = getword(%type, 0);
	%disp = Belt::Display(%type);
	
	%msg = "<jc><f2>To store 'bulk' " @ %disp @ ", please enter your desired 'bulk' number now!\n\n'Bulk' numbers must be greater than 0 and less than 500";
	bottomprint(%clientId, %msg, floor(String::len(%msg) / 20));
	
	// Store the original order when first opening the menu (page 1)
	if(%page == 1 && %clientId.beltItemOrder[%type] == "")
	{
		%stuff = fetchData(%clientId, %type);
		%orderList = "";
		for(%i = 0; (%item = getWord(%stuff, %i)) != -1; %i+=2)
		{
			%amnt = getWord(%stuff, %i + 1);
			if(%amnt > 0)
			{
				%orderList = %orderList @ " " @ %item;
			}
		}
		%clientId.beltItemOrder[%type] = String::NEWgetSubStr(%orderList, 1, 99999);
	}
	
	Client::buildMenu(%clientId, %disp @ ":", "BeltStoreThisItem", true);
	%clientId.bulkNum = "";

	%l = 6;
	%nx = $Belt::Count[%type];
	%nf = Belt::GetNS(%clientId, %type);
	%ns = GetWord(%nf, 0);
	%np = floor(%ns / %l);
	%lb = (%page * %l) - (%l-1);
	%ub = %lb + (%l-1);
	if(%ub > %ns)
	%ub = %ns;

	%x = %lb;
	for(%i = %lb; %i <= %ub; %i++)
	{
		%item = getword(%nf, %x);
		%amnt = Belt::HasThisStuff(%clientId, %item);
		Client::addMenuItem(%clientId, %cnt++ @ %amnt @ " " @ $BeltItem[%item, "Name"], %item @ " " @ %page @ " " @ %type @ " " @ %mode);
		%x++;
	}

	if(%page == 1)
	{
		if(%ns > 6) Client::addMenuItem(%clientId, "nNext >>", "page " @ %page+1 @ " " @ %type @ " " @ %mode);
		Client::addMenuItem(%clientId, "bBack", "back " @ %type @ " " @ %mode);
		Client::addMenuItem(%clientId, "xDone", "done");
	}
	else if(%page == %np+1)
	{
		Client::addMenuItem(%clientId, "p<< Prev", "page " @ %page-1 @ " " @ %type @ " " @ %mode);
		Client::addMenuItem(%clientId, "bBack", "back " @ %type @ " " @ %mode);
		Client::addMenuItem(%clientId, "xDone", "done");
	}
	else
	{
		Client::addMenuItem(%clientId, "nNext >>", "page " @ %page+1 @ " " @ %type @ " " @ %mode);
		Client::addMenuItem(%clientId, "p<< Prev", "page " @ %page-1 @ " " @ %type @ " " @ %mode);
		Client::addMenuItem(%clientId, "bBack", "back " @ %type @ " " @ %mode);
	}

	return;
}

function processMenuBeltStoreThisItem(%clientId, %opt)
{
	%o = GetWord(%opt, 0);
	%p = GetWord(%opt, 1);
	%t = GetWord(%opt, 2);
	%mode = getword(%opt, 3);

	if(%o == "back")
	{
		MenuStoreBelt(%clientId, %mode);
		return;
	}

	if(%o != "page" && %o != "done")
	{
		MenuSellBeltItemFinal(%clientId, %o, %t, %mode);
		return;
	}

	if(%o != "done")
	MenuBeltStoreThisItem(%clientId, %t, %p, %mode);

			return;
		}
		
function MenuBeltWithdrawThisItem(%clientId, %type, %page, %mode)
{
	%type = getword(%type, 0);
	%disp = Belt::Display(%type);
	
	// Store the original order when first opening the menu (page 1)
	if(%page == 1 && %clientId.beltStoredItemOrder[%type] == "")
	{
		%storedStuff = fetchdata(%clientId, "Stored" @ %type);
		%orderList = "";
		for(%i = 0; (%item = getWord(%storedStuff, %i)) != -1; %i+=2)
		{
			%amnt = getWord(%storedStuff, %i + 1);
			if(%amnt > 0)
			{
				%orderList = %orderList @ " " @ %item;
			}
		}
		%clientId.beltStoredItemOrder[%type] = String::NEWgetSubStr(%orderList, 1, 99999);
	}
	
	Client::buildMenu(%clientId, %disp @ ":", "BeltWithdrawThisItem", true);

	%l = 6;
	%nx = $Belt::Count[%type];
	%nf = fetchdata(%clientId, "Stored" @ %type);
	
	// Use stored order if available
	if(%clientId.beltStoredItemOrder[%type] != "")
	{
		%storedOrder = %clientId.beltStoredItemOrder[%type];
		%orderedList = "";
		%count = 0;
		
		// Build ordered list based on stored order
		for(%i = 0; (%item = getWord(%storedOrder, %i)) != -1; %i++)
		{
			%amnt = Belt::ItemCount(%item, %nf);
			if(%amnt > 0)
			{
				%orderedList = %orderedList @ " " @ %item @ " " @ %amnt;
				%count++;
			}
		}
		%nf = String::NEWgetSubStr(%orderedList, 1, 99999);
		%ns = %count - 1;
	}
	else
	{
		%ns = (CountObjInList(%nf) / 2) - 1;
	}
	
	%np = floor(%ns / %l);
	%lb = (%page * %l) - (%l-1);
	%ub = %lb + (%l-1);
	if(%ub > %ns)
		%ub = %ns;

	%x = (%lb - 1) * 2 + 2;
	for(%i = %lb; %i <= %ub; %i++)
	{	
		%item = getword(%nf, %x);
		%amnt = getword(%nf, %x + 1);
		Client::addMenuItem(%clientId, %cnt++ @ %amnt @ " " @ %item, %item @ " " @ %page @ " " @ %type @ " " @ %mode);
		%x+=2;
	}

	if(%page == 1)
	{
		if(%ns > 6) Client::addMenuItem(%clientId, "nNext >>", "page " @ %page+1 @ " " @ %type @ " " @ %mode);
		Client::addMenuItem(%clientId, "bBack", "back " @ %type @ " " @ %mode);
		Client::addMenuItem(%clientId, "xDone", "done");
	}
	else if(%page == %np+1)
	{
		Client::addMenuItem(%clientId, "p<< Prev", "page " @ %page-1 @ " " @ %type @ " " @ %mode);
		Client::addMenuItem(%clientId, "bBack", "back " @ %type @ " " @ %mode);
		Client::addMenuItem(%clientId, "xDone", "done");
	}
	else
	{
		Client::addMenuItem(%clientId, "nNext >>", "page " @ %page+1 @ " " @ %type @ " " @ %mode);
		Client::addMenuItem(%clientId, "p<< Prev", "page " @ %page-1 @ " " @ %type @ " " @ %mode);
		Client::addMenuItem(%clientId, "bBack", "back " @ %type @ " " @ %mode);
	}

	return;
}

function processMenuBeltWithdrawThisItem(%clientId, %opt)
{
	%o = GetWord(%opt, 0);
	%p = GetWord(%opt, 1);
	%t = GetWord(%opt, 2);
	%mode = getword(%opt, 3);

	if(%o == "back")
	{
		MenuStoreBelt(%clientId, %mode);
		return;
	}

	if(%o != "page" && %o != "done")
	{
		MenuSellBeltItemFinal(%clientId, %o, %t, %mode);
		return;
	}

	if(%o != "done")
	MenuBeltWithdrawThisItem(%clientId, %t, %p, %mode);

	return;
}

// ------------------- //
// Non Menu Functions  //
// ------------------- //

//==========================//
//======MUG BELT START======//
//==========================//
// TEMPORARILY DISABLED - Belt::Mug functions
//==========================//
//====== MUG BELT END ======//
//==========================//

function MenuBeltWithdrawThisItem(%clientId, %type, %page, %mode)
{
	%type = getword(%type, 0);
	%disp = Belt::Display(%type);
	
	// Store the original order when first opening the menu (page 1)
	if(%page == 1 && %clientId.beltStoredItemOrder[%type] == "")
	{
		%storedStuff = fetchdata(%clientId, "Stored" @ %type);
		%orderList = "";
		for(%i = 0; (%item = getWord(%storedStuff, %i)) != -1; %i+=2)
		{
			%amnt = getWord(%storedStuff, %i + 1);
			if(%amnt > 0)
			{
				%orderList = %orderList @ " " @ %item;
			}
		}
		%clientId.beltStoredItemOrder[%type] = String::NEWgetSubStr(%orderList, 1, 99999);
	}
	
	Client::buildMenu(%clientId, %disp @ ":", "BeltWithdrawThisItem", true);

	%l = 6;
	%nx = $Belt::Count[%type];
	%nf = fetchdata(%clientId, "Stored" @ %type);
	
	// Use stored order if available
	if(%clientId.beltStoredItemOrder[%type] != "")
	{
		%storedOrder = %clientId.beltStoredItemOrder[%type];
		%orderedList = "";
		%count = 0;
		
		// Build ordered list based on stored order
		for(%i = 0; (%item = getWord(%storedOrder, %i)) != -1; %i++)
		{
			%amnt = Belt::ItemCount(%item, %nf);
	if(%amnt > 0)
	{
				%orderedList = %orderedList @ " " @ %item @ " " @ %amnt;
				%count++;
			}
		}
		%nf = String::NEWgetSubStr(%orderedList, 1, 99999);
		%ns = %count - 1;
	}
	else
	{
		%ns = (CountObjInList(%nf) / 2) - 1;
	}
	
	%np = floor(%ns / %l);
	%lb = (%page * %l) - (%l-1);
	%ub = %lb + (%l-1);
	if(%ub > %ns)
		%ub = %ns;

	%x = (%lb - 1) * 2 + 2;
	for(%i = %lb; %i <= %ub; %i++)
	{	
		%item = getword(%nf, %x);
		%amnt = getword(%nf, %x + 1);
		Client::addMenuItem(%clientId, %cnt++ @ %amnt @ " " @ %item, %item @ " " @ %page @ " " @ %type @ " " @ %mode);
		%x+=2;
	}

	if(%page == 1)
	{
		if(%ns > 6) Client::addMenuItem(%clientId, "nNext >>", "page " @ %page+1 @ " " @ %type @ " " @ %mode);
		Client::addMenuItem(%clientId, "bBack", "back " @ %type @ " " @ %mode);
		Client::addMenuItem(%clientId, "xDone", "done");
	}
	else if(%page == %np+1)
	{
		Client::addMenuItem(%clientId, "p<< Prev", "page " @ %page-1 @ " " @ %type @ " " @ %mode);
		Client::addMenuItem(%clientId, "bBack", "back " @ %type @ " " @ %mode);
		Client::addMenuItem(%clientId, "xDone", "done");
	}
	else
	{
		Client::addMenuItem(%clientId, "nNext >>", "page " @ %page+1 @ " " @ %type @ " " @ %mode);
		Client::addMenuItem(%clientId, "p<< Prev", "page " @ %page-1 @ " " @ %type @ " " @ %mode);
		Client::addMenuItem(%clientId, "bBack", "back " @ %type @ " " @ %mode);
	}

	return;
}
function processMenuBeltWithdrawThisItem(%clientId, %opt)
{
	%o = GetWord(%opt, 0);
	%p = GetWord(%opt, 1);
	%t = GetWord(%opt, 2);
	%mode = getword(%opt, 3);

	if(%o == "back")
	{
		MenuStoreBelt(%clientId, %mode);
		return;
	}

	if(%o != "page" && %o != "done")
	{
		MenuSellBeltItemFinal(%clientId, %o, %t, %mode);
		return;
	}

	if(%o != "done")
	MenuBeltWithdrawThisItem(%clientId, %t, %p, %mode);

	return;
}
function MenuBeltStoreThisItem(%clientId, %type, %page, %mode)
{
	%type = getword(%type, 0);
	%disp = Belt::Display(%type);
	
	%msg = "<jc><f2>To store 'bulk' " @ %disp @ ", please enter your desired 'bulk' number now!\n\n'Bulk' numbers must be greater than 0 and less than 500";
	bottomprint(%clientId, %msg, floor(String::len(%msg) / 20));
	
	// Store the original order when first opening the menu (page 1)
	if(%page == 1 && %clientId.beltItemOrder[%type] == "")
	{
		%stuff = fetchData(%clientId, %type);
		%orderList = "";
		for(%i = 0; (%item = getWord(%stuff, %i)) != -1; %i+=2)
		{
			%amnt = getWord(%stuff, %i + 1);
			if(%amnt > 0)
			{
				%orderList = %orderList @ " " @ %item;
			}
		}
		%clientId.beltItemOrder[%type] = String::NEWgetSubStr(%orderList, 1, 99999);
	}
	
	Client::buildMenu(%clientId, %disp @ ":", "BeltStoreThisItem", true);
	%clientId.bulkNum = "";

	%l = 6;
	%nx = $Belt::Count[%type];
	%nf = Belt::GetNS(%clientId, %type);
	%ns = GetWord(%nf, 0);
	%np = floor(%ns / %l);
	%lb = (%page * %l) - (%l-1);
	%ub = %lb + (%l-1);
	if(%ub > %ns)
	%ub = %ns;

	%x = %lb;
	for(%i = %lb; %i <= %ub; %i++)
	{
		%item = getword(%nf, %x);
		%amnt = Belt::HasThisStuff(%clientId, %item);
		Client::addMenuItem(%clientId, %cnt++ @ %amnt @ " " @ $BeltItem[%item, "Name"], %item @ " " @ %page @ " " @ %type @ " " @ %mode);
		%x++;
	}

	if(%page == 1)
	{
		if(%ns > 6) Client::addMenuItem(%clientId, "nNext >>", "page " @ %page+1 @ " " @ %type @ " " @ %mode);
		Client::addMenuItem(%clientId, "bBack", "back " @ %type @ " " @ %mode);
		Client::addMenuItem(%clientId, "xDone", "done");
	}
	else if(%page == %np+1)
	{
		Client::addMenuItem(%clientId, "p<< Prev", "page " @ %page-1 @ " " @ %type @ " " @ %mode);
		Client::addMenuItem(%clientId, "bBack", "back " @ %type @ " " @ %mode);
		Client::addMenuItem(%clientId, "xDone", "done");
	}
	else
	{
		Client::addMenuItem(%clientId, "nNext >>", "page " @ %page+1 @ " " @ %type @ " " @ %mode);
		Client::addMenuItem(%clientId, "p<< Prev", "page " @ %page-1 @ " " @ %type @ " " @ %mode);
		Client::addMenuItem(%clientId, "bBack", "back " @ %type @ " " @ %mode);
	}

	return;
}
function processMenuBeltStoreThisItem(%clientId, %opt)
{
	%o = GetWord(%opt, 0);
	%p = GetWord(%opt, 1);
	%t = GetWord(%opt, 2);
	%mode = getword(%opt, 3);

	if(%o == "back")
	{
		MenuStoreBelt(%clientId, %mode);
		return;
	}

	if(%o != "page" && %o != "done")
	{
		MenuSellBeltItemFinal(%clientId, %o, %t, %mode);
		return;
	}

	if(%o != "done")
	MenuBeltStoreThisItem(%clientId, %t, %p, %mode);

	return;
}

// ------------------- //
// Non Menu Functions  //
// ------------------- //

//==========================//
//======MUG BELT START======//
//==========================//
// TEMPORARILY DISABLED - Belt::Mug functions
//function Belt::Mug(%clientId, %id)
//{
//	%clientId.MugID=%id;
//	Belt::MugBeltMain(%clientId, %id);
//	client::sendmessage(%clientId, "You are belt mugging");
//}
//function Belt::MugBeltMain(%clientId, %id)
//{
//	Client::buildMenu(%clientId, client::getname(%id) @ "'s Belt:", "MugBeltMain", true);
//	for(%i = 1; %i < Belt::GetLastItem(); %i++)
//	if(!Belt::isEmpty(%clientId, $Belt::Categories[%i]) > 0)
//	Client::addMenuItem(%clientId, %cnt++ @ Belt::Display($Belt::Categories[%i]), $Belt::Categories[%i]);	
//	Client::addMenuItem(%clientId, "xDone", "done");
//	return;
//}
//function processMenuMugBeltMain(%clientId, %opt)
//{
//	%o = GetWord(%opt, 0);
//	%p = GetWord(%opt, 1);
//
//	if($Belt::Count[%o] > 0)
//	{
//		MenuBelt::MugThisType(%clientId, %o, 1);
//		return;
//	}
//	return;
//}
//function MenuBelt::MugThisType(%clientId, %type, %page)
//{
//	%id=%clientId.MugId;
//	%disp = Belt::Display(%type);
//
//	Client::buildMenu(%clientId, %disp @ ":", "Belt::MugThisType", true);
//	%clientId.bulkNum = "";
//
//	%l = 6;
//	%nx = $Belt::Count[%type];
//	%nf = Belt::GetNS(%id, %type);
//	%ns = GetWord(%nf, 0);
//	%np = floor(%ns / %l);
//	%lb = (%page * %l) - (%l-1);
//	%ub = %lb + (%l-1);
//	if(%ub > %ns)
//	%ub = %ns;
//
//	%x = %lb - 1;
//	for(%i = %lb; %i <= %ub; %i++)
//	{
//		%x++;
//		%item = getword(%nf, %x);
//		%amnt = Belt::HasThisStuff(%id, %item);
//		Client::addMenuItem(%clientId, %cnt++ @ %amnt @ " " @ $BeltItem[%item, "Name"], %item @ " " @ %page @ " " @ %type);
//	}
//
//	if(%page == 1)
//	{
//		if(%ns > 6) Client::addMenuItem(%clientId, "nNext >>", "page " @ %page+1 @ " " @ %type);
//		Client::addMenuItem(%clientId, "xDone", "done");
//	}
//	else if(%page == %np+1)
//	{
//		Client::addMenuItem(%clientId, "p<< Prev", "page " @ %page-1 @ " " @ %type);
//		Client::addMenuItem(%clientId, "xDone", "done");
//	}
//	else
//	{
//		Client::addMenuItem(%clientId, "nNext >>", "page " @ %page+1 @ " " @ %type);
//		Client::addMenuItem(%clientId, "p<< Prev", "page " @ %page-1 @ " " @ %type);
//	}
//
//	return;
//}
//function processMenuBelt::MugThisType(%clientId, %opt)
//{
//	%o = GetWord(%opt, 0);
//	%p = GetWord(%opt, 1);
//	%t = GetWord(%opt, 2);
//
//	if(%o != "page" && %o != "done")
//	{
//		%clientId.bulkNum = 1;
//
//		MenuBelt::MugChoose(%clientId, %o, %t);
//		return;
//	}
//
//	return;
//}
//function MenuBelt::MugChoose(%clientId, %item, %type)
//{
//	%id=%clientId.MugId;
//	%name = $BeltItem[%item, "Name"];
//	%amnt = %clientId.bulkNum;
//	%cmnt = Belt::HasThisStuff(%id, %item);
//
//	if(%amnt > %cmnt)
//	%amnt = %cmnt;
//
//	Client::buildMenu(%clientId, %name @ " (" @ %cmnt @ ")", "Belt::MugChoose", true);
//
//	Client::addMenuItem(%clientId, %cnt++ @ "Mug " @ %item, %type @ " MUG " @ %item @ " 1");
//	Client::addMenuItem(%clientId, %cnt++ @ "Examine", %type @ " examine " @ %item);
//	Client::addMenuItem(%clientId, %cnt++ @ "Back", %type @ " back " @ %item);
//	Client::addMenuItem(%clientId, "xDone", "done");
//	return;
//}
//
//function processMenuBelt::MugChoose(%clientId, %opt)
//{
//	%type = GetWord(%opt, 0);
//	%option = GetWord(%opt, 1);
//	%item = GetWord(%opt, 2);
//
//	if(%option == "MUG")
//	{
//		Client::sendMessage(%clientId, $MsgBeige, "Attempting to Mug " @ client::getName(%clientId.MugId) @ "'s belt...");
//		schedule("Belt::MugItem(" @ %clientId @ ", " @ %item @ ", " @ %type @ ");", 5);
//	}
//	else if(%option == "examine")
//	{
//		%msg = WhatIs(%item);
//		bottomprint(%clientId, %msg, floor(String::len(%msg) / 20));
//		MenuBelt::MugChoose(%clientId, %item, %type);
//	}
//	else if(%option == "back")
//	{
//		MenuBelt::MugThisType(%clientId, %option, 1);
//	}
//	return;
//}
//function Belt::MugItem(%clientId, %item, %type)
//{
//	%cl=%clientId.MugId;
//	%list = fetchData(%cl, %type);
//	%victimName = Client::getName(%cl);
//	%stealerName = Client::getName(%clientId);
//
//	for(%i=0; getword(fetchData(%cl, %type), %i) != -1; %i+=2)
//	{
//		if(getword(fetchData(%cl, %type), %i) == %item)
//		%icnt = getword(fetchData(%cl, %type), %i+1);
//	}
//	%clientId.TryingToSteal = "";
//
//	//weights
//	%itemweight = GetAccessoryVar(%item, $Weight);
//	%wweight = 10;
//	if(Player::getMountedItem(%clientId, $WeaponSlot) == %item || %item.className == Equipped)
//	%handweight = 5.0;
//	else
//	%handweight = 1.0;
//	%FailWeight = (%itemweight * %wweight) * %handweight;
//
//	if(Vector::getDistance(GameBase::getPosition(%clientId), GameBase::getPosition(%cl)) > 2)
//	Client::sendMessage(%clientId, $MsgWhite, "Your target has wandered off...");
//	else
//	{
//		%r1 = GetRoll("1d" @ $PlayerSkill[%clientId, $SkillStealing]);
//		%r2 = GetRoll("1d" @ ($PlayerSkill[%cl, $SkillStealing] + $PlayerSkill[%cl, $SkillDodging]));
//		%b = %r1 - %r2;
//		%a = %b - %FailWeight;
//		if(%a > 0 && %icnt > 0)
//		{
//			%newcnt = %icnt-1;
//			Client::sendMessage(%clientId, $MsgBeige, "You successfully stole a " @ %item @ " from " @ %victimName @ "!");
//			Belt::TakeThisStuff(%cl, %item, 1);
//			Belt::GiveThisStuff(%clientId, %item, 1);
//			PerhapsPlayStealSound(%clientId, %clientId.stealType);
//
//			if(%newcnt > 0)
//			MenuBelt::MugChoose(%clientId, %item, %type);
//
//			RefreshAll(%clientId);
//			RefreshAll(%cl);
//
//			UseSkill(%clientId, $SkillStealing, true, true);
//			PostSteal(%clientId, true, %clientId.stealType);
//
//			return true;
//		}
//		else
//		{
//			Client::CancelMenu(%clientId);
//			Client::sendMessage(%clientId, $MsgRed, "You failed to mug " @ %victimName @ "'s belt!");
//			Client::sendMessage(%cl, $MsgRed, %stealerName @ " just failed to mug your belt!");
//
//			UseSkill(%clientId, $SkillStealing, false, true);
//			PostSteal(%clientId, false, %clientId.stealType);
//		}
//	}
//
//	//force kick from Inv Screen
//	remotePlayMode(%clientId);
//
//	return false;
//}
//==========================//
//====== MUG BELT END ======//
//==========================//

function isBeltItem(%item)
{
	%lookup = $BeltItem[%item, "Item"];
	%compare = String::ICompare(%lookup, %item);
	if(%compare == 0)
	{
		return True;
	}
	return False;
}

function Belt::WhatIs(%clientId, %item)
{
	dbecho($dbechoMode, "Belt::WhatIs(" @ %clientId @ ", " @ %item @ ")");

	if(%item.description == false)
		%desc = $BeltItem[%item, "Name"];
	else
		%desc = %item.description;
		
	%w = GetAccessoryVar(%item, $Weight);
	%c = GetItemCost(%item);
	%t = Belt::Display($BeltItem[%item, "Type"]);
	
	if($AccessoryVar[%item, $MiscInfo] != "")
		%nfo = $AccessoryVar[%item, $MiscInfo];
	else
		%nfo = "There is no further information available.";

	%msg = "";
	%msg = %msg @ "<f1>" @ %desc @ "\n";
	if(%w != "")
	%msg = %msg @ "\nWeight: " @ %w;
	if(%t != "")
	%msg = %msg @ "\nType: " @ %t;	
	if(%c != "")
	%msg = %msg @ "\nPrice: $" @ %c;
	
	
	%msg = %msg @ "\n\n<f0>" @ %nfo;
	bottomprint(%clientId, %msg, floor(String::len(%msg) / 20));
}

function Belt::GetLastItem()
{
	for(%i = 1; $Belt::Categories[%i] != ""; %i++) {}
	
	return %i;
}

function Belt::Display(%type)
{
	%disp = ""; // Initialize to empty string
	if(%type == "QuestItems") %disp = "Quest Items";
	else if(%type == "KeyItems") %disp = "Key Items";
	else if(%type == "Deployables") %disp = "Deployables";
	else if(%type == "Consumables") %disp = "Consumables";
	else if(%type == "Armor") %disp = "Armor";
	else if(%type == "Accessories") %disp = "Accessories";
	else if(%type == "Other") %disp = "Other";
	
	// If no match, return the type name itself as fallback
	if(%disp == "")
		%disp = %type;

	return %disp;
}

function Belt::Sell(%clientId, %npc)
{
	// Set flag to track that player is in belt sell menu (for bulkNum chat input)
	%clientId.currentBeltSell = %npc;
	AI::sayLater(%clientId, %npc, "What would you like to sell?", true);
	MenuSellBelt(%clientId);
}

function Belt::DeployItem(%clientId, %item, %type)
{
	// Check if player has the item in Belt storage
	if(!Belt::HasThisStuff(%clientId, %item))
	{
		Client::sendMessage(%clientId, $MsgRed, "You don't have any " @ $BeltItem[%item, "Name"] @ " in your backpack.");
		return;
	}
	
	// Get player object - needed for Player::deployItem
	%player = Client::getOwnedObject(%clientId);
	if(%player == -1 || %player == "")
	{
		Client::sendMessage(%clientId, $MsgRed, "You must be in-game to deploy items.");
		return;
	}
	
	// Check if this is DepBasePack - deployables still use ItemData
	// For non-deployable belt items (quest items, key items), skip ItemData validation
	if(%item == "DepBasePack")
	{
		// Get ItemData object for deployables (DepBasePack still uses ItemData)
	%itemData = getItemData(%item);
	if(%itemData == "")
	{
			Client::sendMessage(%clientId, $MsgRed, "Invalid item data for " @ %item @ ".");
		return;
	}
	
	// Set flag so onDeploy knows to remove from Belt instead of standard inventory
	%clientId.beltDeploying = %item;
	
	// Call Player::deployItem - this triggers the onDeploy callback
	Player::deployItem(%player, %itemData);
	}
	else
	{
		// Non-deployable belt items don't need ItemData - they're string-based
		// This path is for future belt items that might be deployable but not yet implemented
		Client::sendMessage(%clientId, $MsgRed, "Cannot deploy " @ %item @ " - this item is not deployable.");
		return;
	}
	
	// Clear flag after a moment (in case deployment fails)
	schedule("if(" @ %clientId @ ".beltDeploying != \"\") " @ %clientId @ ".beltDeploying = \"\";", 2);
}

function Belt::UseItem(%clientId, %item, %type)
{
	dbecho($dbechoMode, "Belt::UseItem(" @ %clientId @ ", " @ %item @ ", " @ %type @ ")");
	
	// Check if player has the item in Belt storage
	if(!Belt::HasThisStuff(%clientId, %item))
	{
		Client::sendMessage(%clientId, $MsgRed, "You don't have any " @ $BeltItem[%item, "Name"] @ " in your backpack.");
		return;
	}
	
	// Get player object - needed for onUse function
	%player = Client::getOwnedObject(%clientId);
	if(%player == -1 || %player == "")
	{
		Client::sendMessage(%clientId, $MsgRed, "You must be in-game to use items.");
		return;
	}
	
	// Check if item has an onUse function (potions, etc.)
	// Call the item's onUse function with player object and item name
	// The onUse function will handle consuming the item (via Belt::TakeThisStuff)
	if(%item == "BluePotion")
		BluePotion::onUse(%player, %item);
	else if(%item == "CrystalBluePotion")
		CrystalBluePotion::onUse(%player, %item);
	else if(%item == "EnergyVial")
		EnergyVial::onUse(%player, %item);
	else if(%item == "CrystalEnergyVial")
		CrystalEnergyVial::onUse(%player, %item);
	else
	{
		Client::sendMessage(%clientId, $MsgRed, "Cannot use " @ $BeltItem[%item, "Name"] @ " - this item is not consumable.");
		return;
	}
}

function Belt::DropItem(%clientId, %item, %amnt, %type)
{
	%chk = Belt::HasThisStuff(%clientId, %item);
	if(%chk >= %amnt)
	{
		Belt::TakeThisStuff(%clientId, %item, %amnt);
		TossLootbag(%clientId, %item @ " " @ %amnt, 8, "*", 0, 1);
	}
}

function Belt::AddToList(%list, %item)
{
	// Validate item string before adding
	// Parse item string format: "itemname count" (e.g., "AlienSpine 10")
	%itemName = GetWord(%item, 0);
	%itemCount = GetWord(%item, 1);
	
	// Skip invalid entries: empty item, item "0", empty count, count -1 or "0", count <= 0
	%countNum = %itemCount * 1;
	if(%itemName == "" || %itemName == -1 || %itemName == "0" || %itemCount == "" || %itemCount == -1 || %itemCount == "-1" || %itemCount == "0" || %countNum <= 0)
	{
		// Invalid entry - don't add it to the list
		return %list;
	}
	
	// Validate item string before adding
	// Parse item string format: "itemname count" (e.g., "AlienSpine 10")
	%itemName = GetWord(%item, 0);
	%itemCount = GetWord(%item, 1);
	
	// Skip invalid entries: empty item, item "0", empty count, count -1 or "0", count <= 0
	%countNum = %itemCount * 1;
	if(%itemName == "" || %itemName == -1 || %itemName == "0" || %itemCount == "" || %itemCount == -1 || %itemCount == "-1" || %itemCount == "0" || %countNum <= 0)
	{
		// Invalid entry - don't add it to the list
		return %list;
	}
	
	// Ensure list ends with a space before adding new item
	%len = String::len(%list);
	if(%len > 0 && String::getSubStr(%list, %len-1, 1) != " ")
		%list = %list @ " ";
	%list = %list @ %item @ " ";
	return %list;
}

function Belt::RemoveFromList(%list, %item)
{
	// Pad both sides with spaces to ensure pattern matching works
	%paddedList = " " @ %list @ " ";
	
	// Search pattern needs spaces on both sides
	%searchStr = " " @ %item @ " ";
	
	%pos = String::findSubStr(%paddedList, %searchStr);
	if(%pos != -1)
	{
		// Item found - remove it
		%before = String::getSubStr(%paddedList, 0, %pos);
		%after = String::getSubStr(%paddedList, %pos + String::len(%searchStr), 99999);
		%result = %before @ %after;
		
		// Remove leading space (if we removed the first item, result will start with " ")
		%len = String::len(%result);
		if(%len > 0 && String::getSubStr(%result, 0, 1) == " ")
			%result = String::getSubStr(%result, 1, 99999);
		
		// Remove trailing space
		%len = String::len(%result);
		if(%len > 0 && String::getSubStr(%result, %len-1, 1) == " ")
			%result = String::getSubStr(%result, 0, %len-1);
		
		%list = %result;
	}
	
	return %list;
}

function Belt::IsInList(%list, %item)
{
	if(String::findSubStr(%list, %item) != -1)
		return True;
	else
		return False;
}

function Belt::GetStored(%clientId, %opt)
{	
	%type = GetWord(%opt, 0);
	%item = GetWord(%opt, 2);
	%amnt = GetWord(%opt, 3);

	for(%i=0; (%item2=getword(fetchData(%clientId, "Stored" @ %type), %i)) != -1; %i+=2)
	{
		if(%item == %item2)
		{
			%amnt=getword(fetchData(%clientId, "Stored" @ %type), %i+1);
			return %amnt;
		}
	}
}

function Belt::GetDeathItems(%clientId)
{
	%tmploot = "";
	if(fetchData(%clientId, "LCK") < 0)
	{
		for(%i = 1; $Belt::Categories[%i] != ""; %i++)
			if($Belt::Storage[$Belt::Categories[%i]])
				%tmploot = %tmploot @ fetchData(%clientId, $Belt::Categories[%i]);

		for(%i=0;getword(%tmploot, %i)!=-1;%i++)
		{
			%a = getword(%tmploot, %i);
			%b = getword(%tmploot, %i++);

			Belt::TakeThisStuff(%clientId, %a, %b);
		}
	}
	
	return %tmploot;
}

function BeltItem::Add(%name, %item, %type, %weight, %cost)
{
	%num = $Belt::Count[%type]++;
	$BeltItem[%num, "Num", %type] = %item;
	$BeltItem[%item, "Item"] = %item;
	$BeltItem[%item, "Name"] = %name;
	$BeltItem[%item, "Type"] = %type;
	$AccessoryVar[%item, $Weight] = %weight;
	$HardcodedItemCost[%item] = %cost;
	
	// Also register the display name as an alias to the item name for lookup purposes
	// This handles cases where items might be referenced by their display name
	$BeltItem[%name, "Item"] = %item;
}

//===================
//  Minerals (Removed - not in this mod)
//===================
// Mining items removed from Kingdom of Kronos

//===================
//  Quest Items
//===================

BeltItem::Add("Black Statue", "BlackStatue", "QuestItems", 1.0, 300);
BeltItem::Add("Enchanted Stone", "EnchantedStone", "QuestItems", 5.0, 2450);
BeltItem::Add("Skeleton Bone", "SkeletonBone", "QuestItems", 2.5, 5860);
BeltItem::Add("Ogre Tooth", "OgreTooth", "QuestItems", 2.5, 6000);
BeltItem::Add("Ancient Scroll", "AncientScroll", "QuestItems", 5.0, 40000);
BeltItem::Add("Crown", "Crown", "QuestItems", 2.5, 45000);
BeltItem::Add("Krono Stone", "KronoStone", "QuestItems", 5.0, 80000);
BeltItem::Add("Minotaur Horn", "MinotaurHorn", "QuestItems", 2.5, 100000);
BeltItem::Add("Alien Spine", "AlienSpine", "QuestItems", 5.0, 150000);
BeltItem::Add("Alien Eye", "AlienEye", "QuestItems", 2.5, 500000);
BeltItem::Add("Demon Breath", "DemonBreath", "QuestItems", 5.0, 700000);
BeltItem::Add("Bible", "Bible", "QuestItems", 5.0, 800000);
BeltItem::Add("Angel's Tear", "AngelsTear", "QuestItems", 2.5, 900000);

$AccessoryVar[BlackStatue, $MiscInfo] = "A black statue";
$AccessoryVar[EnchantedStone, $MiscInfo] = "An enchanted stone";
$AccessoryVar[SkeletonBone, $MiscInfo] = "A skeleton bone";
$AccessoryVar[OgreTooth, $MiscInfo] = "An ogre tooth";
$AccessoryVar[AncientScroll, $MiscInfo] = "A very old look scroll";
$AccessoryVar[Crown, $MiscInfo] = "A very valuable crown.";
$AccessoryVar[KronoStone, $MiscInfo] = "A mystical stone sizzling with power";
$AccessoryVar[MinotaurHorn, $MiscInfo] = "A horn from a Minotaur's Head";
$AccessoryVar[AlienSpine, $MiscInfo] = "A long spine from an alien";
$AccessoryVar[AlienEye, $MiscInfo] = "A gooey eye from the Alien Queen";
$AccessoryVar[DemonBreath, $MiscInfo] = "The very rare breath of a demon";
$AccessoryVar[Bible, $MiscInfo] = "Do you have time to talk about your lord and savior?";
$AccessoryVar[AngelsTear, $MiscInfo] = "A tear shed from an angel when it dies.";

//===================
//  Key Items
//===================
BeltItem::Add("DuelCard", "DuelCard", "KeyItems", 2.0, 100000);

$AccessoryVar[DuelCard, $MiscInfo] = "A special card that allows you to #challenge someone to a duel.";

//===================
//  Deployables
//===================
BeltItem::Add("Deployable Base Pack", "DepBasePack", "Deployables", 0.0, 40000);

//===================
//  Consumables
//===================
BeltItem::Add("Blue Potion", "BluePotion", "Consumables", 4.0, 15);
BeltItem::Add("Crystal Blue Potion", "CrystalBluePotion", "Consumables", 10.0, 100);
BeltItem::Add("Energy Vial", "EnergyVial", "Consumables", 2.0, 15);
BeltItem::Add("Crystal Energy Vial", "CrystalEnergyVial", "Consumables", 5.0, 100);

//===================
//  Belt Storage at Banker (Backpack menu)
//===================
function Belt::Store(%clientId, %bankerId)
{
	dbecho($dbechoMode, "Belt::Store(" @ %clientId @ ", " @ %bankerId @ ")");
	
	%clientId.currentBeltBank = %bankerId;
	
	// Show menu with deposit and withdraw options
	Client::buildMenu(%clientId, "Backpack Storage:", "BeltStorage", true);
	Client::addMenuItem(%clientId, "1Deposit Backpack Items", "deposit");
	Client::addMenuItem(%clientId, "2Withdraw Backpack Items", "withdraw");
	Client::addMenuItem(%clientId, "xCancel", "cancel");
	
	AI::sayLater(%clientId, %bankerId, "Would you like to DEPOSIT or WITHDRAW backpack items?", True);
}

function processMenuBeltStorage(%clientId, %option)
{
	if(%option == "deposit")
	{
		Belt::ShowDepositMenu(%clientId);
	}
	else if(%option == "withdraw")
	{
		Belt::ShowWithdrawMenu(%clientId);
	}
	else if(%option == "cancel")
	{
		// Clear the belt bank flag and stored orders when cancelled
		%clientId.currentBeltBank = "";
		%clientId.beltDepositItemOrder = "";
		%clientId.beltWithdrawItemOrder = "";
		Client::cancelMenu(%clientId);
	}
	// If cancel, do nothing
}

function Belt::ShowDepositMenu(%clientId)
{
	// Always rebuild the order list to prevent duplicates from old stored orders
	// Clear stored order to force rebuild each time
	%clientId.beltDepositItemOrder = "";
	
	// Build the order list
		%orderList = "";
		%seenItems = ""; // Track items we've already added to prevent duplicates in order list
		// Check QuestItems
		%questItems = fetchData(%clientId, "QuestItems");
		if(%questItems != "")
		{
			for(%i = 0; GetWord(%questItems, %i) != -1; %i += 2)
			{
				%item = GetWord(%questItems, %i);
				%count = GetWord(%questItems, %i + 1);
				if(%count > 0)
				{
					// Check if we've already added this item to the order list
					if(String::findSubStr(%seenItems, " " @ %item @ " ") == -1)
				{
					%orderList = %orderList @ " " @ %item @ " QuestItems";
						%seenItems = %seenItems @ " " @ %item @ " ";
					}
				}
			}
		}
		// Check KeyItems
		%keyItems = fetchData(%clientId, "KeyItems");
		if(%keyItems != "")
		{
			for(%i = 0; GetWord(%keyItems, %i) != -1; %i += 2)
			{
				%item = GetWord(%keyItems, %i);
				%count = GetWord(%keyItems, %i + 1);
				if(%count > 0)
				{
					// Check if we've already added this item to the order list
					if(String::findSubStr(%seenItems, " " @ %item @ " ") == -1)
				{
					%orderList = %orderList @ " " @ %item @ " KeyItems";
						%seenItems = %seenItems @ " " @ %item @ " ";
					}
				}
			}
		}
		// Check Consumables
		%consumables = fetchData(%clientId, "Consumables");
		if(%consumables != "")
		{
			for(%i = 0; GetWord(%consumables, %i) != -1; %i += 2)
			{
				%item = GetWord(%consumables, %i);
				%count = GetWord(%consumables, %i + 1);
				if(%count > 0)
				{
					// Check if we've already added this item to the order list
					if(String::findSubStr(%seenItems, " " @ %item @ " ") == -1)
					{
						%orderList = %orderList @ " " @ %item @ " Consumables";
						%seenItems = %seenItems @ " " @ %item @ " ";
					}
				}
			}
		}
		// Check Armor
		%armor = fetchData(%clientId, "Armor");
		if(%armor != "")
		{
			for(%i = 0; GetWord(%armor, %i) != -1; %i += 2)
			{
				%item = GetWord(%armor, %i);
				%count = GetWord(%armor, %i + 1);
				if(%count > 0)
				{
					// Check if we've already added this item to the order list
					if(String::findSubStr(%seenItems, " " @ %item @ " ") == -1)
					{
						%orderList = %orderList @ " " @ %item @ " Armor";
						%seenItems = %seenItems @ " " @ %item @ " ";
					}
				}
			}
		}
		// Check Accessories
		%accessories = fetchData(%clientId, "Accessories");
		if(%accessories != "")
		{
			for(%i = 0; GetWord(%accessories, %i) != -1; %i += 2)
			{
				%item = GetWord(%accessories, %i);
				%count = GetWord(%accessories, %i + 1);
				if(%count > 0)
				{
					// Check if we've already added this item to the order list
					if(String::findSubStr(%seenItems, " " @ %item @ " ") == -1)
					{
						%orderList = %orderList @ " " @ %item @ " Accessories";
						%seenItems = %seenItems @ " " @ %item @ " ";
					}
				}
			}
		}
		// Check Other
		%other = fetchData(%clientId, "Other");
		if(%other != "")
		{
			for(%i = 0; GetWord(%other, %i) != -1; %i += 2)
			{
				%item = GetWord(%other, %i);
				%count = GetWord(%other, %i + 1);
				if(%count > 0)
				{
					// Check if we've already added this item to the order list
					if(String::findSubStr(%seenItems, " " @ %item @ " ") == -1)
					{
						%orderList = %orderList @ " " @ %item @ " Other";
						%seenItems = %seenItems @ " " @ %item @ " ";
					}
				}
			}
		}
		%clientId.beltDepositItemOrder = String::NEWgetSubStr(%orderList, 1, 99999);
	
	Client::buildMenu(%clientId, "Deposit Backpack Items:", "BeltDeposit", true);
	
	%cnt = 1;
	%addedItems = ""; // Track items we've already added to prevent duplicates
	// Use stored order if available
	if(%clientId.beltDepositItemOrder != "")
	{
		%storedOrder = %clientId.beltDepositItemOrder;
		for(%i = 0; (%itemData = getWord(%storedOrder, %i)) != -1; %i += 2)
		{
			%item = %itemData;
			%category = getWord(%storedOrder, %i + 1);
			// Check if we've already added this item
			if(String::findSubStr(%addedItems, " " @ %item @ " ") == -1)
			{
			%count = Belt::HasThisStuff(%clientId, %item);
			if(%count > 0)
			{
					%itemName = $BeltItem[%item, "Name"];
					if(%itemName == "")
					{
						// Fallback to AccessoryVar for non-belt items
				%itemName = $AccessoryVar[%item, $Name];
				if(%itemName == "")
					%itemName = %item;
					}
				Client::addMenuItem(%clientId, %cnt @ %itemName @ " (" @ %count @ ")", %item @ " " @ %category);
				%cnt++;
					// Mark this item as added
					%addedItems = %addedItems @ " " @ %item @ " ";
				}
			}
		}
	}
	else
	{
		// Fallback to normal order if no stored order
		%addedItems = ""; // Track items we've already added to prevent duplicates
		// Check QuestItems
		%questItems = fetchData(%clientId, "QuestItems");
		if(%questItems != "")
		{
			for(%i = 0; GetWord(%questItems, %i) != -1; %i += 2)
			{
				%item = GetWord(%questItems, %i);
				%count = GetWord(%questItems, %i + 1);
				if(%count > 0)
				{
					// Check if we've already added this item
					if(String::findSubStr(%addedItems, " " @ %item @ " ") == -1)
					{
						%itemName = $BeltItem[%item, "Name"];
						if(%itemName == "")
						{
							// Fallback to AccessoryVar for non-belt items
					%itemName = $AccessoryVar[%item, $Name];
					if(%itemName == "")
						%itemName = %item;
						}
					Client::addMenuItem(%clientId, %cnt @ %itemName @ " (" @ %count @ ")", %item @ " QuestItems");
					%cnt++;
						// Mark this item as added
						%addedItems = %addedItems @ " " @ %item @ " ";
					}
				}
			}
		}
		
		// Check KeyItems
		%keyItems = fetchData(%clientId, "KeyItems");
		if(%keyItems != "")
		{
			for(%i = 0; GetWord(%keyItems, %i) != -1; %i += 2)
			{
				%item = GetWord(%keyItems, %i);
				%count = GetWord(%keyItems, %i + 1);
				if(%count > 0)
				{
					// Check if we've already added this item
					if(String::findSubStr(%addedItems, " " @ %item @ " ") == -1)
					{
						%itemName = $BeltItem[%item, "Name"];
						if(%itemName == "")
						{
							// Fallback to AccessoryVar for non-belt items
					%itemName = $AccessoryVar[%item, $Name];
					if(%itemName == "")
						%itemName = %item;
						}
					Client::addMenuItem(%clientId, %cnt @ %itemName @ " (" @ %count @ ")", %item @ " KeyItems");
					%cnt++;
						// Mark this item as added
						%addedItems = %addedItems @ " " @ %item @ " ";
					}
				}
			}
		}
		
		// Check Consumables
		%consumables = fetchData(%clientId, "Consumables");
		if(%consumables != "")
		{
			for(%i = 0; GetWord(%consumables, %i) != -1; %i += 2)
			{
				%item = GetWord(%consumables, %i);
				%count = GetWord(%consumables, %i + 1);
				if(%count > 0)
				{
					// Check if we've already added this item
					if(String::findSubStr(%addedItems, " " @ %item @ " ") == -1)
					{
						%itemName = $BeltItem[%item, "Name"];
						if(%itemName == "")
						{
							// Fallback to AccessoryVar for non-belt items
							%itemName = $AccessoryVar[%item, $Name];
							if(%itemName == "")
								%itemName = %item;
						}
						Client::addMenuItem(%clientId, %cnt @ %itemName @ " (" @ %count @ ")", %item @ " Consumables");
						%cnt++;
						// Mark this item as added
						%addedItems = %addedItems @ " " @ %item @ " ";
					}
				}
			}
		}

		// Check Armor
		%armorItems = fetchData(%clientId, "Armor");
		if(%armorItems != "")
		{
			for(%i = 0; GetWord(%armorItems, %i) != -1; %i += 2)
			{
				%item = GetWord(%armorItems, %i);
				%count = GetWord(%armorItems, %i + 1);
				if(%count > 0)
				{
					// Check if we've already added this item
					if(String::findSubStr(%addedItems, " " @ %item @ " ") == -1)
					{
						%itemName = $BeltItem[%item, "Name"];
						if(%itemName == "")
						{
							%itemName = $AccessoryVar[%item, $Name];
							if(%itemName == "")
								%itemName = %item;
						}
						Client::addMenuItem(%clientId, %cnt @ %itemName @ " (" @ %count @ ")", %item @ " Armor");
						%cnt++;
						// Mark this item as added
						%addedItems = %addedItems @ " " @ %item @ " ";
					}
				}
			}
		}

		// Check Accessories
		%accessoryItems = fetchData(%clientId, "Accessories");
		if(%accessoryItems != "")
		{
			for(%i = 0; GetWord(%accessoryItems, %i) != -1; %i += 2)
			{
				%item = GetWord(%accessoryItems, %i);
				%count = GetWord(%accessoryItems, %i + 1);
				if(%count > 0)
				{
					// Check if we've already added this item
					if(String::findSubStr(%addedItems, " " @ %item @ " ") == -1)
					{
						%itemName = $BeltItem[%item, "Name"];
						if(%itemName == "")
						{
							%itemName = $AccessoryVar[%item, $Name];
							if(%itemName == "")
								%itemName = %item;
						}
						Client::addMenuItem(%clientId, %cnt @ %itemName @ " (" @ %count @ ")", %item @ " Accessories");
						%cnt++;
						// Mark this item as added
						%addedItems = %addedItems @ " " @ %item @ " ";
					}
				}
			}
		}

		// Check Other
		%otherItems = fetchData(%clientId, "Other");
		if(%otherItems != "")
		{
			for(%i = 0; GetWord(%otherItems, %i) != -1; %i += 2)
			{
				%item = GetWord(%otherItems, %i);
				%count = GetWord(%otherItems, %i + 1);
				if(%count > 0)
				{
					// Check if we've already added this item
					if(String::findSubStr(%addedItems, " " @ %item @ " ") == -1)
					{
						%itemName = $BeltItem[%item, "Name"];
						if(%itemName == "")
						{
							%itemName = $AccessoryVar[%item, $Name];
							if(%itemName == "")
								%itemName = %item;
						}
						Client::addMenuItem(%clientId, %cnt @ %itemName @ " (" @ %count @ ")", %item @ " Other");
						%cnt++;
						// Mark this item as added
						%addedItems = %addedItems @ " " @ %item @ " ";
					}
				}
			}
		}
	}
	
	if(%cnt == 1)
		Client::addMenuItem(%clientId, "1No backpack items to deposit", "none");
	
	Client::addMenuItem(%clientId, "xBack", "back");
}

function processMenuBeltDeposit(%clientId, %option)
{
	%clientName = Client::getName(%clientId);
	echo("DEBUG processMenuBeltDeposit: ENTER - clientId=" @ %clientId @ " (" @ %clientName @ "), option='" @ %option @ "'");
	
	if(%option == "back")
	{
		echo("DEBUG processMenuBeltDeposit: Back option selected");
		// Clear stored order when menu is closed
		%clientId.beltDepositItemOrder = "";
		Belt::Store(%clientId, %clientId.currentBeltBank);
		return;
	}
	
	if(%option == "none")
	{
		echo("DEBUG processMenuBeltDeposit: No items to deposit");
		return;
	}
	
	%item = GetWord(%option, 0);
	%category = GetWord(%option, 1);
	echo("DEBUG processMenuBeltDeposit: Parsed - item='" @ %item @ "', category='" @ %category @ "'");
	
	// Show the 5/10/All menu instead of directly depositing
	echo("DEBUG processMenuBeltDeposit: Showing deposit menu for item");
	MenuSellBeltItemFinal(%clientId, %item, %category, "store");
}

function Belt::ShowWithdrawMenu(%clientId)
{
	%clientName = Client::getName(%clientId);
	echo("DEBUG Belt::ShowWithdrawMenu: ENTER - clientId=" @ %clientId @ " (" @ %clientName @ ")");
	
	// Clean up BeltStorage first - remove any invalid entries (item "0", count 0, etc.)
	%beltStorage = fetchData(%clientId, "BeltStorage");
	echo("DEBUG Belt::ShowWithdrawMenu: BEFORE cleanup BeltStorage='" @ %beltStorage @ "'");
	%cleanedStorage = "";
	%removedCount = 0;
	for(%i = 0; GetWord(%beltStorage, %i) != -1; %i+=2)
	{
		%item = GetWord(%beltStorage, %i);
		%count = GetWord(%beltStorage, %i+1);
		echo("DEBUG Belt::ShowWithdrawMenu: Checking item[" @ %i @ "]='" @ %item @ "', count[" @ (%i+1) @ "]='" @ %count @ "'");
		// Convert count to numeric to properly handle negative values like "-1" or "-0"
		%countNum = %count * 1;
		// Only keep valid entries (item is not empty/"0", count is not -1 or "0", and count > 0)
		if(%item != "" && %item != -1 && %item != "0" && %count != "" && %count != -1 && %count != "-1" && %count != "0" && %countNum > 0)
		{
			%cleanedStorage = %cleanedStorage @ %item @ " " @ %count @ " ";
			echo("DEBUG Belt::ShowWithdrawMenu: Added valid entry - item='" @ %item @ "', count=" @ %count);
		}
		else
		{
			echo("DEBUG Belt::ShowWithdrawMenu: Skipping invalid entry - item='" @ %item @ "', count='" @ %count @ "'");
			%removedCount++;
		}
	}
	// Update BeltStorage if it was cleaned (remove trailing space)
	if(%cleanedStorage != %beltStorage)
	{
		echo("DEBUG Belt::ShowWithdrawMenu: Cleaned " @ %removedCount @ " invalid entries from BeltStorage");
		// Remove trailing space if present
		%len = String::len(%cleanedStorage);
		if(%len > 0 && String::getSubStr(%cleanedStorage, %len-1, 1) == " ")
			%cleanedStorage = String::getSubStr(%cleanedStorage, 0, %len-1);
		echo("DEBUG Belt::ShowWithdrawMenu: AFTER cleanup BeltStorage='" @ %cleanedStorage @ "'");
		storeData(%clientId, "BeltStorage", %cleanedStorage);
		%beltStorage = %cleanedStorage;
	}
	else
	{
		echo("DEBUG Belt::ShowWithdrawMenu: No cleanup needed");
	}
	
	// Store the original order when first opening the menu
	if(%clientId.beltWithdrawItemOrder == "")
	{
		%orderList = "";
		for(%i = 0; GetWord(%beltStorage, %i) != -1; %i+=2)
		{
			%item = GetWord(%beltStorage, %i);
			%count = GetWord(%beltStorage, %i+1);
			if(%item != "" && %item != -1 && %item != "0" && %count > 0)
			{
				%orderList = %orderList @ " " @ %item;
			}
		}
		%clientId.beltWithdrawItemOrder = String::NEWgetSubStr(%orderList, 1, 99999);
	}
	
	Client::buildMenu(%clientId, "Withdraw Backpack Items:", "BeltWithdraw", true);
	
	%cnt = 1;
	
	// Use stored order if available
	if(%clientId.beltWithdrawItemOrder != "")
	{
		%storedOrder = %clientId.beltWithdrawItemOrder;
		for(%i = 0; (%item = getWord(%storedOrder, %i)) != -1; %i++)
		{
			%count = Belt::ItemCount(%item, %beltStorage);
			if(%count > 0)
			{
				%itemName = $BeltItem[%item, "Name"];
				if(%itemName == "")
				{
					// Fallback to AccessoryVar for non-belt items
				%itemName = $AccessoryVar[%item, $Name];
				if(%itemName == "")
					%itemName = %item;
				}
				Client::addMenuItem(%clientId, %cnt @ %itemName @ " (" @ %count @ ")", %item);
				%cnt++;
			}
		}
	}
	else
	{
		// Fallback to normal order if no stored order
		for(%i = 0; GetWord(%beltStorage, %i) != -1; %i+=2)
		{
			%item = GetWord(%beltStorage, %i);
			%count = GetWord(%beltStorage, %i+1);
			
			// Skip invalid entries (item is "0" or empty, or count is 0 or negative)
			if(%item == "" || %item == -1 || %item == "0" || %count <= 0)
				continue;
			
			%itemName = $BeltItem[%item, "Name"];
			if(%itemName == "")
			{
				// Fallback to AccessoryVar for non-belt items
			%itemName = $AccessoryVar[%item, $Name];
			if(%itemName == "")
				%itemName = %item;
			}
			
			Client::addMenuItem(%clientId, %cnt @ %itemName @ " (" @ %count @ ")", %item);
			%cnt++;
		}
	}
	
	if(%cnt == 1)
		Client::addMenuItem(%clientId, "1No items in storage", "none");
	
	Client::addMenuItem(%clientId, "xBack", "back");
}

function processMenuBeltWithdraw(%clientId, %option)
{
	%clientName = Client::getName(%clientId);
	echo("DEBUG processMenuBeltWithdraw: ENTER - clientId=" @ %clientId @ " (" @ %clientName @ "), option='" @ %option @ "'");
	
	if(%option == "back")
	{
		echo("DEBUG processMenuBeltWithdraw: Back option selected");
		// Clear stored order when menu is closed
		%clientId.beltWithdrawItemOrder = "";
		Belt::Store(%clientId, %clientId.currentBeltBank);
		return;
	}
	
	if(%option == "none")
	{
		echo("DEBUG processMenuBeltWithdraw: No items in storage");
		return;
	}
	
	%item = %option;
	echo("DEBUG processMenuBeltWithdraw: Item='" @ %item @ "'");
	
	// Validate item is not empty
	if(%item == "" || %item == -1)
	{
		echo("ERROR: processMenuBeltWithdraw - Invalid item parameter: '" @ %item @ "' from option: '" @ %option @ "' ClientId: " @ %clientId @ " (" @ %clientName @ ")");
		return;
	}
	
	// Determine which category this item belongs to using BeltItem lookup
	// First try the item as-is (it might already be the registered name from BeltStorage)
	%category = $BeltItem[%item, "Type"];
	echo("DEBUG processMenuBeltWithdraw: Lookup category='" @ %category @ "'");
	
	if(%category == "")
	{
		echo("DEBUG processMenuBeltWithdraw: Category not found, defaulting to QuestItems");
		// Item might not be in BeltItem registry directly - try to find it by iterating
		// This shouldn't happen if BeltStorage only contains registered item names, but handle it anyway
		%category = "QuestItems"; // Default category
		
		// Try to find the item in BeltStorage to confirm it exists
		%beltStorage = fetchData(%clientId, "BeltStorage");
		echo("DEBUG processMenuBeltWithdraw: BeltStorage='" @ %beltStorage @ "'");
		%count = Belt::ItemCount(%item, %beltStorage);
		echo("DEBUG processMenuBeltWithdraw: Item count in storage=" @ %count);
		
		if(%count <= 0)
		{
			echo("ERROR: processMenuBeltWithdraw - Item '" @ %item @ "' not found in BeltStorage! ClientId: " @ %clientId @ " (" @ %clientName @ ")");
			return;
		}
	}
	
	// Show the 5/10/All menu instead of directly withdrawing
	echo("DEBUG processMenuBeltWithdraw: Showing withdraw menu for item '" @ %item @ "' category='" @ %category @ "'");
	MenuSellBeltItemFinal(%clientId, %item, %category, "withdraw");
}