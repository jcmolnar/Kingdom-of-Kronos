function Game::pickObserverSpawn(%clientId)
{
	dbecho($dbechoMode2, "Game::pickObserverSpawn(" @ %clientId @ ")");

	%group = nameToID("MissionGroup\\ObserverDropPoints");
	%count = Group::objectCount(%group);

	if(%group == -1 || !%count)
		%group = nameToID("MissionGroup\\Teams\\team0\\DropPoints");
	%count = Group::objectCount(%group);
	if(%group == -1 || !%count)
		%group = nameToID("MissionGroup\\Teams\\team1\\DropPoints");
	%count = Group::objectCount(%group);
	if(%group == -1 || !%count)
		return -1;
	%spawnIdx = %clientId.lastObserverSpawn + 1;
	if(%spawnIdx >= %count)
		%spawnIdx = 0;
	%clientId.lastObserverSpawn = %spawnIdx;

	return Group::getObject(%group, %spawnIdx);
}

function Game::pickPlayerSpawn(%clientId, %respawn)
{
	dbecho($dbechoMode2, "Game::pickPlayerSpawn(" @ %clientId @ ", " @ %respawn @ ")");

	
	%lastzone = fetchData(%clientId, "lastzone");
	
	if(%lastzone == "" || %lastzone == -1)
	{
		%group = nameToID("MissionGroup/Teams/team0/DropPoints");
	}
	else
	{
		// Try zone's DropPoints first (original behavior - matches old code)
		%group = nameToID("MissionGroup/Zones/" @ Object::getName(%lastzone) @ "/DropPoints");
		%count = Group::objectCount(%group);
		// Only fall back to default if zone's DropPoints don't exist or are empty
		if(%group == -1 || !%count)
		{
			%group = nameToID("MissionGroup/Teams/team0/DropPoints");
		}
	}
	
	%count = Group::objectCount(%group);
	if(!%count)
	{
		return -1;
	}
	%spawnIdx = floor(getRandom() * (%count - 0.1));
	%value = %count;

	for(%i = %spawnIdx; %i < %value; %i++)
	{
		%set = newObject("set",SimSet);
		%obj = Group::getObject(%group, %i);
		%objPos = GameBase::getPosition(%obj);
		if(containerBoxFillSet(%set,$SimPlayerObjectType|$VehicleObjectType,%objPos,2,2,4,0) == 0)
		{
			deleteObject(%set);
			return %obj;		
		}
		if(%i == %count - 1)
		{
			%i = -1;
			%value = %spawnIdx;
		}
		deleteObject(%set);
	}
	return false;
}

function Game::playerSpawn(%clientId, %respawn)
{
	dbecho($dbechoMode2, "Game::playerSpawn(" @ %clientId @ ", " @ %respawn @ ")");

	if(!$ghosting)
		return false;

	Client::clearItemShopping(%clientId);
	Client::clearItemBuying(%clientId);

	if(fetchData(%clientId, "isMimic"))
	{
		storeData(%clientId, "RACE", Client::getGender(%clientId) @ "Human");
		storeData(%clientId, "isMimic", "");
	}

	if(%clientId.RespawnMeInArena)
	{
		%group = nameToID("MissionGroup\\TheArena\\TeleportEntranceMarkers");

		if(%group != -1)
		{
			%num = Group::objectCount(%group);

			%r = floor(getRandom() * %num);
			%spawnMarker = Group::getObject(%group, %r);
		}
		else
		{
			%spawnMarker = Game::pickPlayerSpawn(%clientId, %respawn);
		}

		RefreshArenaTextBox(%clientId);
	}
	else
	{
		%spawnMarker = Game::pickPlayerSpawn(%clientId, %respawn);

		//the player is spawning normally, ie. not in the arena
		storeData(%clientId, "inArena", "");
		CloseArenaTextBox(%clientId);
	}

	if(%spawnMarker && %spawnMarker != -1)
	{
		%clientId.guiLock = "";
		%clientId.dead = "";
		if(%spawnMarker == -1)
		{
			%spawnPos = "0 0 600";
			%spawnRot = "0 0 0";
		}
		else
		{
			%campPos = fetchData(%clientId, "campPos");
			// Check if player has a valid campPos and this is their first spawn (not a respawn)
			// Also check that campPos is not "0" or empty/whitespace
			if(%campPos != "" && %campPos != "0" && %campPos != -1 && String::len(%campPos) > 3 && !%respawn)
			{
				//if the player HAS a valid campPos and it is his FIRST TIME SPAWNING, then spawn him at this campPos
				%spawnPos = %campPos;
				%spawnRot = fetchData(%clientId, "campRot");
				if(%spawnRot == "" || %spawnRot == "0" || %spawnRot == -1)
					%spawnRot = "0 0 0";
			}
			else
			{
				// Use spawn marker position (default for new players or respawns)
				%spawnPos = GameBase::getPosition(%spawnMarker);
				%spawnRot = GameBase::getRotation(%spawnMarker);
				
				// Validate spawn position - ensure Z coordinate is not underground
				%posZ = GetWord(%spawnPos, 2);
				if(%posZ == "" || %posZ == -1 || (%posZ * 1) < 0)
				{
					// Get X and Y from marker, but use a safe Z height
					%posX = GetWord(%spawnPos, 0);
					%posY = GetWord(%spawnPos, 1);
					%spawnPos = %posX @ " " @ %posY @ " 100";  // Set Z to 100 (above ground)
				}
			}
		}

		%armor = $RaceToArmorType[fetchData(%clientId, "RACE")];

		%pl = spawnPlayer(%armor, %spawnPos, %spawnRot);
		PlaySound(SoundSpawn2, %spawnPos);
		GameBase::startFadeIn(Client::getOwnedObject(%clientId));

		echo("SPAWN: cl:" @ %clientId @ " pl:" @ %pl @ " marker:" @ %spawnMarker @ " position: " @ %spawnPos @ " armor:" @ %armor);

		if(%pl != -1)
		{
			UpdateTeam(%clientId);
			GameBase::setTeam(%pl, Client::getTeam(%clientId));
			Client::setOwnedObject(%clientId, %pl);
			Client::setControlObject(%clientId, %pl);
			Game::playerSpawned(%pl, %clientId, %armor, %respawn);

			if(%respawn)	      
			{
				setHP(%clientId, fetchData(%clientId, "MaxHP"));
				setMANA(%clientId, fetchData(%clientId, "MaxMANA"));
			}
		else
		{
			%playerObj = Client::getOwnedObject(%clientId);
			%tmphp = fetchData(%clientId, "tmphp");
			%tmpmana = fetchData(%clientId, "tmpmana");
			
			// For new spawns, if tmphp is empty or 0, use MaxHP instead to prevent setting HP to 0 (which kills player)
			if(%tmphp == "" || %tmphp == "0" || %tmphp == -1 || (%tmphp * 1) <= 0)
			{
				%tmphp = fetchData(%clientId, "MaxHP");
				if(%tmphp == "" || %tmphp == 0 || %tmphp == -1)
				{
					%skipHP = True;
				}
			}
			
			// For new spawns, if tmpmana is empty or 0, use MaxMANA instead
			if(%tmpmana == "" || %tmpmana == "0" || %tmpmana == -1 || (%tmpmana * 1) <= 0)
			{
				%tmpmana = fetchData(%clientId, "MaxMANA");
				if(%tmpmana == "" || %tmpmana == 0 || %tmpmana == -1)
				{
					%skipMANA = True;
				}
			}
			
			if(!%skipHP)
			{
				setHP(%clientId, %tmphp);
			}
			else
			{
			}
			
			%playerObjAfterHP = Client::getOwnedObject(%clientId);
			if(%playerObjAfterHP == -1 || %playerObjAfterHP == "")
			{
			}
			else if(!%skipMANA)
			{
				setMANA(%clientId, %tmpmana);
			}
			else
			{
			}
			
			storeData(%clientId, "tmphp", "");
			storeData(%clientId, "tmpmana", "");
		}
			storeData(%clientId.possessId, "dumbAIflag", "");
		}
		return true;
	}
	else
	{
		Client::sendMessage(%clientId,0,"Sorry No Respawn Positions Are Empty - Try again later ");
		return false;
	}
}

function Game::playerSpawned(%pl, %clientId, %armor)
{
	dbecho($dbechoMode2, "Game::playerSpawned(" @ %pl @ ", " @ %clientId @ ", " @ %armor @ ")");


	storeData(%clientId, "HasLoadedAndSpawned", True);

	if(%clientId.RespawnMeInArena)
	{
		//give him his equipment back
		RestorePreviousEquipment(%clientId);

		%clientId.RespawnMeInArena = "";
	}
	else
	{
		%spawnStuff = fetchData(%clientId, "spawnStuff");
		GiveThisStuff(%clientId, %spawnStuff, False);
	}

	%lck = fetchData(%clientId, "LCK");
	if(%lck < 0)
	{
		storeData(%clientId, "LCK", 0);
	}

	RefreshAll(%clientId);
	
	// Disable default command menu (Change Teams, etc) to allow RPG HUD on TAB
	remoteEval(%clientId, "setCommandStatus", 0);
	schedule("if(Client::getName(" @ %clientId @ ") != \"\") remoteEval(" @ %clientId @ ", \"setCommandStatus\", 0);", 0.5);
	schedule("if(Client::getName(" @ %clientId @ ") != \"\") remoteEval(" @ %clientId @ ", \"setCommandStatus\", 0);", 1.0);
	schedule("if(Client::getName(" @ %clientId @ ") != \"\") remoteEval(" @ %clientId @ ", \"setCommandStatus\", 0);", 2.0);
} 

function Game::autoRespawn(%clientId)
{
	dbecho($dbechoMode2, "Game::autoRespawn(" @ %clientId @ ")");

	if(%clientId.dead == 1)
		Game::playerSpawn(%clientId, True);
}
