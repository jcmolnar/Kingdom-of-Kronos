function String::len(%string)
{
	//dbecho($dbechoMode, "String::len(" @ %string @ ")");

	%chunk = 10;
	%length = 0;

	for(%i = 0; String::getSubStr(%string, %i, 1) != ""; %i += %chunk)
		%length += %chunk;
	%length -= %chunk;

	%checkstr = String::getSubStr(%string, %length, 99999);
	for(%k = 0; String::getSubStr(%checkstr, %k, 1) != ""; %k++)
		%length++;

	if(%length == -%chunk)
		%length = 0;

	return %length;
}

function String::replace(%string, %search, %replace)
{
	dbecho($dbechoMode, "String::replace(" @ %string @ ", " @ %search @ ", " @ %replace @ ")");

	%loc = String::findSubStr(%string, %search);

	if(%loc != -1)
	{
		%ls = String::len(%search);

		%part1 = String::NEWgetSubStr(%string, 0, %loc);
		%part2 = String::NEWgetSubStr(%string, %loc + %ls, 99999);

		%string = %part1 @ %replace @ %part2;
	}

	return %string;
}

function String::create(%c, %len)
{
	dbecho($dbechoMode, "String::create(" @ %c @ ", " @ %len @ ")");

	%f = "";
	for(%i = 1; %i <= %len; %i++)
		%f = %f @ %c;

	return %f;
}

function String::ofindSubStr(%s, %f, %o)
{
	dbecho($dbechoMode, "String::ofindSubStr(" @ %s @ ", " @ %f @ ", " @ %o @ ")");

	%ns = String::NEWgetSubStr(%s, %o, 99999);
	return String::findSubStr(%ns, %f);
}

function viewGroupList(%clientId)
{
	dbecho($dbechoMode, "viewGroupList(" @ %clientId @ ")");

	bottomprint(%clientId, fetchData(%clientId, "grouplist"), 8);
}
function updateSpawnStuff(%clientId)
{
	dbecho($dbechoMode2, "updateSpawnStuff(" @ %clientId @ ")");

	//determine what player is carrying and transfer to spawnList
	%s = "";
	%player = Client::getOwnedObject(%clientId);
	if(%player == -1)
		return ""; // Player object doesn't exist
	
	%max = getNumItems();
	for(%i = 0; %i < %max; %i++)
	{
		%checkItem = getItemData(%i);
		// CRITICAL: Never save flags to spawnStuff - flags are mission objectives, not player inventory
		if(%checkItem == "Flag" || %checkItem == Flag)
			continue;
		
		%itemcount = Player::getItemCount(%clientId, %checkItem);
		if(%itemcount)
			%s = %s @ %checkItem @ " " @ %itemcount @ " ";
	}

	storeData(%clientId, "spawnStuff", %s);

	return %s;
}
function isInSpellList(%name, %sname)
{
	dbecho($dbechoMode, "isInSpellList(" @ %name @ ", " @ %sname @ ")");

	%sname = %sname @ $sepchar;

	//check if %sname (includes delimiter) is in %name's SpellList
	if(String::findSubStr($SpellList[%name], %sname) != -1)
		return 1;
	else
		return 0;
}
function getSpellAtPos(%name, %pos)
{
	dbecho($dbechoMode, "getSpellAtPos(" @ %name @ ", " @ %pos @ ")");

	%s = $SpellList[%name];
	%n = 0;
	%oldpos = 0;

	for(%i=0; %i<=String::len(%s); %i++)
	{
		%a = String::getSubStr(%s, %i, 1);
		if(%a == ",")
		{
			%n++;
			if(%n == %pos && (%i+1) <= String::len(%s))
			{
				return String::getSubStr(%s, %oldpos, (%i-1)-%oldpos+1);
			}
			%oldpos = %i+1;
		}
	}
	return -1;
}
function countNumSpells(%clientId)
{
	dbecho($dbechoMode, "countNumSpells(" @ %clientId @ ")");

	%name = Client::getName(%clientId);
	%s = $SpellList[%name];
	%n = 0;

	for(%i=0; %i<=String::len(%s); %i++)
	{
		%a = String::getSubStr(%s, %i, 1);
		if(%a == ",") %n++;
	}

	return %n;
}
function StartRecord(%clientId)
{
	dbecho($dbechoMode, "StartRecord(" @ %clientId @ ")");

	//clear variables
	$recording[%clientId] = "";
	for(%t=1; $rec::type[%t] != ""; %t++)
		$rec::type[%t] = "";
	$recCount[%clientId]=0;

	$recording[%clientId] = 1;
}
function StopRecord(%clientId, %f)
{
	dbecho($dbechoMode, "StopRecord(" @ %clientId @ ", " @ %f @ ")");

	//%f = String::replace(%f, "\", "\\");
	File::delete(%f);
	export("rec::*", "temp\\" @ %f, false);

	//clear variables
	$recording[%clientId] = "";
	for(%t=1; $rec::type[%t] != ""; %t++)
		$rec::type[%t] = "";
	$recCount[%clientId]=0;
}
function AddObjectToRec(%clientId, %a, %pos, %rot)
{
	dbecho($dbechoMode, "AddObjectToRec(" @ %clientId @ ", " @ %a @ ", " @ %pos @ ", " @ %rot @ ")");

	//%pos: deploy position
	//%rot: player's rotation

	$recCount[%clientId]++;

	if($recCount[%clientId] == 1)
	{
		//this is the first object placed, so use it as a reference object
		$recRefpos[%clientId] = %pos;
		$recRefrot[%clientId] = %rot;
	}
	$rec::type[$recCount[%clientId]] = %a;

	$rec::pos[$recCount[%clientId]] = Vector::sub(%pos, $recRefpos[%clientId]);

	$rec::rot[$recCount[%clientId]] = %rot;
}
function DeployBase(%clientId, %f, %refPos, %refRot)
{
	dbecho($dbechoMode, "DeployBase(" @ %clientId @ ", " @ %f @ ", " @ %refPos @ ", " @ %refRot @ ")");

	//%refPos: deploy position
	//%refRot: player's rotation

	for(%t=1; $rec::type[%t] != ""; %t++)
		$rec::type[%t] = "";

	$ConsoleWorld::DefaultSearchPath = $ConsoleWorld::DefaultSearchPath;	//thanks Presto
	exec(%f);
	
	$baseIndex++;
	for(%i = 1; $rec::type[%i] != ""; %i++)
	{
		if(%i == 1)
		{
			%newpos = %refPos;
			%newrot = $rec::rot[%i];
		}
		else
		{
			%a = Vector::add(%refPos, $rec::pos[%i]);

			%newpos = %a;
			%newrot = $rec::rot[%i];
		}

		if($rec::type[%i] == 1)
		{
			%a = DepPlatSmallHorz;
		}
		else if($rec::type[%i] == 2)
		{
			%a = DepPlatMediumHorz;
		}
		else if($rec::type[%i] == 3)
		{
			%a = DepPlatLargeHorz;
		}
		else if($rec::type[%i] == 4)
		{
			%a = DepPlatSmallVert;
			%newrot = "0 1.5708 " @ GetWord(%newrot, 2) + "1.5708";
			%newpos = GetWord(%newpos, 0) @ " " @ GetWord(%newpos, 1) @ " " @ (GetWord(%newpos, 2) + 2);
		}
		else if($rec::type[%i] == 5)
		{
			%a = DepPlatMediumVert;
			%newrot = "0 1.5708 " @ GetWord(%newrot, 2) + "1.5708";
			%newpos = GetWord(%newpos, 0) @ " " @ GetWord(%newpos, 1) @ " " @ (GetWord(%newpos, 2) + 3);
		}
		else if($rec::type[%i] == 6)
		{
			%a = DepPlatLargeVert;
			%newrot = "0 1.5708 " @ GetWord(%newrot, 2) + "1.5708";
			%newpos = GetWord(%newpos, 0) @ " " @ GetWord(%newpos, 1) @ " " @ (GetWord(%newpos, 2) + 4.5);
		}
		else if($rec::type[%i] == 7)
		{
			%a = StaticDoorForceField;
		}

		%depbase = newObject("","StaticShape",%a,true);
		addToSet("MissionCleanup", %depbase);
		GameBase::setTeam(%depbase, GameBase::getTeam(%clientId));
		GameBase::setPosition(%depbase, %newpos);
		GameBase::setRotation(%depbase, %newrot);
		GameBase::startFadeIn(%depbase);

		$owner[%depbase] = Client::getName(%clientId);
	}

	Client::sendMessage(%clientId,0,"Base deployed");
}
function DoCamp(%clientId, %savecharTry)
{
	dbecho($dbechoMode, "DoCamp(" @ %clientId @ ", " @ %savecharTry @ ")");

	if(%savecharTry)
	{
		%vel = Item::getVelocity(%clientId);
		if(getWord(%vel, 2) > -500)
		{
			if(!IsDead(%clientId))
			{
				storeData(%clientId, "campPos", GameBase::getPosition(%clientId));
				storeData(%clientId, "campRot", GameBase::getRotation(%clientId));
			}
			return True;
		}
	}
	else
	{
		if(GameBase::isAtRest(%clientId))
		{
			storeData(%clientId, "campPos", GameBase::getPosition(%clientId));
			storeData(%clientId, "campRot", GameBase::getRotation(%clientId));
			return True;
		}
	}
	return False;
}
function SaveCharacter(%clientId)
{
	dbecho($dbechoMode2, "SaveCharacter(" @ %clientId @ ")");

	//first pass check
	if(%clientId.isInvalid || !fetchData(%clientId, "HasLoadedAndSpawned"))
		return False;
	
	// Prevent saving AI bots
	if(isRPGAI(%clientId))
		return False;

	//second pass check, will cause 4 line flood if the client is invalid
	//only do this as a "last resort" test.  if the player is detected to be dead, then there shouldn't be a problem
	%player = Client::getOwnedObject(%clientId);
	if(!IsDead(%clientId) && %player != -1)
	{
		Player::incItemCount(%clientId, Tool);
		%x = Player::getItemCount(%clientId, Tool);
		Player::decItemCount(%clientId, Tool);
		%y = Player::getItemCount(%clientId, Tool);
		if(%x == %y)
		{
			//echo("DEBUG SaveCharacter: ABORT - player inventory test failed (x=" @ %x @ ", y=" @ %y @ ")");
			return False;
		}
	}

	%name = Client::getName(%clientId);
	//echo("DEBUG SaveCharacter: Player = " @ %name @ " (" @ %clientId @ ")");

	if(!IsDead(%clientId) && !IsInRoster(%clientId) && !IsInArenaDueler(%clientId))
	{
		//echo("DEBUG SaveCharacter: Updating campPos and campRot from player position");
		storeData(%clientId, "campPos", GameBase::getPosition(%clientId));
		storeData(%clientId, "campRot", GameBase::getRotation(%clientId));
	}

	ClearFunkVar(%name);

	//the first identifier in the array is the player's name.
	//this is needed because we are using a global array ($funk::var), so if another player
	//attempts to save at the same time, then there won't be $funk::var's being overwritten

	//the second identifier in the array is either 0, 1, or 2
	//0: regular player variable
	//1: weapon/item
	//2: quest counters

	//the third identifier is simply for identifying what we're saving.

	//echo("DEBUG SaveCharacter: Saving character " @ %name @ " (" @ %clientId @ ")...");
	//echo("DEBUG SaveCharacter: Saving basic character data...");
	$funk::var["[\"" @ %name @ "\", 0, 1]"] = fetchData(%clientId, "RACE");
	$funk::var["[\"" @ %name @ "\", 0, 2]"] = fetchData(%clientId, "EXP");
	$funk::var["[\"" @ %name @ "\", 0, 3]"] = fetchData(%clientId, "campPos");
	$funk::var["[\"" @ %name @ "\", 0, 4]"] = fetchData(%clientId, "COINS");
	$funk::var["[\"" @ %name @ "\", 0, 5]"] = fetchData(%clientId, "isMimic");
	$funk::var["[\"" @ %name @ "\", 0, 6]"] = fetchData(%clientId, "BANK");
	$funk::var["[\"" @ %name @ "\", 0, 7]"] = Client::getName(%clientId);
	$funk::var["[\"" @ %name @ "\", 0, 8]"] = fetchData(%clientId, "grouplist");
	$funk::var["[\"" @ %name @ "\", 0, 9]"] = fetchData(%clientId, "defaultTalk");
	$funk::var["[\"" @ %name @ "\", 0, 10]"] = fetchData(%clientId, "password");
	$funk::var["[\"" @ %name @ "\", 0, 11]"] = fetchData(%clientId, "bounty");
	$funk::var["[\"" @ %name @ "\", 0, 12]"] = fetchData(%clientId, "inArena");
	$funk::var["[\"" @ %name @ "\", 0, 13]"] = fetchData(%clientId, "PlayerInfo");
	$funk::var["[\"" @ %name @ "\", 0, 14]"] = fetchData(%clientId, "deathmsg");
	//15 is done lower
	$funk::var["[\"" @ %name @ "\", 0, 16]"] = fetchData(%clientId, "BankStorage");
	$funk::var["[\"" @ %name @ "\", 0, 17]"] = fetchData(%clientId, "campRot");
	//echo("DEBUG SaveCharacter: campRot = '" @ fetchData(%clientId, "campRot") @ "'");
	
	//echo("DEBUG SaveCharacter: Normalizing HP/MANA before save...");
	// Normalize HP and MANA - prevent negative values from being saved
	%hp = fetchData(%clientId, "HP");
	//echo("DEBUG SaveCharacter: HP RAW = '" @ %hp @ "'");
	%hpNum = %hp * 1;
	if(%hp == "" || %hp == " " || %hp == "0" || %hp == "-0" || %hpNum < 0)
	{
		//echo("DEBUG SaveCharacter: HP was invalid (empty/0/-0/negative), normalizing to empty string");
		%hp = "";
	}
	$funk::var["[\"" @ %name @ "\", 0, 18]"] = %hp;
	//echo("DEBUG SaveCharacter: HP FINAL = '" @ %hp @ "'");
	
	%mana = fetchData(%clientId, "MANA");
	//echo("DEBUG SaveCharacter: MANA RAW = '" @ %mana @ "'");
	%manaNum = %mana * 1;
	if(%mana == "" || %mana == " " || %mana == "0" || %mana == "-0" || %manaNum < 0)
	{
		//echo("DEBUG SaveCharacter: MANA was invalid (empty/0/-0/negative), normalizing to empty string");
		%mana = "";
	}
	$funk::var["[\"" @ %name @ "\", 0, 19]"] = %mana;
	//echo("DEBUG SaveCharacter: MANA FINAL = '" @ %mana @ "'");
	$funk::var["[\"" @ %name @ "\", 0, 20]"] = fetchData(%clientId, "LCKconsequence");
	$funk::var["[\"" @ %name @ "\", 0, 21]"] = fetchData(%clientId, "RemortStep");
	$funk::var["[\"" @ %name @ "\", 0, 22]"] = fetchData(%clientId, "LCK");
	$funk::var["[\"" @ %name @ "\", 0, 23]"] = $rpgver;
	$funk::var["[\"" @ %name @ "\", 0, 26]"] = fetchData(%clientId, "GROUP");
	$funk::var["[\"" @ %name @ "\", 0, 27]"] = fetchData(%clientId, "CLASS");
	$funk::var["[\"" @ %name @ "\", 0, 28]"] = fetchData(%clientId, "SPcredits");
	//$funk::var["[\"" @ %name @ "\", 0, 29]"] = "";
	// CRITICAL: Ensure empty houses save as empty string, not "0"
	// GetHouseNumber returns "" for empty houses, but we need to ensure it's never saved as "0"
	%houseValue = fetchData(%clientId, "MyHouse");
	// Treat "0" and "House0" as empty (no house)
	if(%houseValue == "0" || %houseValue == "House0" || %houseValue == "house0")
		%houseValue = "";
	%houseNum = GetHouseNumber(%houseValue);
	// If houseNum is empty, 0, or "0", save as empty string (not "0")
	if(%houseNum == "" || %houseNum == 0 || %houseNum == "0")
		%houseNum = "";
	$funk::var["[\"" @ %name @ "\", 0, 30]"] = %houseNum;
	$funk::var["[\"" @ %name @ "\", 0, 31]"] = fetchData(%clientId, "RankPoints");
	$funk::var["[\"" @ %name @ "\", 0, 32]"] = fetchData(%clientId, "TournyRank");
	// Normalize equipped categories - use "0" for empty to match original inventory system behavior
	%questItems = fetchData(%clientId, "QuestItems");
	if(%questItems == "" || %questItems == " " || %questItems == "0")
		%questItems = "0";
	$funk::var["[\"" @ %name @ "\", 0, 35]"] = %questItems;
	//echo("DEBUG SaveCharacter: QuestItems = '" @ %questItems @ "'");
	
	%keyItems = fetchData(%clientId, "KeyItems");
	if(%keyItems == "" || %keyItems == " " || %keyItems == "0")
		%keyItems = "0";
	$funk::var["[\"" @ %name @ "\", 0, 36]"] = %keyItems;
	//echo("DEBUG SaveCharacter: KeyItems = '" @ %keyItems @ "'");
	
	%consumables = fetchData(%clientId, "Consumables");
	if(%consumables == "" || %consumables == " " || %consumables == "0")
		%consumables = "0";
	$funk::var["[\"" @ %name @ "\", 0, 37]"] = %consumables;
	//echo("DEBUG SaveCharacter: Consumables = '" @ %consumables @ "'");
	
	//echo("DEBUG SaveCharacter: Syncing StoredQuestItems/StoredKeyItems from BeltStorage...");
	// Sync StoredQuestItems and StoredKeyItems from BeltStorage before saving
	// This ensures saved data matches what's in bank storage
	// Validate and clean data to prevent negative values from being saved
	%beltStorage = fetchData(%clientId, "BeltStorage");
	//echo("DEBUG SaveCharacter: BeltStorage = '" @ %beltStorage @ "' (Player: " @ Client::getName(%clientId) @ ")");
	
	// Normalize "0" to empty string - "0" is not a valid belt storage value
	// If BeltStorage is just "0", it will be parsed as item='0', count='-1' (where -1 is end of string)
	// CRITICAL: If BeltStorage is empty but stored categories have data, rebuild BeltStorage from stored categories
	// This prevents data loss when BeltStorage gets cleared but stored categories still have items
	if(%beltStorage == "0" || %beltStorage == " " || %beltStorage == "")
	{
		//echo("DEBUG SaveCharacter: BeltStorage was '0'/empty, checking stored categories...");
		%storedQuestCheck = fetchData(%clientId, "StoredQuestItems");
		%storedKeyCheck = fetchData(%clientId, "StoredKeyItems");
		%storedConsumablesCheck = fetchData(%clientId, "StoredConsumables");
		%storedArmorCheck = fetchData(%clientId, "StoredArmor");
		%storedAccessoriesCheck = fetchData(%clientId, "StoredAccessories");
		%storedOtherCheck = fetchData(%clientId, "StoredOther");
		
		// Normalize "0" to empty string for checks
		if(%storedQuestCheck == "0" || %storedQuestCheck == " ") %storedQuestCheck = "";
		if(%storedKeyCheck == "0" || %storedKeyCheck == " ") %storedKeyCheck = "";
		if(%storedConsumablesCheck == "0" || %storedConsumablesCheck == " ") %storedConsumablesCheck = "";
		if(%storedArmorCheck == "0" || %storedArmorCheck == " ") %storedArmorCheck = "";
		if(%storedAccessoriesCheck == "0" || %storedAccessoriesCheck == " ") %storedAccessoriesCheck = "";
		if(%storedOtherCheck == "0" || %storedOtherCheck == " ") %storedOtherCheck = "";
		
		// If any stored category has data, rebuild BeltStorage from them
		if(%storedQuestCheck != "" || %storedKeyCheck != "" || %storedConsumablesCheck != "" || 
		   %storedArmorCheck != "" || %storedAccessoriesCheck != "" || %storedOtherCheck != "")
		{
			echo("DEBUG SaveCharacter: BeltStorage was empty but stored categories have data - rebuilding BeltStorage");
			%beltStorage = "";
			if(%storedQuestCheck != "")
				%beltStorage = %storedQuestCheck;
			if(%storedKeyCheck != "")
			{
				if(%beltStorage != "")
					%beltStorage = %beltStorage @ " " @ %storedKeyCheck;
				else
					%beltStorage = %storedKeyCheck;
			}
			if(%storedConsumablesCheck != "")
			{
				if(%beltStorage != "")
					%beltStorage = %beltStorage @ " " @ %storedConsumablesCheck;
				else
					%beltStorage = %storedConsumablesCheck;
			}
			if(%storedArmorCheck != "")
			{
				if(%beltStorage != "")
					%beltStorage = %beltStorage @ " " @ %storedArmorCheck;
				else
					%beltStorage = %storedArmorCheck;
			}
			if(%storedAccessoriesCheck != "")
			{
				if(%beltStorage != "")
					%beltStorage = %beltStorage @ " " @ %storedAccessoriesCheck;
				else
					%beltStorage = %storedAccessoriesCheck;
			}
			if(%storedOtherCheck != "")
			{
				if(%beltStorage != "")
					%beltStorage = %beltStorage @ " " @ %storedOtherCheck;
				else
					%beltStorage = %storedOtherCheck;
			}
			storeData(%clientId, "BeltStorage", %beltStorage);
			echo("DEBUG SaveCharacter: Rebuilt BeltStorage='" @ %beltStorage @ "'");
		}
		else
		{
			//echo("DEBUG SaveCharacter: BeltStorage was '0'/empty, normalizing to empty string");
			%beltStorage = "";
			storeData(%clientId, "BeltStorage", "");
		}
	}
	
	%storedQuest = "";
	%storedKey = "";
	%storedConsumables = "";
	%storedArmor = "";
	%storedAccessories = "";
	%storedOther = "";
	%processedCount = 0;
	%removedCount = 0;
	
	if(%beltStorage != "")
	{
		for(%i = 0; (%item = GetWord(%beltStorage, %i)) != -1; %i += 2)
		{
			%count = GetWord(%beltStorage, %i + 1);
			// Convert count to numeric to properly validate negative values
			%countNum = %count * 1;
			//echo("DEBUG SaveCharacter:   Processing belt item: item='" @ %item @ "', count='" @ %count @ "', countNum=" @ %countNum);
			
			// Only process valid entries (item is not empty/"0" and count is positive)
			if(%item != "" && %item != -1 && %item != "0" && %count != "" && %count != -1 && %countNum > 0)
			{
				// Check if it's a belt item first (uses $BeltItem), then fall back to $AccessoryVar
				%category = $BeltItem[%item, "Type"];
				if(%category == "" || %category == -1)
					%category = $AccessoryVar[%item, $Category];
				if(%category == "" || %category == -1)
					%category = "QuestItems"; // Default category
				
				//echo("DEBUG SaveCharacter:   Processing item='" @ %item @ "', count=" @ %count @ ", category='" @ %category @ "'");
				
				if(%category == "QuestItems")
				{
					if(%storedQuest != "")
						%storedQuest = %storedQuest @ " " @ %item @ " " @ %count;
					else
						%storedQuest = %item @ " " @ %count;
					//echo("DEBUG SaveCharacter:     Added to StoredQuestItems: item='" @ %item @ "', count=" @ %count);
				}
				else if(%category == "KeyItems")
				{
					if(%storedKey != "")
						%storedKey = %storedKey @ " " @ %item @ " " @ %count;
					else
						%storedKey = %item @ " " @ %count;
					//echo("DEBUG SaveCharacter:     Added to StoredKeyItems: item='" @ %item @ "', count=" @ %count);
				}
				else if(%category == "Consumables")
				{
					if(%storedConsumables != "")
						%storedConsumables = %storedConsumables @ " " @ %item @ " " @ %count;
					else
						%storedConsumables = %item @ " " @ %count;
					//echo("DEBUG SaveCharacter:     Added to StoredConsumables: item='" @ %item @ "', count=" @ %count @ ", category='" @ %category @ "'");
				}
				else if(%category == "Armor")
				{
					if(%storedArmor != "")
						%storedArmor = %storedArmor @ " " @ %item @ " " @ %count;
					else
						%storedArmor = %item @ " " @ %count;
					//echo("DEBUG SaveCharacter:     Added to StoredArmor");
				}
				else if(%category == "Accessories")
				{
					if(%storedAccessories != "")
						%storedAccessories = %storedAccessories @ " " @ %item @ " " @ %count;
					else
						%storedAccessories = %item @ " " @ %count;
					//echo("DEBUG SaveCharacter:     Added to StoredAccessories");
				}
				else if(%category == "Other")
				{
					if(%storedOther != "")
						%storedOther = %storedOther @ " " @ %item @ " " @ %count;
					else
						%storedOther = %item @ " " @ %count;
					//echo("DEBUG SaveCharacter:     Added to StoredOther");
				}
				%processedCount++;
			}
			else
			{
				//echo("DEBUG SaveCharacter:     REMOVED invalid entry: item='" @ %item @ "', count='" @ %count @ "'");
				%removedCount++;
			}
		}
	}
	
	// Always rebuild and save cleaned BeltStorage, even if no items were removed
	// This ensures BeltStorage is always clean and matches the stored categories
	%cleanedBeltStorage = "";
	if(%storedQuest != "")
		%cleanedBeltStorage = %storedQuest;
	if(%storedKey != "")
	{
		if(%cleanedBeltStorage != "")
			%cleanedBeltStorage = %cleanedBeltStorage @ " " @ %storedKey;
		else
			%cleanedBeltStorage = %storedKey;
	}
	if(%storedConsumables != "")
	{
		if(%cleanedBeltStorage != "")
			%cleanedBeltStorage = %cleanedBeltStorage @ " " @ %storedConsumables;
		else
			%cleanedBeltStorage = %storedConsumables;
	}
	if(%storedArmor != "")
	{
		if(%cleanedBeltStorage != "")
			%cleanedBeltStorage = %cleanedBeltStorage @ " " @ %storedArmor;
		else
			%cleanedBeltStorage = %storedArmor;
	}
	if(%storedAccessories != "")
	{
		if(%cleanedBeltStorage != "")
			%cleanedBeltStorage = %cleanedBeltStorage @ " " @ %storedAccessories;
		else
			%cleanedBeltStorage = %storedAccessories;
	}
	if(%storedOther != "")
	{
		if(%cleanedBeltStorage != "")
			%cleanedBeltStorage = %cleanedBeltStorage @ " " @ %storedOther;
		else
			%cleanedBeltStorage = %storedOther;
	}
	storeData(%clientId, "BeltStorage", %cleanedBeltStorage);
	if(%removedCount > 0)
		//echo("DEBUG SaveCharacter: Removed " @ %removedCount @ " invalid entries from belt storage");
	//echo("DEBUG SaveCharacter: Cleaned BeltStorage saved = '" @ %cleanedBeltStorage @ "'");
	
	// Update stored data if it changed (or clear if BeltStorage is empty)
	// Always update to ensure sync, even if empty (prevents stale data)
	storeData(%clientId, "StoredQuestItems", %storedQuest);
	storeData(%clientId, "StoredKeyItems", %storedKey);
	storeData(%clientId, "StoredConsumables", %storedConsumables);
	storeData(%clientId, "StoredArmor", %storedArmor);
	storeData(%clientId, "StoredAccessories", %storedAccessories);
	storeData(%clientId, "StoredOther", %storedOther);
	//echo("DEBUG SaveCharacter: StoredQuestItems = '" @ %storedQuest @ "'");
	//echo("DEBUG SaveCharacter: StoredKeyItems = '" @ %storedKey @ "'");
	//echo("DEBUG SaveCharacter: StoredConsumables = '" @ %storedConsumables @ "'");
	//echo("DEBUG SaveCharacter: StoredArmor = '" @ %storedArmor @ "'");
	//echo("DEBUG SaveCharacter: StoredAccessories = '" @ %storedAccessories @ "'");
	//echo("DEBUG SaveCharacter: StoredOther = '" @ %storedOther @ "'");
	//echo("DEBUG SaveCharacter: Processed " @ %processedCount @ " items from BeltStorage='" @ %beltStorage @ "'");
	//echo("DEBUG SaveCharacter: StoredArmor = '" @ %storedArmor @ "'");
	//echo("DEBUG SaveCharacter: StoredAccessories = '" @ %storedAccessories @ "'");
	//echo("DEBUG SaveCharacter: StoredOther = '" @ %storedOther @ "'");
	//echo("DEBUG SaveCharacter: StoredKeyItems = '" @ %storedKey @ "'");
	
	// Always save these variables, even if empty (use "0" for empty to match original inventory system)
	// Use the local variables we just set, not fetchData (which may return "0" for empty)
	%storedQuestSave = %storedQuest;
	%storedKeySave = %storedKey;
	%storedConsumablesSave = %storedConsumables;
	%storedArmorSave = %storedArmor;
	%storedAccessoriesSave = %storedAccessories;
	%storedOtherSave = %storedOther;
	
	// Normalize empty strings to "0" to match original inventory system behavior (fields 11-14 use "0" for empty)
	if(%storedQuestSave == "" || %storedQuestSave == " " || %storedQuestSave == "0")
		%storedQuestSave = "0";
	if(%storedKeySave == "" || %storedKeySave == " " || %storedKeySave == "0")
		%storedKeySave = "0";
	if(%storedConsumablesSave == "" || %storedConsumablesSave == " " || %storedConsumablesSave == "0")
		%storedConsumablesSave = "0";
	if(%storedArmorSave == "" || %storedArmorSave == " " || %storedArmorSave == "0")
		%storedArmorSave = "0";
	if(%storedAccessoriesSave == "" || %storedAccessoriesSave == " " || %storedAccessoriesSave == "0")
		%storedAccessoriesSave = "0";
	if(%storedOtherSave == "" || %storedOtherSave == " " || %storedOtherSave == "0")
		%storedOtherSave = "0";
	
	//echo("DEBUG SaveCharacter: Saving to fields 38-39-42-43-45-46 (StoredQuestItems/StoredKeyItems/StoredConsumables/StoredArmor/StoredAccessories/StoredOther)...");
	$funk::var["[\"" @ %name @ "\", 0, 38]"] = %storedQuestSave;
	//echo("DEBUG SaveCharacter: Field 38 (StoredQuestItems) = '" @ %storedQuestSave @ "'");
	$funk::var["[\"" @ %name @ "\", 0, 39]"] = %storedKeySave;
	//echo("DEBUG SaveCharacter: Field 39 (StoredKeyItems) = '" @ %storedKeySave @ "'");
	$funk::var["[\"" @ %name @ "\", 0, 42]"] = %storedConsumablesSave;
	//echo("DEBUG SaveCharacter: Field 42 (StoredConsumables) = '" @ %storedConsumablesSave @ "'");
	$funk::var["[\"" @ %name @ "\", 0, 43]"] = %storedArmorSave;
	//echo("DEBUG SaveCharacter: Field 43 (StoredArmor) = '" @ %storedArmorSave @ "'");
	$funk::var["[\"" @ %name @ "\", 0, 45]"] = %storedAccessoriesSave;
	//echo("DEBUG SaveCharacter: Field 45 (StoredAccessories) = '" @ %storedAccessoriesSave @ "'");
	$funk::var["[\"" @ %name @ "\", 0, 46]"] = %storedOtherSave;
	//echo("DEBUG SaveCharacter: Field 46 (StoredOther) = '" @ %storedOtherSave @ "'");
	$funk::var["[\"" @ %name @ "\", 0, 44]"] = fetchData(%clientId, "Stance");

	//echo("DEBUG SaveCharacter: Saving skill variables...");
	//skill variables
	%cnt = 0;
	for(%i = 1; %i <= GetNumSkills(); %i++)
	{
		$funk::var["[\"" @ %name @ "\", 4, " @ %cnt++ @ "]"] = $PlayerSkill[%clientId, %i];
		$funk::var["[\"" @ %name @ "\", 4, " @ %cnt++ @ "]"] = $SkillCounter[%clientId, %i];
	}
	//echo("DEBUG SaveCharacter: Saved " @ GetNumSkills() @ " skills");

	//IP dump, for server admin look-up purposes
	$funk::var["[\"" @ %name @ "\", 0, 666]"] = Client::getTransportAddress(%clientId);

	%ii = 0;

	//determine which weapons player has

	%player = Client::getOwnedObject(%clientId);
	if(!IsDead(%clientId) && %player != -1)
	{
		%s = "";
		%max = getNumItems();
		for(%i = 0; %i < %max; %i++)
		{
			%checkItem = getItemData(%i);
			// CRITICAL: Never save flags to character data - flags are mission objectives, not player inventory
			// If a player disconnects/crashes while carrying a flag, Flag::clientDropped should handle dropping it
			// But we must prevent flags from being saved to avoid issues on reload
			if(%checkItem == "Flag" || %checkItem == Flag)
				continue;
			
			%itemcount = Player::getItemCount(%clientId, %checkItem);
			if(%itemcount > $maxItem)
				%itemcount = $maxItem;
			if(%itemcount > 0)
				%s = %s @ %checkItem @ " " @ %itemcount @ " ";
		}
		$funk::var["[\"" @ %name @ "\", 0, 15]"] = %s;
	}
	else
		$funk::var["[\"" @ %name @ "\", 0, 15]"] = fetchData(%clientId, "spawnStuff");

	%cnt = 0;
	%list = GetBotIdList();
	for(%i = 0; GetWord(%list, %i) != -1; %i++)
	{
		%id = GetWord(%list, %i);
		%aiName = fetchData(%id, "BotInfoAiName");

		if($QuestCounter[%name, %aiName] != "")
		{
			%cnt++;
			$funk::var["[\"" @ %name @ "\", 2, " @ %cnt @ "]"] = %aiName;
			$funk::var["[\"" @ %name @ "\", 3, " @ %cnt @ "]"] = $QuestCounter[%name, %aiName];
		}
	}

	//bonus state variables
	for(%i = 1; %i <= $maxBonusStates; %i++)
	{
		$funk::var["[\"" @ %name @ "\", 5, " @ %i @ "]"] = $BonusState[%clientId, %i];
		$funk::var["[\"" @ %name @ "\", 6, " @ %i @ "]"] = $BonusStateCnt[%clientId, %i];
	}
	

	File::delete("temp\\" @ %name @ ".cs");

	export("funk::var[\"" @ %name @ "\",*", "temp\\" @ %name @ ".cs", false);
	ClearFunkVar(%name);
	echo("Save for " @ %name @ " (" @ %clientId @ ") complete.");

	return True;
}

function SaveAllCharacters()
{
	dbecho($dbechoMode, "SaveAllCharacters()");
	
	%list = GetPlayerIdList();
	%count = 0;
	%delay = 0;
	
	for(%i = 0; GetWord(%list, %i) != -1; %i++)
	{
		%id = GetWord(%list, %i);
		// Save character with a small delay to stagger saves and reduce server load
		schedule("SaveCharacter(" @ %id @ ");", %delay, %id);
		%delay += 0.1;
		%count++;
	}
	
	if(%count > 0)
		echo("Saving all " @ %count @ " players...");
	else
		echo("No players to save.");
}

function LoadCharacter(%clientId)
{
	dbecho($dbechoMode2, "LoadCharacter(" @ %clientId @ ")");

	ClearVariables(%clientId);

	%name = Client::getName(%clientId);
	%filename = %name @ ".cs";

	$ConsoleWorld::DefaultSearchPath = $ConsoleWorld::DefaultSearchPath;	//thanks Presto

	if(isFile("temp\\" @ %filename))
	{
		//load character
		echo("Loading character " @ %name @ " (" @ %clientId @ ")...");

		for(%retry = 0; %retry < 5; %retry++)		//This might not be necessary, but it's to ensure that the
		{								//exec doesn't get flakey when there's lag.
			exec(%filename);
			if($funk::var[%name, 0, 1] != "")
				break;
		}
		storeData(%clientId, "RACE", $funk::var[%name, 0, 1]);
		storeData(%clientId, "EXP", $funk::var[%name, 0, 2]);
		storeData(%clientId, "campPos", $funk::var[%name, 0, 3]);
		storeData(%clientId, "COINS", $funk::var[%name, 0, 4]);
		storeData(%clientId, "isMimic", $funk::var[%name, 0, 5]);
		storeData(%clientId, "BANK", $funk::var[%name, 0, 6]);
		storeData(%clientId, "tmpname", $funk::var[%name, 0, 7]);
		storeData(%clientId, "grouplist", $funk::var[%name, 0, 8]);
		storeData(%clientId, "defaultTalk", $funk::var[%name, 0, 9]);
		storeData(%clientId, "password", $funk::var[%name, 0, 10]);
		storeData(%clientId, "bounty", $funk::var[%name, 0, 11]);
		storeData(%clientId, "inArena", $funk::var[%name, 0, 12]);
		storeData(%clientId, "PlayerInfo", $funk::var[%name, 0, 13]);
		storeData(%clientId, "deathmsg", $funk::var[%name, 0, 14]);
		// CRITICAL: Filter out flags from spawnStuff - flags are mission objectives, not player inventory
		// This prevents old saves that might have flags from loading them
		%spawnStuffRaw = $funk::var[%name, 0, 15];
		%spawnStuffCleaned = "";
		if(%spawnStuffRaw != "" && %spawnStuffRaw != "0")
		{
			for(%i = 0; GetWord(%spawnStuffRaw, %i) != -1; %i += 2)
			{
				%item = GetWord(%spawnStuffRaw, %i);
				%count = GetWord(%spawnStuffRaw, %i + 1);
				// Skip flags - they should never be in player inventory
				if(%item == "Flag" || %item == Flag)
					continue;
				// Add non-flag items to cleaned list
				if(%spawnStuffCleaned != "")
					%spawnStuffCleaned = %spawnStuffCleaned @ " " @ %item @ " " @ %count;
				else
					%spawnStuffCleaned = %item @ " " @ %count;
			}
		}
		storeData(%clientId, "spawnStuff", %spawnStuffCleaned);
		// CRITICAL: Clean BankStorage on load - remove leading "0" items and invalid entries
		// BankStorage format should be "item count item count..." but old saves may have leading "0"
		%bankStorageRaw = $funk::var[%name, 0, 16];
		%bankStorageCleaned = "";
		if(%bankStorageRaw != "" && %bankStorageRaw != "0")
		{
			// Check if it starts with "0 " - if so, skip the first two words (item "0" and its count)
			%firstWord = GetWord(%bankStorageRaw, 0);
			%startIndex = 0;
			if(%firstWord == "0")
			{
				// Skip the leading "0" and its count (next word)
				%startIndex = 2;
				echo("DEBUG LoadCharacter: BankStorage starts with '0', skipping first 2 words");
			}
			
			// Parse and clean the rest of BankStorage
			for(%i = %startIndex; GetWord(%bankStorageRaw, %i) != -1; %i += 2)
			{
				%item = GetWord(%bankStorageRaw, %i);
				%count = GetWord(%bankStorageRaw, %i + 1);
				// Skip invalid entries (item is "0" or empty, count is invalid)
				if(%item == "" || %item == -1 || %item == "0" || %count == "" || %count == -1 || %count == "0")
					continue;
				// Convert count to numeric to validate
				%countNum = %count * 1;
				if(%countNum <= 0)
					continue;
				// Add valid entries to cleaned list
				if(%bankStorageCleaned != "")
					%bankStorageCleaned = %bankStorageCleaned @ " " @ %item @ " " @ %count;
				else
					%bankStorageCleaned = %item @ " " @ %count;
			}
		}
		storeData(%clientId, "BankStorage", %bankStorageCleaned);
		// Validate campRot - handle missing values and clean "-0" values
		%campRot = $funk::var[%name, 0, 17];
		if(%campRot == "" || %campRot == -1)
		{
			%campRot = "";
			echo("DEBUG: campRot was missing/empty, defaulting to empty string");
		}
		else
		{
			// Clean up "-0" values in rotation (replace "-0" with "0")
			// Rotation format is "x y z" (3 space-separated numbers)
			%cleanedRot = "";
			for(%i = 0; (%word = GetWord(%campRot, %i)) != -1; %i++)
			{
				// Convert "-0" to "0", and validate numeric value
				if(%word == "-0" || %word == "0")
					%word = "0";
				else
				{
					// Convert to numeric to handle any negative values properly
					%wordNum = %word * 1;
					%word = %wordNum;
				}
				
				if(%cleanedRot != "")
					%cleanedRot = %cleanedRot @ " " @ %word;
				else
					%cleanedRot = %word;
			}
			if(%cleanedRot != %campRot)
				echo("DEBUG: campRot cleaned from '" @ %campRot @ "' to '" @ %cleanedRot @ "'");
			%campRot = %cleanedRot;
		}
		storeData(%clientId, "campRot", %campRot);
		echo("DEBUG: campRot FINAL = '" @ %campRot @ "'");
		
		echo("DEBUG: Loading tmphp/tmpmana (fields 18-19)...");
		// Normalize tmphp and tmpmana - convert "-0", "0", or negative values to empty string
		%tmphp = $funk::var[%name, 0, 18];
		echo("DEBUG: tmphp RAW = '" @ %tmphp @ "'");
		if(%tmphp == "" || %tmphp == " " || %tmphp == "0" || %tmphp == "-0" || (%tmphp * 1) <= 0)
		{
			echo("DEBUG: tmphp was invalid (empty/0/-0/negative), normalizing to empty string");
			%tmphp = "";
		}
		storeData(%clientId, "tmphp", %tmphp);
		echo("DEBUG: tmphp FINAL = '" @ %tmphp @ "'");
		
		%tmpmana = $funk::var[%name, 0, 19];
		echo("DEBUG: tmpmana RAW = '" @ %tmpmana @ "'");
		if(%tmpmana == "" || %tmpmana == " " || %tmpmana == "0" || %tmpmana == "-0" || (%tmpmana * 1) <= 0)
		{
			echo("DEBUG: tmpmana was invalid (empty/0/-0/negative), normalizing to empty string");
			%tmpmana = "";
		}
		storeData(%clientId, "tmpmana", %tmpmana);
		echo("DEBUG: tmpmana FINAL = '" @ %tmpmana @ "'");
		echo("DEBUG: Loading character stats and properties...");
		storeData(%clientId, "LCKconsequence", $funk::var[%name, 0, 20]);
		echo("DEBUG: LCKconsequence = '" @ $funk::var[%name, 0, 20] @ "'");
		storeData(%clientId, "RemortStep", $funk::var[%name, 0, 21]);
		echo("DEBUG: RemortStep = '" @ $funk::var[%name, 0, 21] @ "'");
		storeData(%clientId, "LCK", $funk::var[%name, 0, 22]);
		echo("DEBUG: LCK = '" @ $funk::var[%name, 0, 22] @ "'");
		storeData(%clientId, "tmpLastSaveVer", $funk::var[%name, 0, 23]);
		echo("DEBUG: tmpLastSaveVer = '" @ $funk::var[%name, 0, 23] @ "'");
		storeData(%clientId, "GROUP", $funk::var[%name, 0, 26]);
		echo("DEBUG: GROUP = '" @ $funk::var[%name, 0, 26] @ "'");
		storeData(%clientId, "CLASS", $funk::var[%name, 0, 27]);
		echo("DEBUG: CLASS = '" @ $funk::var[%name, 0, 27] @ "'");
		storeData(%clientId, "SPcredits", $funk::var[%name, 0, 28]);
		echo("DEBUG: SPcredits = '" @ $funk::var[%name, 0, 28] @ "'");
		//$funk::var[%name, 0, 29]);
		
		echo("DEBUG: Loading MyHouse (field 30)...");
		// Validate MyHouse number before array access - prevent crash if field 30 doesn't exist
		%houseNum = $funk::var[%name, 0, 30];
		echo("DEBUG: MyHouse RAW (field 30) = '" @ %houseNum @ "'");
		// If houseNum is empty, -1, 0, or "0", treat as no house (empty string)
		// Houses start at index 1, so 0 is not a valid house number
		if(%houseNum == "" || %houseNum == -1 || %houseNum == 0 || %houseNum == "0")
		{
			echo("DEBUG: MyHouse field was missing/empty/0, setting to empty string (no house)");
			%houseName = "";
		}
		else
		{
			%houseName = $HouseName[%houseNum];
			// Validate that houseName exists and is not empty
			if(%houseName == "" || %houseName == -1)
			{
				echo("DEBUG: MyHouse number " @ %houseNum @ " is invalid, setting to empty string (no house)");
				%houseName = "";
			}
		}
		// CRITICAL: Always check for "House0", "0", or "house0" before storing
		// This prevents any case where "House0" might have been saved as a string
		if(%houseName == "House0" || %houseName == "0" || %houseName == "house0")
		{
			echo("DEBUG: LoadCharacter - Detected invalid house name '" @ %houseName @ "' before storing, clearing");
			%houseName = "";
		}
		storeData(%clientId, "MyHouse", %houseName);
		echo("DEBUG: MyHouse FINAL = '" @ %houseName @ "' (from houseNum " @ %houseNum @ ")");
		
		// CRITICAL: Double-check after storing - if somehow "House0" got through, clear it
		// This handles edge cases where the house might be set elsewhere
		%loadedHouse = fetchData(%clientId, "MyHouse");
		if(%loadedHouse == "House0" || %loadedHouse == "0" || %loadedHouse == "house0")
		{
			echo("DEBUG: LoadCharacter - Player " @ %name @ " had invalid house '" @ %loadedHouse @ "' after load, clearing house assignment");
			storeData(%clientId, "MyHouse", "");
			// Boot them from the invalid house (this will also reset rank points and unequip items)
			BootFromCurrentHouse(%clientId);
		}
		
		storeData(%clientId, "RankPoints", $funk::var[%name, 0, 31]);
		echo("DEBUG: RankPoints = '" @ $funk::var[%name, 0, 31] @ "'");
		storeData(%clientId, "TournyRank", $funk::var[%name, 0, 32]);
		echo("DEBUG: TournyRank = '" @ $funk::var[%name, 0, 32] @ "'");
		
		echo("DEBUG: Loading belt items (QuestItems/KeyItems)...");
		// Normalize QuestItems and KeyItems - convert "0" to empty string
		%questItems = $funk::var[%name, 0, 35];
		echo("DEBUG: QuestItems RAW = '" @ %questItems @ "'");
		if(%questItems == "" || %questItems == " " || %questItems == "0")
		{
			echo("DEBUG: QuestItems was empty/'0', normalizing to empty string");
			%questItems = "";
		}
		storeData(%clientId, "QuestItems", %questItems);
		echo("DEBUG: QuestItems FINAL = '" @ %questItems @ "'");
		
		%keyItems = $funk::var[%name, 0, 36];
		echo("DEBUG: KeyItems RAW = '" @ %keyItems @ "'");
		if(%keyItems == "" || %keyItems == " " || %keyItems == "0")
		{
			echo("DEBUG: KeyItems was empty/'0', normalizing to empty string");
			%keyItems = "";
		}
		storeData(%clientId, "KeyItems", %keyItems);
		echo("DEBUG: KeyItems FINAL = '" @ %keyItems @ "'");
		
		// Load Consumables from field 37 (new field for potions)
		%consumables = $funk::var[%name, 0, 37];
		echo("DEBUG: Consumables RAW (field 37) = '" @ %consumables @ "'");
		if(%consumables == "" || %consumables == " " || %consumables == "0" || %consumables == -1)
		{
			echo("DEBUG: Consumables was empty/'0', normalizing to empty string");
			%consumables = "";
		}
		storeData(%clientId, "Consumables", %consumables);
		echo("DEBUG: Consumables FINAL = '" @ %consumables @ "'");
		
		echo("DEBUG: Loading stored belt items (StoredQuestItems/StoredKeyItems)...");
		// Handle StoredQuestItems and StoredKeyItems - convert space or "0" to empty string if needed
		// Also handle case where variable doesn't exist in old save files (defaults to empty)
		// Validate and clean corrupted data like "0 -1" before storing
		%storedQuest = $funk::var[%name, 0, 38];
		echo("DEBUG: StoredQuestItems RAW (field 38) = '" @ %storedQuest @ "'");
		if(%storedQuest == "" || %storedQuest == " " || %storedQuest == "0")
		{
			echo("DEBUG: StoredQuestItems was empty/'0', normalizing to empty string");
			%storedQuest = "";
		}
		else
		{
			// Clean up corrupted entries (item "0", count <= 0, negative values, etc.)
			%cleanedQuest = "";
			%removedCount = 0;
			for(%i = 0; GetWord(%storedQuest, %i) != -1; %i += 2)
			{
				%item = GetWord(%storedQuest, %i);
				%count = GetWord(%storedQuest, %i + 1);
				// Convert count to numeric to properly handle negative values like "-1" or "-0"
				%countNum = %count * 1;
				echo("DEBUG:   Checking entry: item='" @ %item @ "', count='" @ %count @ "', countNum=" @ %countNum);
				// Only keep valid entries (item is not empty/"0" and count is a positive number)
				if(%item != "" && %item != -1 && %item != "0" && %count != "" && %count != -1 && %countNum > 0)
				{
					if(%cleanedQuest != "")
						%cleanedQuest = %cleanedQuest @ " ";
					%cleanedQuest = %cleanedQuest @ %item @ " " @ %count;
				}
				else
				{
					echo("DEBUG:   REMOVED invalid entry: item='" @ %item @ "', count='" @ %count @ "'");
					%removedCount++;
				}
			}
			if(%removedCount > 0)
				echo("DEBUG: StoredQuestItems cleaned - removed " @ %removedCount @ " invalid entries");
			if(%cleanedQuest != %storedQuest)
				echo("DEBUG: StoredQuestItems changed from '" @ %storedQuest @ "' to '" @ %cleanedQuest @ "'");
			%storedQuest = %cleanedQuest;
		}
		storeData(%clientId, "StoredQuestItems", %storedQuest);
		echo("DEBUG: StoredQuestItems FINAL = '" @ %storedQuest @ "'");
		
		// Load StoredKeyItems from field 39
		%storedKey = $funk::var[%name, 0, 39];
		echo("DEBUG: StoredKeyItems RAW (field 39) = '" @ %storedKey @ "'");
		if(%storedKey == "" || %storedKey == " " || %storedKey == "0")
		{
			echo("DEBUG: StoredKeyItems was empty/'0', normalizing to empty string");
			%storedKey = "";
		}
		else
		{
			// Clean up corrupted entries (item "0", count <= 0, negative values, etc.)
			%cleanedKey = "";
			%removedCount = 0;
			for(%i = 0; GetWord(%storedKey, %i) != -1; %i += 2)
			{
				%item = GetWord(%storedKey, %i);
				%count = GetWord(%storedKey, %i + 1);
				// Convert count to numeric to properly handle negative values like "-1" or "-0"
				%countNum = %count * 1;
				echo("DEBUG:   Checking entry: item='" @ %item @ "', count='" @ %count @ "', countNum=" @ %countNum);
				// Only keep valid entries (item is not empty/"0" and count is a positive number)
				if(%item != "" && %item != -1 && %item != "0" && %count != "" && %count != -1 && %countNum > 0)
				{
					if(%cleanedKey != "")
						%cleanedKey = %cleanedKey @ " ";
					%cleanedKey = %cleanedKey @ %item @ " " @ %count;
				}
				else
				{
					echo("DEBUG:   REMOVED invalid entry: item='" @ %item @ "', count='" @ %count @ "'");
					%removedCount++;
				}
			}
			if(%removedCount > 0)
				echo("DEBUG: StoredKeyItems cleaned - removed " @ %removedCount @ " invalid entries");
			if(%cleanedKey != %storedKey)
				echo("DEBUG: StoredKeyItems changed from '" @ %storedKey @ "' to '" @ %cleanedKey @ "'");
			%storedKey = %cleanedKey;
		}
		storeData(%clientId, "StoredKeyItems", %storedKey);
		echo("DEBUG: StoredKeyItems FINAL = '" @ %storedKey @ "'");
		
		echo("DEBUG: Loading bank items and inventory...");
		// NOTE: BankGemItems, BankRareItems, BankKeysItems, and BankScrollsItems are no longer used
		// Fields 33-34 are unused legacy bank fields
		// Fields 35-36 are now used for QuestItems and KeyItems (equipped belt items)
		// These old bank variables are not loaded to avoid field conflicts
		storeData(%clientId, "BankGemItems", "");
		storeData(%clientId, "BankRareItems", "");
		storeData(%clientId, "BankKeysItems", "");
		storeData(%clientId, "BankScrollsItems", "");
		// Field 37 is now used for Consumables (belt items like potions)
		%consumables = $funk::var[%name, 0, 37];
		echo("DEBUG: Consumables RAW (field 37) = '" @ %consumables @ "'");
		if(%consumables == "" || %consumables == " " || %consumables == "0")
		{
			echo("DEBUG: Consumables was empty/'0', normalizing to empty string");
			%consumables = "";
		}
		storeData(%clientId, "Consumables", %consumables);
		echo("DEBUG: Consumables FINAL = '" @ %consumables @ "'");
		// BankUniqueItems is no longer used - keep empty for backward compatibility
		storeData(%clientId, "BankUniqueItems", "");
		// CRITICAL FIX: Position 38 is now used for StoredQuestItems (loaded above)
		// GemItems is unused and has been removed - do not load from position 38
		// Position 39 is now used for StoredKeyItems (loaded above)
		// Position 42 is now used for StoredConsumables (bank storage for consumables)
		%storedConsumables = $funk::var[%name, 0, 42];
		echo("DEBUG: StoredConsumables RAW (field 42) = '" @ %storedConsumables @ "'");
		if(%storedConsumables == "" || %storedConsumables == " " || %storedConsumables == "0")
		{
			echo("DEBUG: StoredConsumables was empty/'0', normalizing to empty string");
			%storedConsumables = "";
		}
		storeData(%clientId, "StoredConsumables", %storedConsumables);
		echo("DEBUG: StoredConsumables FINAL = '" @ %storedConsumables @ "'");
		// Position 43 is now used for StoredArmor (bank storage for armor)
		%storedArmor = $funk::var[%name, 0, 43];
		echo("DEBUG: StoredArmor RAW (field 43) = '" @ %storedArmor @ "'");
		if(%storedArmor == "" || %storedArmor == " " || %storedArmor == "0")
		{
			echo("DEBUG: StoredArmor was empty/'0', normalizing to empty string");
			%storedArmor = "";
		}
		storeData(%clientId, "StoredArmor", %storedArmor);
		echo("DEBUG: StoredArmor FINAL = '" @ %storedArmor @ "'");
		// Position 45 is now used for StoredAccessories (bank storage for accessories)
		%storedAccessories = $funk::var[%name, 0, 45];
		echo("DEBUG: StoredAccessories RAW (field 45) = '" @ %storedAccessories @ "'");
		if(%storedAccessories == "" || %storedAccessories == " " || %storedAccessories == "0")
		{
			echo("DEBUG: StoredAccessories was empty/'0', normalizing to empty string");
			%storedAccessories = "";
		}
		storeData(%clientId, "StoredAccessories", %storedAccessories);
		echo("DEBUG: StoredAccessories FINAL = '" @ %storedAccessories @ "'");
		// Position 46 is now used for StoredOther (bank storage for other items)
		%storedOther = $funk::var[%name, 0, 46];
		echo("DEBUG: StoredOther RAW (field 46) = '" @ %storedOther @ "'");
		if(%storedOther == "" || %storedOther == " " || %storedOther == "0")
		{
			echo("DEBUG: StoredOther was empty/'0', normalizing to empty string");
			%storedOther = "";
		}
		storeData(%clientId, "StoredOther", %storedOther);
		echo("DEBUG: StoredOther FINAL = '" @ %storedOther @ "'");
		// RareItems is unused - do not load from position 39
		storeData(%clientId, "RareItems", "");
		echo("DEBUG: RareItems = '' (unused)");
		// NOTE: KeysItems, ScrollsItems, and UniqueItems are no longer used
		// Set them to empty strings to prevent conflicts with belt storage fields
		// Field 40 was used for KeysItems (now unused)
		// Field 41 was used for ScrollsItems (now unused)
		// Field 42 is now used for StoredConsumables (belt storage), not UniqueItems
		storeData(%clientId, "KeysItems", "");
		storeData(%clientId, "ScrollsItems", "");
		storeData(%clientId, "UniqueItems", "");
		//echo("DEBUG: KeysItems = '' (unused)");
		//echo("DEBUG: ScrollsItems = '' (unused)");
		//echo("DEBUG: UniqueItems = '' (unused)");
		storeData(%clientId, "Stance", $funk::var[%name, 0, 44]);
		echo("DEBUG: Stance = '" @ $funk::var[%name, 0, 44] @ "'");

		echo("DEBUG: Calling Belt::BankStorageConversion...");
		Belt::BankStorageConversion(%clientid);
		echo("DEBUG: Belt::BankStorageConversion complete");

		echo("DEBUG: Loading skill variables...");
		//skill variables
		%cnt = 0;
		for(%i = 1; %i <= GetNumSkills(); %i++)
		{
			$PlayerSkill[%clientId, %i] = $funk::var[%name, 4, %cnt++];
			$SkillCounter[%clientId, %i] = $funk::var[%name, 4, %cnt++];
		}
		echo("DEBUG: Loaded " @ GetNumSkills() @ " skills");

		echo("DEBUG: Loading quest counters...");
		%questCounterCount = 0;
		for(%i = 1; $funk::var[%name, 3, %i] != ""; %i++)
		{
			$QuestCounter[%name, $funk::var[%name, 2, %i]] = $funk::var[%name, 3, %i];
			%questCounterCount++;
		}
		echo("DEBUG: Loaded " @ %questCounterCount @ " quest counters");

		echo("DEBUG: Loading bonus state variables...");
		//bonus state variables
		for(%i = 1; %i <= $maxBonusStates; %i++)
		{
			$BonusState[%clientId, %i] = $funk::var[%name, 5, %i];
			$BonusStateCnt[%clientId, %i] = $funk::var[%name, 6, %i];
		}
		echo("DEBUG: Loaded bonus states (max=" @ $maxBonusStates @ ")");

		//== VERSION CONVERSION ROUTINES ============================

		echo("DEBUG: Running version conversion/default checks...");
		//temp--------
		if(fetchData(%clientId, "RemortStep") == "")
		{
			echo("DEBUG: RemortStep was empty, defaulting to 0");
			storeData(%clientId, "RemortStep", 0);
		}
		if(fetchData(%clientId, "LCKconsequence") == "")
		{
			echo("DEBUG: LCKconsequence was empty, defaulting to 'death'");
			storeData(%clientId, "LCKconsequence", "death");
		}
		if(fetchData(%clientId, "tmphp") == "")
		{
			echo("DEBUG: tmphp was empty after load, defaulting to 1");
			storeData(%clientId, "tmphp", 1);
		}
		if(fetchData(%clientId, "tmpmana") == "")
		{
			echo("DEBUG: tmpmana was empty after load, defaulting to 1");
			storeData(%clientId, "tmpmana", 1);
		}
		if(fetchData(%clientId, "tmpname") == "")
		{
			echo("DEBUG: tmpname was empty, defaulting to player name");
			storeData(%clientId, "tmpname", %name);
		}
		if(fetchData(%clientId, "TournyRank") == "")
		{
			echo("DEBUG: TournyRank was empty, defaulting to 0");
			storeData(%clientId, "TournyRank", 0);
		}
		if(fetchData(%clientId, "Stance") == "")
		{
			echo("DEBUG: Stance was empty, defaulting to 'Normal'");
			storeData(%clientId, "Stance", "Normal");
		}
		//------------

		//===========================================================
		
		echo("===== DEBUG LoadCharacter: COMPLETE =====");
		echo("Load complete.");
	}
	else
	{
		//give defaults
		echo("===== DEBUG LoadCharacter: NEW CHARACTER CREATION =====");
		echo("Giving defaults to new player " @ %clientId @ " (" @ %name @ ")");
		echo("DEBUG: Save file not found, initializing new character with defaults");
		
		echo("DEBUG: Setting basic character data...");
		storeData(%clientId, "RACE", Client::getGender(%clientId) @ "Human");
		echo("DEBUG: RACE = '" @ Client::getGender(%clientId) @ "Human'");
		storeData(%clientId, "EXP", 0);
		echo("DEBUG: EXP = 0");
		storeData(%clientId, "campPos", "");
		echo("DEBUG: campPos = ''");
		storeData(%clientId, "BANK", $initbankcoins);
		echo("DEBUG: BANK = " @ $initbankcoins);
		storeData(%clientId, "grouplist", "");
		echo("DEBUG: grouplist = ''");
		storeData(%clientId, "defaultTalk", "#say");
		echo("DEBUG: defaultTalk = '#say'");
		storeData(%clientId, "password", $Client::info[%clientId, 5]);
		echo("DEBUG: password = '" @ $Client::info[%clientId, 5] @ "'");
		storeData(%clientId, "LCK", $initLCK);
		echo("DEBUG: LCK = " @ $initLCK);
		storeData(%clientId, "PlayerInfo", "");
		echo("DEBUG: PlayerInfo = ''");
		storeData(%clientId, "ignoreGlobal", "");
		echo("DEBUG: ignoreGlobal = ''");
		storeData(%clientId, "LCKconsequence", "death");
		echo("DEBUG: LCKconsequence = 'death'");
		storeData(%clientId, "tmphp", "");
		echo("DEBUG: tmphp = '' (new character)");
		storeData(%clientId, "tmpmana", "");
		echo("DEBUG: tmpmana = '' (new character)");
		storeData(%clientId, "RemortStep", 0);
		echo("DEBUG: RemortStep = 0");
		storeData(%clientId, "tmpname", %name);
		echo("DEBUG: tmpname = '" @ %name @ "'");
		storeData(%clientId, "tmpLastSaveVer", $rpgver);
		echo("DEBUG: tmpLastSaveVer = '" @ $rpgver @ "'");
		storeData(%clientId, "bounty", 0);
		echo("DEBUG: bounty = 0");
		storeData(%clientId, "isMimic", "");
		echo("DEBUG: isMimic = ''");
		storeData(%clientId, "MyHouse", "");
		echo("DEBUG: MyHouse = ''");
		storeData(%clientId, "RankPoints", 0);
		echo("DEBUG: RankPoints = 0");
		storeData(%clientId, "TournyRank", 0);
		echo("DEBUG: TournyRank = 0");
		storeData(%clientId, "Stance", "Normal");
		echo("DEBUG: Stance = 'Normal'");
		
		echo("DEBUG: Initializing belt storage fields for new character...");
		// Initialize belt storage fields for new characters
		storeData(%clientId, "QuestItems", "");
		echo("DEBUG: QuestItems = ''");
		storeData(%clientId, "KeyItems", "");
		echo("DEBUG: KeyItems = ''");
		storeData(%clientId, "Consumables", "");
		echo("DEBUG: Consumables = ''");
		storeData(%clientId, "StoredQuestItems", "");
		echo("DEBUG: StoredQuestItems = ''");
		storeData(%clientId, "StoredKeyItems", "");
		echo("DEBUG: StoredKeyItems = ''");
		storeData(%clientId, "StoredConsumables", "");
		echo("DEBUG: StoredConsumables = ''");
		storeData(%clientId, "StoredArmor", "");
		echo("DEBUG: StoredArmor = ''");
		storeData(%clientId, "StoredAccessories", "");
		echo("DEBUG: StoredAccessories = ''");
		storeData(%clientId, "StoredOther", "");
		echo("DEBUG: StoredOther = ''");
		storeData(%clientId, "BeltStorage", "");
		echo("DEBUG: BeltStorage = ''");
		storeData(%clientId, "Consumables", "");
		echo("DEBUG: Consumables = ''");
		storeData(%clientId, "Armor", "");
		echo("DEBUG: Armor = ''");
		storeData(%clientId, "Accessories", "");
		echo("DEBUG: Accessories = ''");
		storeData(%clientId, "Other", "");
		echo("DEBUG: Other = ''");

		%clientId.choosingGroup = True;
		echo("DEBUG: Set choosingGroup = True");

		echo("DEBUG: Initializing all skills to 0...");
		SetAllSkills(%clientId, 0);
		echo("DEBUG: Skills initialized");

		storeData(%clientId, "spawnStuff", "PickAxe 1 BluePotion 1 CrystalBluePotion 3");
		echo("DEBUG: spawnStuff = 'PickAxe 1 BluePotion 1 CrystalBluePotion 3'");
		echo("===== DEBUG LoadCharacter: NEW CHARACTER CREATION COMPLETE =====");
	}

	ClearFunkVar(%name);
}

function OnOrOfflineGive(%name, %award)
{
	dbecho($dbechoMode, "OnOrOfflineGive(" @ %name @ ", " @ %award @ ")");

	%clientId = NEWgetClientByName(%name);
	//messageAll($MsgRed, "DEBUG: %name: " @ %name);
	//messageAll($MsgRed, "DEBUG: %clientId: " @ %clientId);
	//messageAll($MsgRed, "DEBUG: %award: " @ %award);
	if(%clientId != -1)
	{
		//player is in-game, simply store the item in storage
		Client::sendMessage(%clientId, $MsgBeige, "You have received a prize for downloading Theory Of Trance music, check your storage!");
		for(%i = 0; GetWord(%award, %i) != -1; %i+=2)
			storeData(%clientId, "BankStorage", SetStuffString(fetchData(%clientId, "BankStorage"), GetWord(%award, %i), GetWord(%award, %i+1)));
	}
	else
	{
		//player is not in-game. load character file, make changes, then save
		%filename = %name @ ".cs";

		$ConsoleWorld::DefaultSearchPath = $ConsoleWorld::DefaultSearchPath;	//thanks Presto

		if(isFile("temp\\" @ %filename))
		{
			//load character
			ClearFunkVar(%name);
			exec(%filename);

			//pass variables thru, while adding the awarded item
			$funk::var["[\"" @ %name @ "\", 0, 1]"] = $funk::var[%name, 0, 1];
			$funk::var["[\"" @ %name @ "\", 0, 2]"] = $funk::var[%name, 0, 2];
			$funk::var["[\"" @ %name @ "\", 0, 3]"] = $funk::var[%name, 0, 3];
			$funk::var["[\"" @ %name @ "\", 0, 4]"] = $funk::var[%name, 0, 4];
			$funk::var["[\"" @ %name @ "\", 0, 5]"] = $funk::var[%name, 0, 5];
			$funk::var["[\"" @ %name @ "\", 0, 6]"] = $funk::var[%name, 0, 6];
			$funk::var["[\"" @ %name @ "\", 0, 7]"] = $funk::var[%name, 0, 7];
			$funk::var["[\"" @ %name @ "\", 0, 8]"] = $funk::var[%name, 0, 8];
			$funk::var["[\"" @ %name @ "\", 0, 9]"] = $funk::var[%name, 0, 9];
			$funk::var["[\"" @ %name @ "\", 0, 10]"] = $funk::var[%name, 0, 10];
			$funk::var["[\"" @ %name @ "\", 0, 11]"] = $funk::var[%name, 0, 11];
			$funk::var["[\"" @ %name @ "\", 0, 12]"] = $funk::var[%name, 0, 12];
			$funk::var["[\"" @ %name @ "\", 0, 13]"] = $funk::var[%name, 0, 13];
			$funk::var["[\"" @ %name @ "\", 0, 14]"] = $funk::var[%name, 0, 14];
			$funk::var["[\"" @ %name @ "\", 0, 15]"] = $funk::var[%name, 0, 15];
			for(%i = 0; GetWord(%award, %i) != -1; %i+=2)
				$funk::var["[\"" @ %name @ "\", 0, 16]"] = SetStuffString($funk::var[%name, 0, 16], GetWord(%award, %i), GetWord(%award, %i+1));
			$funk::var["[\"" @ %name @ "\", 0, 17]"] = $funk::var[%name, 0, 17];
			$funk::var["[\"" @ %name @ "\", 0, 18]"] = $funk::var[%name, 0, 18];
			$funk::var["[\"" @ %name @ "\", 0, 19]"] = $funk::var[%name, 0, 19];
			$funk::var["[\"" @ %name @ "\", 0, 20]"] = $funk::var[%name, 0, 20];
			$funk::var["[\"" @ %name @ "\", 0, 21]"] = $funk::var[%name, 0, 21];
			$funk::var["[\"" @ %name @ "\", 0, 22]"] = $funk::var[%name, 0, 22];
			$funk::var["[\"" @ %name @ "\", 0, 23]"] = $funk::var[%name, 0, 23];
			$funk::var["[\"" @ %name @ "\", 0, 26]"] = $funk::var[%name, 0, 26];
			$funk::var["[\"" @ %name @ "\", 0, 27]"] = $funk::var[%name, 0, 27];
			$funk::var["[\"" @ %name @ "\", 0, 28]"] = $funk::var[%name, 0, 28];
			//$funk::var["[\"" @ %name @ "\", 0, 29]"] = $funk::var[%name, 0, 29];
			$funk::var["[\"" @ %name @ "\", 0, 30]"] = $funk::var[%name, 0, 30];
			$funk::var["[\"" @ %name @ "\", 0, 31]"] = $funk::var[%name, 0, 31];
			$funk::var["[\"" @ %name @ "\", 0, 666]"] = $funk::var[%name, 0, 666];

			//skills
			%cnt = 0;
			for(%i = 1; %i <= GetNumSkills(); %i++)
			{
				%cnt++;
				$funk::var["[\"" @ %name @ "\", 4, " @ %cnt @ "]"] = $funk::var[%name, 4, %cnt];
				%cnt++;
				$funk::var["[\"" @ %name @ "\", 4, " @ %cnt @ "]"] = $funk::var[%name, 4, %cnt];
			}

			//quests
			for(%i = 1; $funk::var[%name, 2, %i] != ""; %i++)
				$funk::var["[\"" @ %name @ "\", 2, " @ %i @ "]"] = $funk::var[%name, 2, %i];
			for(%i = 1; $funk::var[%name, 3, %i] != ""; %i++)
				$funk::var["[\"" @ %name @ "\", 3, " @ %i @ "]"] = $funk::var[%name, 3, %i];

			//bonus state variables
			for(%i = 1; %i <= $maxBonusStates; %i++)
			{
				$funk::var["[\"" @ %name @ "\", 5, " @ %i @ "]"] = $funk::var[%name, 5, %i];
				$funk::var["[\"" @ %name @ "\", 6, " @ %i @ "]"] = $funk::var[%name, 6, %i];
			}

			//save character
			File::delete("temp\\" @ %name @ ".cs");
			export("funk::var[\"" @ %name @ "\",*", "temp\\" @ %name @ ".cs", false);

			ClearFunkVar(%name);
		}
	}
}

function ResetPlayer(%clientId)
{
	dbecho($dbechoMode2, "ResetPlayer(" @ %clientId @ ")");

	echo("===== DEBUG ResetPlayer: START =====");
	%name = Client::getName(%clientId);
	%filename = %name @ ".cs";
	echo("DEBUG ResetPlayer: Player = " @ %name @ " (" @ %clientId @ ")");
	echo("DEBUG ResetPlayer: Filename = " @ %filename);

	File::delete("temp\\" @ %filename);
	echo("DEBUG ResetPlayer: Deleted save file (if existed)");

	echo("DEBUG ResetPlayer: Calling LoadCharacter...");
	LoadCharacter(%clientId);
	echo("DEBUG ResetPlayer: LoadCharacter complete");

	echo("DEBUG ResetPlayer: Calling StartStatSelection...");
	StartStatSelection(%clientId);
	echo("===== DEBUG ResetPlayer: COMPLETE =====");
}


function GetPersistentTime() {
    // Returns persistent time that continues across server restarts
    // Uses accumulated elapsed time + current session time
    if($ServerTimeElapsed == "")
        $ServerTimeElapsed = 0;
    if($ServerTimeStart == "")
        $ServerTimeStart = getSimTime();
    
    return $ServerTimeElapsed + (getSimTime() - $ServerTimeStart);
}

function SaveServerTime() {
    // Save the accumulated server time so it persists across restarts
    if($ServerTimeElapsed == "")
        $ServerTimeElapsed = 0;
    if($ServerTimeStart == "")
        $ServerTimeStart = getSimTime();
    
    // Update accumulated time with current session
    $ServerTimeElapsed = $ServerTimeElapsed + (getSimTime() - $ServerTimeStart);
    $ServerTimeStart = getSimTime();
    
    // Save to file
    File::delete("temp\\ServerTime.cs");
    export("ServerTimeElapsed", "temp\\ServerTime.cs", false);
}

function LoadServerTime() {
    // Load accumulated server time from previous sessions
    if(isFile("temp\\ServerTime.cs"))
    {
        exec("ServerTime.cs");
        if($ServerTimeElapsed == "")
            $ServerTimeElapsed = 0;
        echo("DEBUG LoadServerTime: Loaded accumulated time: " @ $ServerTimeElapsed @ " seconds");
    }
    else
    {
        $ServerTimeElapsed = 0;
        echo("DEBUG LoadServerTime: No saved time found, starting fresh");
    }
    $ServerTimeStart = getSimTime();
}

function SaveWorldDeployables() {
    dbecho($dbechoMode, "SaveWorldDeployables()");
    
    // Clear all old world data to prevent stale entries from being saved
    // Clear up to 1000 entries (should be more than enough)
    for(%clearIdx = 1; %clearIdx <= 1000; %clearIdx++)
    {
        $world::object[%clearIdx] = "";
        $world::owner[%clearIdx] = "";
        $world::pos[%clearIdx] = "";
        $world::rot[%clearIdx] = "";
        $world::team[%clearIdx] = "";
        $world::special[%clearIdx] = "";
        $world::lootbagTime[%clearIdx] = "";
    }
    $world::objectCount = "";
    
    %i = 0;
    %ii = 0;
    %othercnt = 0;
    %lootbagCount = 0;
    
    // First, scan MissionCleanup group for lootbags (more reliable than sequential ID scan)
    %missionCleanup = nameToID("MissionCleanup");
    %currentTime = GetPersistentTime(); // Use persistent time instead of getSimTime()
    %maxAge = 86400; // 24 hours in seconds
    %expiredCount = 0;
    
    if(%missionCleanup != -1)
    {
        %objCount = Group::objectCount(%missionCleanup);
        for(%j = 0; %j < %objCount; %j++)
        {
            %objID = Group::getObject(%missionCleanup, %j);
            %obj = GameBase::getDataName(%objID);
            
            // Skip if object doesn't exist or is invalid
            if(%obj == "" || %objID == -1)
            {
                continue;
            }
            
            if(%obj == "Lootbag")
            {
                // Skip lootbags that have been picked up/deleted (empty loot string)
                // This prevents deleted lootbags from being saved to worldsave
                if($loot[%objID] == "")
                {
                    continue;
                }
                
                // Check if lootbag is older than 24 hours
                // If no timestamp exists (old lootbag), treat as expired to clean up
                if($lootbagTime[%objID] == "")
                {
                    %expiredCount++;
                    // Clean up the old lootbag
                    $loot[%objID] = "";
                    continue;
                }
                
                %lootbagAge = %currentTime - $lootbagTime[%objID];
                if(%lootbagAge > %maxAge)
                {
                    %expiredCount++;
                    // Clean up the expired lootbag
                    $loot[%objID] = "";
                    $lootbagTime[%objID] = "";
                    continue;
                }
                
                %ii++;
                %lootbagCount++;
                $world::object[%ii] = %obj;
                $world::owner[%ii] = $owner[%objID];
                $world::pos[%ii] = GameBase::getPosition(%objID);
                $world::rot[%ii] = GameBase::getRotation(%objID);
                $world::team[%ii] = GameBase::getTeam(%objID);
                
                %loot = $loot[%objID];
                %w0 = getWord(%loot, 0);
                %w1 = getWord(%loot, 1);
                if (%w1 != "*")
                    %loot = %w0 @ " * " @ String::getSubStr(%loot, String::len(%w0)+String::len(%w1)+2, 99999);
                $world::special[%ii] = %loot;
                $world::lootbagTime[%ii] = $lootbagTime[%objID]; // Save timestamp for this lootbag
            }
        }
    }
    
    // Then scan sequential IDs for other deployables (platforms, force fields, trees, etc.)
    %deployableCount = 0;
    while (%othercnt < 15) {
        %i++;
        %ID = 8361 + %i;
        %obj = GameBase::getDataName(%ID);
        if (String::findSubStr($WorldSaveList, "|" @ %obj @ "|") != -1) {
            // Skip lootbags here since we already handled them from MissionCleanup
            if(%obj != "Lootbag")
            {
                %ii++;
                %deployableCount++;
                $world::object[%ii] = %obj;
                $world::owner[%ii] = $owner[%ID];
                $world::pos[%ii] = GameBase::getPosition(%ID);
                $world::rot[%ii] = GameBase::getRotation(%ID);
                $world::team[%ii] = GameBase::getTeam(%ID);
                $world::special[%ii] = "";
            }
        }
        if (%obj == "")
            %othercnt++;
        else
            %othercnt = 0;
    }

    // Set the final object count
    $world::objectCount = %ii;
    
    File::delete("temp\\" @ $missionName @ "_worldsave_.cs");
    
    // Always create the worldsave file, even if no deployables found
    if(%ii == 0) {
        export("world::objectCount", "temp\\" @ $missionName @ "_worldsave_.cs", false);
    } else {
        export("world::objectCount", "temp\\" @ $missionName @ "_worldsave_.cs", false);
        export("world::*", "temp\\" @ $missionName @ "_worldsave_.cs", true);
        export("world::lootbagTime*", "temp\\" @ $missionName @ "_worldsave_.cs", true); // Save lootbag timestamps
    }
    
    // Save server time so timestamps persist across restarts
    SaveServerTime();
}

function SaveWorld() {
    dbecho($dbechoMode, "SaveWorld()");
    echo("Saving world '" @ $missionName @ "_worldsave_.cs'...");

    SaveWorldDeployables();
    
    // Save TotalSealValue to separate file (not from worldsave to avoid AI initialization issues)
    if($TotalSealValue == "" || $TotalSealValue < 20)
        $TotalSealValue = 20;
    
    // Ensure value is numeric (not string) before saving
    $TotalSealValue = $TotalSealValue + 0;
    
    File::delete("temp\\SealValue.cs");
    export("TotalSealValue", "temp\\SealValue.cs", false);
    
    // Save server time so lootbag timestamps persist across restarts
    SaveServerTime();
    
    // Save house objective captures (base control and flag commands)
    SaveHouseObjectives();
    echo("House objectives saved.");
}

function LoadWorld() {
    dbecho($dbechoMode, "LoadWorld()");
    %filename = $missionName @ "_worldsave_.cs";
    if (isFile("temp\\" @ %filename)) {
        echo("Loading world '" @ $missionName @ "_worldsave_.cs'...");
        messageAll(2, "LoadWorld in progress...");
        $ConsoleWorld::DefaultSearchPath = $ConsoleWorld::DefaultSearchPath;
        $LoadingWorldSave = true;
        exec(%filename);
        $LoadingWorldSave = false;

        // Restore house objective captures (base control and flag commands)
        LoadHouseObjectives();
        echo("House objectives restored.");

        for (%i = 1; $world::object[%i] != ""; %i++) {
            if ($world::object[%i] == "DepPlatSmallHorz" ||
                $world::object[%i] == "DepPlatMediumHorz" ||
                $world::object[%i] == "DepPlatSmallVert" ||
                $world::object[%i] == "DepPlatMediumVert") {
                DeployPlatform($world::owner[%i], $world::team[%i], $world::pos[%i], $world::rot[%i], $world::object[%i]);
            } else if ($world::object[%i] == "StaticDoorForceField") {
                DeployForceField($world::owner[%i], $world::team[%i], $world::pos[%i], $world::rot[%i]);
            } else if ($world::object[%i] == "DeployableTree") {
                DeployTree($world::owner[%i], $world::team[%i], $world::pos[%i], $world::rot[%i]);
            } else if ($world::object[%i] == "Lootbag") {
                %lootbagId = DeployLootbag($world::pos[%i], $world::rot[%i], $world::special[%i]);
                // Restore the saved timestamp if it exists (for persistent age tracking)
                if($world::lootbagTime[%i] != "")
                {
                    $lootbagTime[%lootbagId] = $world::lootbagTime[%i];
                }
                // Clear the saved timestamp variable
                $world::lootbagTime[%i] = "";
            }
        }

        messageAll(2, "LoadWorld complete.");
    } else {
        echo("ERROR: Couldn't find world '" @ $missionName @ "_worldsave_.cs'");
    }
}
function DeployPlatform(%name, %team, %pos, %rot, %plattype)
{
	dbecho($dbechoMode, "DeployPlatform(" @ %name @ ", " @ %team @ ", " @ %pos @ ", " @ %rot @ ", " @ %plattype @ ")");

	%platform = newObject("", "StaticShape", %plattype, true);

	$owner[%platform] = %name;

	if($recording[getClientByName(%name)] == 1)
		AddObjectToRec(getClientByName(%name), 1, %pos, %rot);

//	if(%plattype == "DepPlatSmallVert")
//	{
//		%rot = "0 1.5708 " @ GetWord(%rot, 2) + "1.5708";
//		%pos = GetWord(%pos, 0) @ " " @ GetWord(%pos, 1) @ " " @ (GetWord(%pos, 2) + 2);
//	}
//	else if(%plattype == "DepPlatMediumVert")
//	{
//		%rot = "0 1.5708 " @ GetWord(%rot, 2) + "1.5708";
//		%pos = GetWord(%pos, 0) @ " " @ GetWord(%pos, 1) @ " " @ (GetWord(%pos, 2) + 3);
//	}
//	else if(%plattype == "DepPlatLargeVert")
//	{
//		%rot = "0 1.5708 " @ GetWord(%rot, 2) + "1.5708";
//		%pos = GetWord(%pos, 0) @ " " @ GetWord(%pos, 1) @ " " @ (GetWord(%pos, 2) + 4.5);
//	}

	addToSet("MissionCleanup", %platform);
	GameBase::setTeam(%platform, %team);
	GameBase::setPosition(%platform, %pos);
	GameBase::setRotation(%platform, %rot);
	Gamebase::setMapName(%platform, %plattype);
	GameBase::startFadeIn(%platform);
	playSound(SoundPickupBackpack, %pos);
	playSound(ForceFieldOpen, %pos);
}

function DeployLootbag(%pos, %rot, %special)
{
	dbecho($dbechoMode, "DeployLootbag(" @ %pos @ ", " @ %rot @ ", " @ %special @ ")");

	%lootbag = newObject("", "Item", "Lootbag", 1, false);

	$loot[%lootbag] = %special;
	$lootbagTime[%lootbag] = GetPersistentTime(); // Store creation timestamp for age checking (persistent across restarts)

 	addToSet("MissionCleanup", %lootbag);
	
	GameBase::setPosition(%lootbag, %pos);
	GameBase::setRotation(%lootbag, %rot);
	GameBase::setMapName(%lootbag, "Backpack");

	return %lootbag;
}

function NEWgetClientByName(%name)
{
	dbecho($dbechoMode, "NEWgetClientByName(" @ %name @ ")");

	%list = GetEveryoneIdList();
	for(%i = 0; GetWord(%list, %i) != -1; %i++)
	{
		%id = GetWord(%list, %i);
		%displayName = Client::getName(%id);
		if(String::ICompare(%name, %displayName) == 0)
			return %id;
	}
	return -1;
}

function clipTrailingNumbers(%str)
{
	dbecho($dbechoMode, "clipTrailingNumbers(" @ %str @ ")");

	for(%i=0; %i <= String::len(%str); %i++)
	{
		%a = String::getSubStr(%str, %i, 1);
		%b = (%a+1-1);

		if(String::ICompare(%b, %a) == 0)
			break;
	}
	%pos = %i;

	return String::getSubStr(%str, 0, %pos);
}

function UpdateAppearance(%clientId)
{
	dbecho($dbechoMode, "UpdateAppearance(" @ %clientId @ ")");

	//Determine armor from shields
	%armor = -1;
	%shield = -1;
	%list = GetAccessoryList(%clientId, 2, "3 7");
	for(%i = 0; (%w = getCroppedItem(GetWord(%list, %i))) != -1; %i++)
	{
		if($AccessoryVar[%w, $AccessoryType] == $BodyAccessoryType)
			%armor = %w;
		else if($AccessoryVar[%w, $AccessoryType] == $ShieldAccessoryType)
			%shield = %w;
	}
	%player = Client::getOwnedObject(%clientId);
	%race = fetchData(%clientId, "RACE");
	%model = Player::getArmor(%clientId);
	%cw = String::getSubStr(%model, String::findSubStr(%model, "Armor"), 99999);
	%skinbase = Client::getSkinBase(%clientId);
	
	// Initialize %apm, only access $ArmorPlayerModel if %armor is valid
	%apm = "";
	if(%armor != -1 && %armor != "")
	{
		if($ArmorPlayerModel[%armor] != "")
			%apm = $ArmorPlayerModel[%armor];
	}

	//=================================
	// Update skin
	//=================================
	if(%race == "MaleHuman" || %race == "FemaleHuman")
	{
		%skinbase = "rpgbase";

		if(%armor != -1)
			%skinbase = $ArmorSkin[%armor];
	}
	else if(%race == "DeathKnight")
	{
		%skinbase = "cphoenix";
		%apm = "";
		%cw = "Armor22";
		%armor = 0;
	}
	else
	{
		%p = $RaceToArmorType[%race];
		%armor = -1;
	}

	if(Client::getSkinBase(%clientId) != %skinbase)
		Client::setSkin(%clientId, %skinbase);

	//=================================
	// Update player model
	//=================================
	if(%armor != -1)
		%p = %race @ %apm @ %cw;

	%ae = GameBase::getEnergy(%player);

	if(Player::getArmor(%clientId) != %p && %p != "")
	{
		Player::setArmor(%clientId, %p);
		GameBase::setEnergy(%player, %ae);
	}

	//=================================
	// Update shields and Orb
	//=================================
	if(%shield != -1)
	{
		if(Player::getMountedItem(%clientId, 2) != %shield)
		{
			Player::unmountItem(%clientId, 2);
			Player::mountItem(%clientId, %shield, 2);
		}
	}
	else
	{
		%player = Client::getOwnedObject(%clientId);
		if(%player != -1)
		{
			if(Player::getMountedItem(%clientId, 2) != -1)
				Player::unmountItem(%clientId, 2);

			for(%i = 1; $ItemList[Orb, %i] != ""; %i++)
			{
				if(Player::getItemCount(%clientId, $ItemList[Orb, %i] @ "0"))
					Player::mountItem(%clientId, $ItemList[Orb, %i] @ "0", 2);
			}
		}
	}
}

function UpdateTeam(%clientId)
{
	dbecho($dbechoMode, "UpdateTeam(" @ %clientId @ ")");

	%race = fetchData(%clientId, "RACE");
	%t = $TeamForRace[%race];
	
	// Validate team value - default to team 1 (enemy) if invalid
	if(%t == "" || %t == -1)
	{
		echo("WARNING: UpdateTeam - Invalid team for race '" @ %race @ "', defaulting to team 1");
		%t = 1;
	}
	
	GameBase::setTeam(%clientId, %t);
}
function ChangeRace(%clientId, %race)
{
	dbecho($dbechoMode, "ChangeRace(" @ %clientId @ ", " @ %race @ ")");

	if(%race == "DeathKnight")
		storeData(%clientId, "RACE", "DeathKnight");
	else if(%race == "Human")
		storeData(%clientId, "RACE", Client::getGender(%clientId) @ "Human");
	else if(%race == "MaleHuman")
		storeData(%clientId, "RACE", "MaleHuman");
	else if(%race == "FemaleHuman")
		storeData(%clientId, "RACE", "FemaleHuman");

	setHP(%clientId, fetchData(%clientId, "MaxHP"));
	setMANA(%clientId, fetchData(%clientId, "MaxMANA"));

	RefreshAll(%clientId);
}

function ClearVariables(%clientId)
{
	dbecho($dbechoMode2, "ClearVariables(" @ %clientId @ ")");

	%name = Client::getName(%clientId);

	//clear variables

	ClearFunkVar(%name);

	$possessedBy[%clientId] = "";

	//this is only for bots
	// Use temp variable to safely check if BotInfoAiName exists before accessing
	%tempBotName = fetchData(%clientId, "BotInfoAiName");
	if(%tempBotName != "")
		$BotFollowDirective[%tempBotName] = "";

	//clear directives
	$aidirectiveTable[%clientId, 99] = "";

	%clientId.IsInvalid = "";
	%clientId.currentShop = "";
	%clientId.currentBank = "";
	%clientId.currentSmith = "";
	%clientId.currentBeltBank = "";
	%clientId.currentBeltSell = "";
	%clientId.adminLevel = "";
	%clientId.lastWaitActionTime = "";
	%clientId.choosingGroup = "";
	%clientId.choosingClass = "";
	%clientId.possessId = "";
	%clientId.sleepMode = "";
	%clientId.lastSaveCharTime = "";
	%clientId.replyTo = "";
	// TEMPORARILY DISABLED - stealType clearing
	//%clientId.stealType = "";
	%clientId.lastTriggerTime = "";
	%clientId.lastFireTime = "";
	%clientId.lastItemPickupTime = "";
	%clientId.MusicTicksLeft = "";
	%clientId.doExport = "";
	%clientId.TryingToSteal = "";
	%clientId.lastGetWeight = "";
	%clientId.echoOff = "";
	%clientId.lastMissMessage = "";
	%clientId.lastMinePos = "";
	%clientId.bulkNum = "";
	%clientId.zoneLastPos = "";

	for(%i = 0; (%id = GetWord($TownBotList, %i)) != -1; %i++)
	{
		$state[%id, %clientId] = "";
		// Use temp variable to safely check if QuestCounter exists before accessing
		%tempCounter = $QuestCounter[%name, %id.name];
		if(%tempCounter != "")
			$QuestCounter[%name, %id.name] = "";
	}

	for(%i = 1; %i <= $maxDamagedBy; %i++)
		$damagedBy[%name, %i] = "";

	SetAllSkills(%clientId, "");

	ClearEvents(%clientId);

	deleteVariables("BonusState" @ %clientId @ "*");
	deleteVariables("BonusStateCnt" @ %clientId @ "*");

	deleteVariables("ClientData" @ %clientId @ "*");
}
function ClearFunkVar(%name)
{
	dbecho($dbechoMode2, "ClearFunkVar(" @ %name @ ")");

	%method = 1;
	if(%method == 0)
	{
		//clear regular data
		for(%i = 1; %i <= 35; %i++)
		{
			$funk::var["[\"" @ %name @ "\", 0, " @ %i @ "]"] = "";
			$funk::var[%name, 0, %i] = "";
		}
	
		for(%i = 1; $funk::var["[\"" @ %name @ "\", 2, " @ %i @ "]"] != ""; %i++)
			$funk::var["[\"" @ %name @ "\", 2, " @ %i @ "]"] = "";
		for(%i = 1; $funk::var[%name, 2, %i] != ""; %i++)
			$funk::var[%name, 2, %i] = "";
	
		for(%i = 1; $funk::var["[\"" @ %name @ "\", 3, " @ %i @ "]"] != ""; %i++)
			$funk::var["[\"" @ %name @ "\", 3, " @ %i @ "]"] = "";
		for(%i = 1; $funk::var[%name, 3, %i] != ""; %i++)
			$funk::var[%name, 3, %i] = "";
	
		for(%i = 1; $funk::var["[\"" @ %name @ "\", 4, " @ %i @ "]"] != ""; %i++)
			$funk::var["[\"" @ %name @ "\", 4, " @ %i @ "]"] = "";
		for(%i = 1; $funk::var[%name, 4, %i] != ""; %i++)
			$funk::var[%name, 4, %i] = "";
	}
	else
	{
		deleteVariables("funk::var[\"" @ %name @ "\"*");
		deleteVariables("funk::var" @ %name @ "*");
	}

}

function Down(%t)
{
	dbecho($dbechoMode, "Down(" @ %t @ ")");

	%tinsec = %t * 60;
	for(%i = %t; %i > 1; %i--)
	{
		%a = (%tinsec - (60 * %i));
		schedule("dmsg(" @ %i @ ", \"minutes\");", %a);
	}

	if(%tinsec > 60)
		%startfrom = 60;
	else
		%startfrom = %tinsec;

	for(%i = %startfrom; %i >= 1; %i -= 10)
	{
		%a = (%tinsec - %i);
		schedule("dmsg(" @ %i @ ", \"seconds\");", %a);
	}
	schedule("focusserver();quit();", %tinsec);
}
function d(%t)
{
	Down(%t);
}
function dmsg(%i, %w)
{
	echo("========= SERVER RESTARTING IN " @ %i @ " " @ %w @ " =========");
	messageAll(1, "Server restarting in " @ %i @ " " @ %w @ ", please disconnect to save your character.");
}

function GetEveryoneIdList()
{
	dbecho($dbechoMode, "GetEveryoneIdList()");

	// Initialize %list at the start to prevent debug warnings

	%list = "";
	%playerList = GetPlayerIdList();
	%botList = GetBotIdList();
	
	// Ensure both lists are initialized (they should be, but be safe)
	if(%playerList == "")
		%playerList = "";
	if(%botList == "")
		%botList = "";
	
	%list = %playerList @ %botList;
	return %list;
}
function GetEveryoneNameList()
{
	dbecho($dbechoMode, "GetEveryoneNameList()");

	%list = "";
	%list = %list @ GetPlayerNameList();
	%list = %list @ GetBotNameList();
	return %list;
}

function GetBotIdList()
{
	dbecho($dbechoMode, "GetBotIdList()");

	%list = "";

	%tempSet = nameToID("MissionCleanup");
	if(%tempSet != -1)
	{
		%num = Group::objectCount(%tempSet);
		for(%i = 0; %i <= %num-1; %i++)
		{
			%tempItem = Group::getObject(%tempSet, %i);

			if(getObjectType(%tempItem) == "Player")
			{
				%clientId = Player::getClient(%tempItem);
				if(Player::isAiControlled(%clientId))
				{
					%list = %list @ %clientId @ " ";
				}
			}
		}
	}

	return %list;
}
function GetBotNameList()
{
	dbecho($dbechoMode, "GetBotNameList()");

	%list = "";

	%tempSet = nameToID("MissionCleanup");
	if(%tempSet != -1)
	{
		%num = Group::objectCount(%tempSet);
		for(%i = 0; %i <= %num-1; %i++)
		{
			%tempItem = Group::getObject(%tempSet, %i);
			if(getObjectType(%tempItem) == "Player")
			{
				%clientId = Player::getClient(%tempItem);
				if(Player::isAiControlled(%clientId))
				{
					//%list = %list @ Client::getName(%clientId) @ " ";
					%list = %list @ fetchData(%clientId, "BotInfoAiName") @ " ";
				}
			}
		}
	}

	return %list;
}
function GetPlayerIdList()
{
	dbecho($dbechoMode, "GetPlayerIdList()");

	%list = "";
	for(%c = Client::getFirst(); %c != -1; %c = Client::getNext(%c))
	{
		%list = %list @ %c @ " ";
	}
	return %list;
}
function GetPlayerNameList()
{
	dbecho($dbechoMode, "GetPlayerNameList()");

	%list = "";
	for(%c = Client::getFirst(); %c != -1; %c = Client::getNext(%c))
	{
		%list = %list @ Client::getName(%c) @ " ";
	}
	return %list;
}

function ChangeWeather()
{
	dbecho($dbechoMode, "ChangeWeather()");

	//credits go to LabRat for the original code for this... Thanks Lab!
	if(OddsAre(1))
	{
		$isRaining = "";

		%intensity = getRandom();

		%x = -1 + (getRandom() * 1.5);
		%y = -1 + (getRandom() * 1.5);
		%z = -300 + (floor(getRandom() * 40));
		%vec = %x @ " " @ %y @ " " @ %z;

		%t = floor(getRandom() * 100);
		if(%t >= 0 && %t < 20)
		{
			%type = 1;			//rain
			$isRaining = True;
			//setTerrainVisibility(8, 600, 0);
		}
		else
		{
			%type = -1;			//stop any weather
			//setTerrainVisibility(8, 1000, 700);
		}

		if(isObject("weather"))
			deleteObject("weather");

		if(%type == 1)
			%weather = newObject("weather", Snowfall, %intensity, %vec, 0, %type);
	}
}

function FindInvalidChar(%name)
{
	dbecho($dbechoMode, "FindInvalidChar(" @ %name @ ")");

	//looks for invalid characters in player's name
	for(%a = 1; %a <= String::len($invalidChars); %a++)
	{
		%b = String::getSubStr($invalidChars, %a-1, 1);
		if(String::findSubStr(%name, %b) != -1)
		{
			return %a-1;
		}
	}
	return "";
}

function CheckForReservedWords(%name)
{
	dbecho($dbechoMode, "CheckForReservedWords(" @ %name @ ")");

	%w[%c++] = "ArenaGladiator";
	%w[%c++] = "Traveller";
	%w[%c++] = "Goblin";
	%w[%c++] = "Gnoll";
	%w[%c++] = "Orc";
	%w[%c++] = "Ogre";
	%w[%c++] = "Elf";
	%w[%c++] = "Undead";
	%w[%c++] = "Minotaur";

	//exact words
	%ew[%d++] = "rpgfunk";
	%ew[%d++] = "crystal";
	%ew[%d++] = "game";
	%ew[%d++] = "item";
	%ew[%d++] = "mine";
	%ew[%d++] = "vehicle";
	%ew[%d++] = "comchat";
	%ew[%d++] = "server";
	%ew[%d++] = "turret";
	%ew[%d++] = "player";
	%ew[%d++] = "observer";
	%ew[%d++] = "ai";
	%ew[%d++] = "client";
	%ew[%d++] = "station";
	%ew[%d++] = "admin";
	%ew[%d++] = "staticshape";
	%ew[%d++] = "armordata";
	%ew[%d++] = "baseexpdata";
	%ew[%d++] = "baseprojdata";
	%ew[%d++] = "clientdefaults";
	%ew[%d++] = "nsound";
	%ew[%d++] = "shopping";
	%ew[%d++] = "zone";
	%ew[%d++] = "specialarmors";
	%ew[%d++] = "accessory";
	%ew[%d++] = "enemyarmors";
	%ew[%d++] = "spawn";
	%ew[%d++] = "registerobjects";
	%ew[%d++] = "registeruserobjects";
	%ew[%d++] = "tsdefaultmatprops";
	%ew[%d++] = "rpgstats";
	%ew[%d++] = "classes";
	%ew[%d++] = "weapons";
	%ew[%d++] = "globals";
	%ew[%d++] = "humanarmors";
	%ew[%d++] = "remote";
	%ew[%d++] = "playerspawn";
	%ew[%d++] = "gameevents";
	%ew[%d++] = "connectivity";
	%ew[%d++] = "playerdamage";
	%ew[%d++] = "economy";
	%ew[%d++] = "itemevents";
	%ew[%d++] = "weaponhandling";
	%ew[%d++] = "depbase";
	%ew[%d++] = "weight";
	%ew[%d++] = "mana";
	%ew[%d++] = "hp";
	%ew[%d++] = "rpgarena";
	%ew[%d++] = "ferry";
	%ew[%d++] = "spells";
	%ew[%d++] = "skills";
	%ew[%d++] = "serverdefaults";
	%ew[%d++] = "sleep";
	%ew[%d++] = "plugs";
	%ew[%d++] = "editorconfig";
	%ew[%d++] = "worlds";
	%ew[%d++] = "changemission";
	%ew[%d++] = "commander";
	%ew[%d++] = "editmission";
	%ew[%d++] = "gui";
	%ew[%d++] = "interiorlight";
	%ew[%d++] = "ircclient";
	%ew[%d++] = "med";
	%ew[%d++] = "missionlist";
	%ew[%d++] = "missiontypes";
	%ew[%d++] = "newmission";
	%ew[%d++] = "sae";
	%ew[%d++] = "playersetup";
	%ew[%d++] = "registervolume";
	%ew[%d++] = "ted";
	%ew[%d++] = "trees";
	%ew[%d++] = "trigger";
	%ew[%d++] = "basedebrisdata";
	%ew[%d++] = "beacon";
	%ew[%d++] = "chatmenu";
	%ew[%d++] = "clientdefaults";
	%ew[%d++] = "dm";
	%ew[%d++] = "editor";
	%ew[%d++] = "keys";
	%ew[%d++] = "loadshow";
	%ew[%d++] = "marker";
	%ew[%d++] = "menu";
	%ew[%d++] = "mission";
	%ew[%d++] = "move";
	%ew[%d++] = "moveable";
	%ew[%d++] = "options";
	%ew[%d++] = "sensor";
	%ew[%d++] = "sound";
	%ew[%d++] = "tag";
	%ew[%d++] = "terrains";
	%ew[%d++] = "objectives";
	%ew[%d++] = "tmpPrize";
	%ew[%d++] = "all";

	for(%i = 1; %w[%i] != ""; %i++)
	{
		if(String::findSubStr(%name, %w[%i]) != -1)
			return %w[%i];
	}
	for(%i = 1; %ew[%i] != ""; %i++)
	{
		if(String::ICompare(%name, %ew[%i]) == 0)
			return %ew[%i];
	}

	%list = GetBotNameList();
	for(%i = 0; (%b = GetWord(%list, %i)) != -1; %i++)
	{
		if(String::findSubStr(%name, %b) != -1)
			return %b;
	}

	return "";
}

function CheckForProtectedWords(%string)
{
	dbecho($dbechoMode, "CheckForProtectedWords(" @ %string @ ")");

	//this function checks for words that shouldn't be used in the #if statement due to its extremely powerful nature
	%w[1] = "Admin";
	%w[2] = "ResetPlayer";
	%w[3] = "storedata";
	%w[4] = "down";
	%w[5] = "quit";
	%w[6] = "eval";
	
	for(%i = 1; %w[%i] != ""; %i++)
	{
		if(String::findSubStr(%string, %w[%i]) != -1)
			return %w[%i];
	}

	return "";
}

function RandomPositionXY(%minrad, %maxrad)
{
	dbecho($dbechoMode, "RandomPositionXY(" @ %minrad @ ", " @ %maxrad @ ")");

	%diff = %maxrad - %minrad;

	%tmpX = floor(getRandom() * (%diff*2)) - %diff;
	if(%tmpX < 0)
		%tmpX -= %minrad;
	else
		%tmpX += %minrad;

	%tmpY = floor(getRandom() * (%diff*2)) - %diff;
	if(%tmpY < 0)
		%tmpY -= %minrad;
	else
		%tmpY += %minrad;

	return %tmpX @ " " @ %tmpY @ " ";
}

function OddsAre(%n)
{
	dbecho($dbechoMode, "OddsAre(" @ %n @ ")");

	%a = floor(getRandom() * %n);
	if(%a == %n-1)
		return True;
	else
		return False;
}

function TeleportToMarker(%clientId, %markergroup, %testpos, %random)
{
	dbecho($dbechoMode, "TeleportToMarker(" @ %clientId @ ", " @ %markergroup @ ", " @ %testpos @ ", " @ %random @ ")");

	%group = nameToID("MissionGroup\\" @ %markergroup);

	if(%group != -1)
	{	
		%num = Group::objectCount(%group);

		if(%random)
		{
			%r = floor(getRandom() * %num);
		      %marker = Group::getObject(%group, %r);
		
			%worldLoc = GameBase::getPosition(%marker);
	
			if(%testpos)
			{
				%set = newObject("tempset", SimSet);
				%n = containerBoxFillSet(%set, $SimPlayerObjectType, %worldLoc, 1.0, 1.0, 1.5, getWord(%worldLoc, 2));
				deleteObject(%set);

				if(%n > 0)
				{
					GameBase::setPosition(%clientId, %worldLoc);
					return %worldLoc;
				}
			}
			else
			{
				GameBase::setPosition(%clientId, %worldLoc);
				return %worldLoc;
			}
		}
		else
		{
			for(%i = 0; %i <= %num-1; %i++)
			{
			      %marker = Group::getObject(%group, %i);
			
				%worldLoc = GameBase::getPosition(%marker);
		
				if(%testpos)
				{
					//this is part of the method SF uses for their teleporters.  thanks Hosed
					%set = newObject("tempset", SimSet);
					%n = containerBoxFillSet(%set, $SimPlayerObjectType, %worldLoc, 1.0, 1.0, 1.5, getWord(%worldLoc, 2));
					deleteObject(%set);

					if(%n == 0)
					{
						GameBase::setPosition(%clientId, %worldLoc);
						return %worldLoc;
					}
				}
				else
				{
					GameBase::setPosition(%clientId, %worldLoc);
					return %worldLoc;
				}
			}
		}
	}
	
	return False;
}

function TossLootbag(%clientId, %loot, %vel, %namelist, %t)
{
	dbecho($dbechoMode2, "TossLootbag(" @ %clientId @ ", " @ %loot @ ", " @ %vel @ ", " @ %namelist @ ", " @ %t @ ")");

	%player = Client::getOwnedObject(%clientId);
	%ownerName = Client::getName(%clientId);

	%lootbag = newObject("", "Item", "Lootbag", 1, false);

	if(%t > 0)
		schedule("$loot[" @ %lootbag @ "] = \"" @ %ownerName @ " * " @ %loot @ "\";", %t, %lootbag);
	else
	{
		if($LootbagPopTime != -1)
		{
			schedule("Item::Pop(" @ %lootbag @ ");", $LootbagPopTime, %lootbag);
			schedule("storeData(" @ %clientId @ ", \"lootbaglist\", RemoveFromCommaList(\"" @ fetchData(%clientId, "lootbaglist") @ "\", " @ %lootbag @ "));", $LootbagPopTime, %lootbag);
		}
	}

	%loot = %ownerName @ " " @ %namelist @ " " @ %loot;

	$loot[%lootbag] = %loot;
	$lootbagTime[%lootbag] = GetPersistentTime(); // Store creation timestamp for age checking (persistent across restarts)
	storeData(%clientId, "lootbaglist", AddToCommaList(fetchData(%clientId, "lootbaglist"), %lootbag));

	addToSet("MissionCleanup", %lootbag);
	GameBase::setMapName(%lootbag, "Backpack");
	GameBase::throw(%lootbag, %player, %vel, false);

	//Make sure there aren't more than 15 packs per player... This is to resolve lag problems
	%lootbaglist = fetchData(%clientId, "lootbaglist");
	if(CountObjInCommaList(%lootbaglist) > 15)
	{
		%p = String::findSubStr(%lootbaglist, ",");
		%w = String::getSubStr(%lootbaglist, 0, %p);

		Item::Pop(%w);
		storeData(%clientId, "lootbaglist", RemoveFromCommaList(%lootbaglist, %w));
	}

}

function ChangeSky(%sky)
{
	dbecho($dbechoMode, "ChangeSky(" @ %sky @ ")");

	%group = nameToId("MissionGroup\\LandScape");
	if(%group != -1)
	{
		%count = Group::objectCount(%group);
		for(%i = 0; %i <= %count-1; %i++)
		{
			%object = Group::getObject(%group, %i);
			if(getObjectType(%object) == "Sky")
			{
				deleteobject(%object);
			}
		}
	}

	%newsky = newObject(Sky, Sky, 0, 0, 0, %sky, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15);
	addToSet("MissionGroup\\LandScape", %newsky);
}


function round(%n)
{
//	dbecho($dbechoMode, "round(" @ %n @ ")");

	if(%n < 0)
	{
		%t = -1;
		%n = -%n;
	}	
	else if(%n >= 0)
		%t = 1;

	%f = floor(%n);
	%a = %n - %f;
	if(%a < 0.5)
		%b = 0;
	else if(%a >= 0.5)
		%b = 1;

	return (%f + %b) * %t;
}

function RefreshAll(%clientId)
{
	dbecho($dbechoMode, "RefreshAll(" @ %clientId @ ")");

//	echo("===== DEBUG RefreshAll: START =====");
//echo("DEBUG RefreshAll: clientId = " @ %clientId);

	%race = fetchData(%clientId, "RACE");
	//echo("DEBUG RefreshAll: RACE = '" @ %race @ "'");
	if(String::findSubStr(%race, "Human") != -1)
	{
//		echo("DEBUG RefreshAll: Calling RefreshWeight...");
		RefreshWeight(%clientId);
//		echo("DEBUG RefreshAll: RefreshWeight completed");
	}

//	echo("DEBUG RefreshAll: Calling UpdateAppearance...");
	UpdateAppearance(%clientId);
//	echo("DEBUG RefreshAll: UpdateAppearance completed");

//	echo("DEBUG RefreshAll: Calling refreshHPREGEN...");
	refreshHPREGEN(%clientId);
//	echo("DEBUG RefreshAll: refreshHPREGEN completed");

//	echo("DEBUG RefreshAll: Calling refreshMANAREGEN...");
	refreshMANAREGEN(%clientId);
//	echo("DEBUG RefreshAll: refreshMANAREGEN completed");

	// Check if player is in bane stance and has run out of mana - switch back to previous stance
	%stance = fetchData(%clientId, "Stance");
	%mana = fetchData(%clientId, "MANA");
	if((%stance == "MageBane" || %stance == "BladeBane") && (%mana == "" || %mana <= 0))
	{
		%previousStance = fetchData(%clientId, "PreviousStance");
		// If no previous stance stored, default to Normal
		if(%previousStance == "" || %previousStance == -1)
			%previousStance = "Normal";
		storeData(%clientId, "Stance", %previousStance);
		storeData(%clientId, "PreviousStance", ""); // Clear previous stance
		Client::sendMessage(%clientId, $MsgBeige, "You have run out of mana - Returning to " @ %previousStance @ ".");
		// Refresh mana regeneration to reset the drain rate now that we're out of bane stance
		refreshMANAREGEN(%clientId);
	}

//	echo("DEBUG RefreshAll: Calling Game::refreshClientScore...");
	Game::refreshClientScore(%clientId);
//	echo("DEBUG RefreshAll: Game::refreshClientScore completed");

//	echo("===== DEBUG RefreshAll: COMPLETE =====");
}

function HasThisStuff(%clientId, %list, %multiplier)
{
	dbecho($dbechoMode, "HasThisStuff(" @ %clientId @ ", " @ %list @ ")");

	if(%list == "")
		return True;

	if(%multiplier == "" || %multiplier <= 0)
		%multiplier = 1;

	%name = Client::getName(%clientId);

	//--------
	// PASS 1
	//--------
	%flag = False;

	for(%i = 0; GetWord(%list, %i) != -1; %i+=2)
	{
		%w = GetWord(%list, %i);
		%w2 = GetWord(%list, %i+1);
		%tw2 = %w2 * 1;
		if(%tw2 == %w2)
			%w2 *= %multiplier;

		if(%w == "LVLG")
		{
			if(fetchData(%clientId, "LVL") > %w2)
				%flag = True;
			else
				%flag = 667;
		}
		else if(%w == "LVLS")
		{
			if(fetchData(%clientId, "LVL") < %w2)
				%flag = True;
			else
				%flag = 667;
		}
		else if(%w == "LVLE")
		{
			if(fetchData(%clientId, "LVL") == %w2)
				%flag = True;
			else
				%flag = 667;
		}
	}

	if(%flag == 667)
		return %flag;


	//--------
	// PASS 2
	//--------
	%cntindex = 0;
	%flag = False;

	for(%i = 0; GetWord(%list, %i) != -1; %i+=2)
	{
		%w = GetWord(%list, %i);
		%w2 = GetWord(%list, %i+1);
		%tw2 = %w2 * 1;
		if(%tw2 == %w2)
			%w2 *= %multiplier;

		if(%w == "CNT")
		{
			%cntindex++;
			%tmpcnt[%cntindex] = %w2;
		}
		else if(%w == "CNTAFFECTS")
		{
			%tmpcntaffects[%cntindex] = %w2;
		}
	}

	//Process the counter data, if any
	for(%i = 1; %tmpcnt[%i] != ""; %i++)
	{
		if(%tmpcnt[%i] != "" && %tmpcntaffects[%i] != "")
		{
			%firstchar = String::getSubStr(%tmpcnt[%i], 0, 1);
			%n = floor(String::getSubStr(%tmpcnt[%i], 1, 9999));
			if(%firstchar == "<")
			{
				if($QuestCounter[%name, %tmpcntaffects[%i]] < %n)
					%flag = True;
				else
					%flag = 666;
			}
			else if(%firstchar == ">")
			{
				if($QuestCounter[%name, %tmpcntaffects[%i]] > %n)
					%flag = True;
				else
					%flag = 666;
			}
			else if(%firstchar == "=")
			{
				if($QuestCounter[%name, %tmpcntaffects[%i]] == %n)
					%flag = True;
				else
					%flag = 666;
			}
		}
		if(%flag == 666)
			return %flag;
	}


	//--------
	// PASS 3
	//--------
	%flag = True;

	for(%i = 0; GetWord(%list, %i) != -1; %i+=2)
	{
		%w = GetWord(%list, %i);
		%w2 = GetWord(%list, %i+1);
		%tw2 = %w2 * 1;
		if(%tw2 == %w2)
			%w2 *= %multiplier;

		if(%w == "COINS")
		{
			if(fetchData(%clientId, "COINS") >= %w2)
				%flag = True;
			else
				return False;
		}
		else if(%w == "REMORT")
		{
			if(fetchData(%clientId, "RemortStep") >= %w2)
				%flag = True;
			else
				return False;
		}
		else if(%w == "TOURNYRANK")
		{
			if(fetchData(%clientId, "TournyRank") >= %w2)
				%flag = True;
			else
				return False;
		}
		else if(%w == "RankPoints")
		{
			if(fetchData(%clientId, "RankPoints") >= %w2)
				%flag = True;
			else
				return False;
		}
		else if(%w == "AI")
		{
			%isAI = Player::isAIcontrolled(%clientId);
			if(%isAI == %w2)
				%flag = True;
			else
				return False;
		}
		else if(%w == "EXP")
		{
			if(fetchData(%clientId, "EXP") >= %w2)
				%flag = True;
			else
				return False;
		}
		else if(isBeltItem(%w))
		{
			%amnt = Belt::HasThisStuff(%clientid,%w);
			if(%amnt >= %w2)
				%flag = True;
			else
				return False;
		}
		else if(%w != "COINS" && %w != "REMORT" && %w != "LVLG" && %w != "LVLS" && %w != "LVLE" && %w != "CNT" && %w != "CNTAFFECTS" && %w != "RankPoints" && %w != "AI" && %w != "EXP" && %w != "TOURNYRANK")
		{
			if(Player::getItemCount(%clientId, %w) >= %w2)
				%flag = True;
			else
				return False;
		}
	}

	return %flag;
}

function TakeThisStuff(%clientId, %list, %multiplier)
{
	dbecho($dbechoMode, "TakeThisStuff(" @ %clientId @ ", " @ %list @ ")");

	if(%multiplier == "" || %multiplier <= 0)
		%multiplier = 1;

	for(%i = 0; GetWord(%list, %i) != -1; %i+=2)
	{
		%w = GetWord(%list, %i);
		%w2 = GetWord(%list, %i+1);
		%tw2 = %w2 * 1;
		if(%tw2 == %w2)
			%w2 *= %multiplier;

		if(%w == "COINS")
		{
			if(fetchData(%clientId, "COINS") >= %w2)
				storeData(%clientId, "COINS", %w2, "dec");
			else
				return False;
		}
		else if(%w == "EXP")
		{
			if(fetchData(%clientId, "EXP") >= %w2)
				storeData(%clientId, "EXP", %w2, "dec");
			else
				return False;
		}
		else if(%w == "CNT" || %w == "CNTAFFECTS" || %w == "LVLG" || %w == "LVLS" || %w == "LVLE")
		{
			//ignore
		}
		else if(isBeltItem(%w))
		{
			%amount = Belt::HasThisStuff(%clientid,%w);
			if(%amount >= %w2)
				Belt::TakeThisStuff(%clientid,%w,%w2);
			else
				return False;
		}
		else
		{
			%amount = Player::getItemCount(%clientId, %w);
			if(%amount >= %w2)
				Player::setItemCount(%clientId, %w, %amount-%w2);
			else
				return False;
		}
	}

	return True;
}

function GiveThisStuff(%clientId, %list, %echo, %multiplier)
{
	// Initialize %list to empty string if not provided
	if(%list == "")
		%list = "";
	
	dbecho($dbechoMode, "GiveThisStuff(" @ %clientId @ ", " @ %list @ ", " @ %echo @ ")");

	%name = Client::getName(%clientId);

	if(%multiplier == "" || %multiplier <= 0)
		%multiplier = 1;

	%cntindex = 0;

	for(%i = 0; GetWord(%list, %i) != -1; %i+=2)
	{
		%w = GetWord(%list, %i);
		%w2 = GetWord(%list, %i+1);

		//if there is a / in %w2, then what trails after the / is the minimum random number between 0 and 100 which
		//is applied as a percentage to the starting number of %w2
		// For AI bots, skip the percentage roll on spawn - it will be rolled when the bot dies
		// For players, roll the percentage immediately
		%spos = String::findSubStr(%w2, "/");
		if(%spos > 0)
		{
			%original = String::getSubStr(%w2, 0, %spos);
			%perc = String::getSubStr(%w2, %spos+1, 99999);

			if(isRPGAI(%clientId))
			{
				// For AI bots, give the full original count and preserve percentage format for later roll on death
				// This prevents double-dipping the percentage chance
				%w2 = %original;
			}
			else
			{
				// For players, roll the percentage immediately
				// Check if percentage is a range (e.g., "10-15" or "5-10")
				%rangePos = String::findSubStr(%perc, "-");
				%firstChar = String::getSubStr(%perc, 0, 1);
				if(%rangePos > 0 && %firstChar != "-")
				{
					// Variable drop rate range (e.g., 10-15% means roll between 10% and 15%)
					%minPerc = String::getSubStr(%perc, 0, %rangePos);
					%maxPerc = String::getSubStr(%perc, %rangePos + 1, 99999);
					
					// Randomly choose a drop chance within the range
					%chance = %minPerc + floor(getRandom() * (%maxPerc - %minPerc + 1));
					if(%chance > %maxPerc) %chance = %maxPerc;
					
					%roll = floor(getRandom() * 100) + 1;  // Roll 1-100
					
					if(%roll <= %chance)
						%w2 = %original;
					else
						%w2 = 0;
				}
				else if(%perc < 0)
				{
					// Negative percentages indicate rare drops (low chance)
					%absPerc = -%perc;  // Convert -100 to 100
					%roll = floor(getRandom() * 100) + 1;  // Roll 1-100
					
					// For -100, need roll of 100 (1% chance)
					// For -50, need roll >= 51 (50% chance)
					// Formula: need roll >= (100 - absPerc + 1), but for absPerc >= 100, need exact 100
					%minRoll = 100 - %absPerc + 1;
					if(%absPerc >= 100) %minRoll = 100;  // -100 or more rare -> need exactly 100 (1% chance)
					
					if(%roll >= %minRoll)
						%w2 = %original;
					else
						%w2 = 0;
				}
				else
				{
					// Single fixed percentage (e.g., 5% or 10%)
					%roll = floor(getRandom() * 100) + 1;  // Roll 1-100
					
					if(%roll <= %perc)
						%w2 = %original;
					else
						%w2 = 0;
				}
				
				if(%w2 < 0) %w2 = 0;
			}
		}

		//if there is a d in %w2 AND it has a number on either side, then it's a dice roll
		%dpos = String::findSubStr(%w2, "d");
		%l1 = String::getSubStr(%w2, %dpos-1, 1);
		%l2 = floor(%l1);
		%r1 = String::getSubStr(%w2, %dpos+1, 1);
		%r2 = floor(%r1);
		if(%dpos > 0 && String::ICompare(%l1, %l2) == 0 && String::ICompare(%r1, %r2) == 0)
		{
			%w2 = GetRoll(%w2);
			if(%w2 < 1) %w2 = 1;
		}

		%tw2 = %w2 * 1;
		if(%tw2 == %w2)
			%w2 *= %multiplier;

		if(%w == "COINS")
		{
			storeData(%clientId, "COINS", %w2, "inc");
			if(%echo) Client::sendMessage(%clientId, 0, "You received " @ %w2 @ " coins.");
		}
		else if(%w == "EXP")
		{
			storeData(%clientId, "EXP", %w2, "inc");
			if(%echo) Client::sendMessage(%clientId, 0, "You received " @ %w2 @ " experience.");
		}
		else if(%w == "LCK")
		{
			storeData(%clientId, "LCK", %w2, "inc");
			if(%echo) Client::sendMessage(%clientId, 0, "You received " @ %w2 @ " LCK.");
		}
		else if(%w == "SP")
		{
			storeData(%clientId, "SPcredits", %w2, "inc");
			if(%echo) Client::sendMessage(%clientId, 0, "You received " @ %w2 @ " Skill Points.");
		}
		else if(%w == "CLASS")
		{
			storeData(%clientId, "CLASS", %w2);
			storeData(%clientId, "GROUP", $ClassGroup[fetchData(%clientId, "CLASS")]);
		}
		else if(%w == "LVL")
		{
			//note: the class MUST be specified in %stuff prior to this call
			storeData(%clientId, "EXP", GetExp(%w2, %clientId) + 100);
		}
		else if(%w == "REMORT")
		{
			//note: the class MUST be specified in %stuff prior to this call
			storeData(%clientId, "RemortStep", %w2);
		}
		else if(%w == "TOURNYRANK")
		{
			//note: the class MUST be specified in %stuff prior to this call
			storeData(%clientId, "TournyRank", %w2);
		}
		else if(%w == "TEAM")
		{
			GameBase::setTeam(%clientId, %w2);
			if(%echo) Client::sendMessage(%clientId, 0, "Team set to " @ %w2 @ ".");
		}
		else if(%w == "RankPoints")
		{
			storeData(%clientId, "RankPoints", %w2, "inc");
			if(%echo) Client::sendMessage(%clientId, 0, "You received " @ %w2 @ " Rank Points.");
		}
		else if(%w == "CNT")
		{
			%cntindex++;
			%tmpcnt[%cntindex] = %w2;
		}
		else if(%w == "CNTAFFECTS")
		{
			%tmpcntaffects[%cntindex] = %w2;
		}
		else if(isBackpackItem(%w))
		{
			// Validate item and count before giving to belt
			// Skip invalid entries: empty item, item "0", empty count, count -1, count <= 0
			if(%w != "" && %w != -1 && %w != "0" && %w2 != "" && %w2 != -1 && %w2 != "-1" && (%w2 * 1) > 0)
			{
				Belt::GiveThisStuff(%clientId, %w, %w2, %echo);
			}
		}
		else
		{
			// Get player object - Item::giveItem expects a player object, not a clientId
			%player = Client::getOwnedObject(%clientId);
			if(%player != "" && %player != -1)
			{
				Item::giveItem(%player, %w, %w2, %echo);
			}
			else
			{
				echo("ERROR: GiveThisStuff - could not find player object for clientId " @ %clientId);
			}
		}
	}

	RefreshAll(%clientId);

	//Process the counter data, if any
	for(%i = 1; %tmpcnt[%i] != ""; %i++)
	{
		if(%tmpcnt[%i] != "" && %tmpcntaffects[%i] != "")
		{
			%first = String::getSubStr(%tmpcnt[%i], 0, 1);
			if(%first == "+" || %first == "-")
				$QuestCounter[%name, %tmpcntaffects[%i]] += floor(%tmpcnt[%i]);
			else
				$QuestCounter[%name, %tmpcntaffects[%i]] = floor(%tmpcnt[%i]);
		}
	}
}
	
function getSpawnIndex(%aiName)
{
	dbecho($dbechoMode, "getSpawnIndex(" @ %aiName @ ")");

	for(%i = 1; $spawnIndex[%i] != ""; %i++)
	{
		if($spawnIndex[%i] == %aiName)
			return %i;
	}
	return -1;
}

function FellOffMap(%id)
{
	dbecho($dbechoMode, "FellOffMap(" @ %id @ ")");

	RefreshAll(%id);

	if(Player::isAiControlled(%id))
	{
		storeData(%id, "noDropLootbagFlag", True);
		playNextAnim(%id);
		Player::Kill(%id);
	}
	else
	{
		CheckAndBootFromArena(%id);
		Item::setVelocity(%id, "0 0 0");
		TeleportToMarker(%id, "TheArena\\TeleportExitMarkers", 0, 0);

		Client::sendMessage(%id, $MsgRed, "You were restored to the arena exit marker.");
	}
}

function SetStuffString(%stuff, %item, %amount)
{
	dbecho($dbechoMode, "SetStuffString(" @ %stuff @ ", " @ %item @ ", " @ %amount @ ")");

	//replaces both Add and Remove stuff string functions by enabling negative values for %amount

	//echo("DEBUG SetStuffString: INPUT - stuff='" @ %stuff @ "', item='" @ %item @ "', amount=" @ %amount);
	%stuff = FixStuffString(%stuff);
	//echo("DEBUG SetStuffString: AFTER FixStuffString - stuff='" @ %stuff @ "'");

	%searchStr = " " @ %item @ " ";
	%pos = String::findSubStr(%stuff, %searchStr);
	//echo("DEBUG SetStuffString: Search for '" @ %searchStr @ "' found at position " @ %pos);

	if(%pos != -1)
	{
		%a = String::NEWgetSubStr(%stuff, %pos+1, 99999);
		%amt = GetWord(%a, 1);	//getword 0 would be the item, so getword 1 is the amount (which follows the item)
		//echo("DEBUG SetStuffString: Found item, substring after item='" @ %a @ "', extracted count='" @ %amt @ "'");
		
		// Validate extracted count - if it's "0", empty, or not a valid number, the string is corrupted
		// Try to find the actual count by looking for the next word that's a number
		%amtNum = %amt * 1;
		if(%amt == "" || %amt == -1 || %amt == "0" || (%amtNum == 0 && %amt != "0"))
		{
			//echo("DEBUG SetStuffString: WARNING - Extracted count '" @ %amt @ "' is invalid! String may be corrupted. Trying to find actual count...");
			// Try to get the next word as the count
			%amt = GetWord(%a, 1);
			%amtNum = %amt * 1;
			if(%amt == "" || %amt == -1 || %amt == "0" || (%amtNum == 0 && %amt != "0"))
			{
				//echo("DEBUG SetStuffString: ERROR - Cannot find valid count for item '" @ %item @ "' in corrupted string. Skipping operation.");
				return %stuff; // Return original string unchanged if we can't parse it
			}
		}

		%part1 = String::NEWgetSubStr(%stuff, 0, %pos+1);
		%skipLen = %pos+String::len(%item)+String::len(%amt)+3;
		%part2 = String::NEWgetSubStr(%stuff, %skipLen, 99999);
		//echo("DEBUG SetStuffString: part1='" @ %part1 @ "', skipLen=" @ %skipLen @ ", part2='" @ %part2 @ "'");

		%b = %amt + %amount;
		//echo("DEBUG SetStuffString: count calculation: " @ %amt @ " + " @ %amount @ " = " @ %b);
		
		if(%b <= 0)
		{
			%part3 = "";
			//echo("DEBUG SetStuffString: Removing item (count <= 0)");
		}
		else
		{
			%part3 = %item @ " " @ %b @ " ";
			//echo("DEBUG SetStuffString: Keeping item with new count, part3='" @ %part3 @ "'");
		}

		%final = %part1 @ %part2 @ %part3;
		//echo("DEBUG SetStuffString: FINAL result='" @ %final @ "'");
	}
	else
	{
		%final = %stuff @ %item @ " " @ %amount @ " ";
		//echo("DEBUG SetStuffString: Item not found, adding new item, FINAL='" @ %final @ "'");
	}

	// Normalize result: trim leading/trailing spaces and convert " " or "0" to empty string
	%final = FixStuffString(%final);
	%len = String::len(%final);
	// Remove trailing space if present
	if(%len > 0 && String::getSubStr(%final, %len-1, 1) == " ")
		%final = String::getSubStr(%final, 0, %len-1);
	// Remove leading space if present
	if(%len > 0 && String::getSubStr(%final, 0, 1) == " ")
		%final = String::getSubStr(%final, 1, 99999);
	// Normalize "0" or empty/whitespace-only strings to empty string
	if(%final == "0" || %final == " " || %final == "")
		%final = "";
	
	//echo("DEBUG SetStuffString: NORMALIZED result='" @ %final @ "'");
	return %final;
}

function GetStuffStringCount(%stuff, %item)
{
	dbecho($dbechoMode, "GetStuffStringCount(" @ %stuff @ ", " @ %item @ ")");

	%stuff = FixStuffString(%stuff);

	%pos = String::findSubStr(%stuff, " " @ %item @ " ");

	if(%pos != -1)
	{
		%a = String::NEWgetSubStr(%stuff, %pos+1, 99999);
		%amt = GetWord(%a, 1);

		return %amt;
	}

	return 0;
}

function FixStuffString(%stuff)
{
	dbecho($dbechoMode, "FixStuffString(" @ %stuff @ ")");

	%nstuff = " ";
	for(%i = 0; GetWord(%stuff, %i) != -1; %i++)
	{
		%w = GetWord(%stuff, %i);
		%nstuff = %nstuff @ %w @ " ";
	}

	return %nstuff;
}

function IsStuffStringEquiv(%s1, %s2, %dblCheck)
{
	dbecho($dbechoMode, "IsStuffStringEquiv(" @ %s1 @ ", " @ %s2 @ ", " @ %dblCheck @ ")");

	//this function COULD be laggy, it all depends on how many items are in %s1.  Below 5, IMO, should be just fine

	%s1 = " " @ %s1;
	%s2 = " " @ %s2;
	for(%x = 0; (%w = GetWord(%s1, %x)) != -1; %x+=2)
	{
		%w2 = GetWord(%s1, %x+1);

		if(String::findSubStr(%s2, " " @ %w @ " " @ %w2) == -1)
			return False;
	}
	if(%x == 0)			//do a dblCheck if %s1 is null.
		%dblCheck = True;

	if(%dblCheck)
	{
		//This will slow down the function, but will get a more accurate reading.
		//If you do NOT do a dblCheck, then %s2 could contain additional items that %s1 does not contain, and still
		//return True.  If this is not a concern, then you don't have to do a dblCheck
		for(%x = 0; (%w = GetWord(%s2, %x)) != -1; %x+=2)
		{
			%w2 = GetWord(%s2, %x+1);
	
			if(String::findSubStr(%s1, " " @ %w @ " " @ %w2) == -1)
				return False;
		}
	}

	return True;
}

//$tst = "I am typing a whole bunch of bullshit on this screen so I can fix this stupid bug concerning the storage. The string::getsubstr function can only get two-hundred fifty five (255) characters from a string, so whenever this function was performed on the storage stuff string, alot of info would get lost. Players were actually capable of spawning items that aren't normally supposed to be spawned, like the Deployable Base for example. This is a big problem, but with this NEWgetSubStr function that I wrote, which splits up strings into chunks of 255 in order to get the string portion properly, the storage bug should go away and there should be a hell of a lot less cheating.";
function String::NEWgetSubStr(%s, %x, %y)
{
	dbecho($dbechoMode, "String::NEWgetSubStr(" @ %s @ ", " @ %x @ ", " @ %y @ ")");

	// Validate input parameters
	if(%s == "" || %y == "")
		return "";

	%len = %y;
	%chunks = floor(%len / 255) + 1;

	%q = %len;
	%nx = %x;
	%final = "";

	for(%i = 1; %i <= %chunks; %i++)
	{
		%q = %q - 255;
		if(%q <= 0)
			%chunkLen = %q+255;
		else
			%chunkLen = 255;

		%final = %final @ String::getSubStr(%s, %nx, %chunkLen);
		%nx = %nx + %chunkLen;
	}

	return %final;
}

function GetRoll(%roll, %optionalMinMax)
{
	dbecho($dbechoMode, "GetRoll(" @ %roll @ ", " @ %optionalMinMax @ ")");

	//this function accepts the following syntax, where N is any positive number NOT containing a +:
	//NdN
	//NdN+N
	//NdN-N
	//NdNxN
	//NdN+NxN
	//NdN-NxN

	%d = String::findSubStr(%roll, "d");
	%p = String::findSubStr(%roll, "+");
	if(%p == -1)
		%m = String::findSubStr(%roll, "-");
	%x = String::findSubStr(%roll, "x");

	if(%d == -1)
		return %roll;

	if(%x == -1)
		%x = String::len(%roll);

	%numDice = floor(String::getSubStr(%roll, 0, %d));
	if(%p != -1)
	{
		%diceFaces = String::getSubStr(%roll, %d+1, %p-%d-1);
		%bonus = String::getSubStr(%roll, %p+1, %x-1);
	}
	else if(%p == -1 && %m != -1)
	{
		%diceFaces = String::getSubStr(%roll, %d+1, %m-%d-1);
		%bonus = -String::getSubStr(%roll, %m+1, %x-1);
	}
	else
		%diceFaces = String::getSubStr(%roll, %d+1, 99999);

	%total = 0;
	for(%i = 1; %i <= %numDice; %i++)
	{
		if(%optionalMinMax == "min")
			%r = 1;
		else if(%optionalMinMax == "max")
			%r = %diceFaces;
		else
			%r = floor(getRandom() * %diceFaces)+1;

		%total += %r;
	}

	if(%bonus != "")
		%total += %bonus;

	if(%x != String::len(%roll))
		%total *= String::getSubStr(%roll, %x+1, 99999);

	return %total;
}

function GetCombo(%n)
{
	dbecho($dbechoMode, "GetCombo(" @ %n @ ")");

	//--- This is used so ComboTables don't get overwritten by simultaneous calls ---
	$w++;
	if($w > 20) $w = 1;
	//-------------------------------------------------------------------------------

	for(%i = 1; $ComboTable[$w, %i] != ""; %i++)
		$ComboTable[$w, %i] = "";

	%cnt = 0;

	while(%i != -1)
	{
		for(%i = 0; pow(2, %i) <= %n; %i++){}
		%i--;

		if(%i >= 0)
		{
			$ComboTable[$w, %cnt++] = pow(2, %i);
			%n -= pow(2, %i);
		}
	}

	return $w;
}

function IsPartOfCombo(%combo, %n)
{
	dbecho($dbechoMode, "IsPartOfCombo(" @ %combo @ ", " @ %n @ ")");

	%w = GetCombo(%combo);

	%flag = false;

	for(%i = 1; $ComboTable[%w, %i] != ""; %i++)
	{
		if(%n == $ComboTable[%w, %i])
			%flag = true;

		//It's a good idea to clean up after oneself, especially with all the ComboTables that would be floating around
		$ComboTable[%w, %i] = "";
	}

	return %flag;
}

function IsDead(%id)
{
	dbecho($dbechoMode, "IsDead(" @ %id @ ")");

	%clientId = Player::getClient(%id);
	%player = Client::getOwnedObject(%clientId);

	if(%player == -1)
		return True;
	else
		return False;
}

function Cap(%n, %lb, %ub)
{
	dbecho($dbechoMode, "Cap(" @ %n @ ", " @ %lb @ ", " @ %ub @ ")");

	if(%lb != "inf")
	{
		if(%n < %lb)
			%n = %lb;
	}

	if(%ub != "inf")
	{
		if(%n > %ub)
			%n = %ub;
	}

	return %n;
}

function GetNESW(%pos1, %pos2)
{
	dbecho($dbechoMode, "GetNESW(" @ %pos1 @ ", " @ %pos2 @ ")");

	%v1 = Vector::sub(%pos1, %pos2);
	%v2 = Vector::getRotation(%v1);
	%a = GetWord(%v2, 2);

	if(%a >= 2.7475 && %a <= 3.15 || %a >= -3.15 && %a <= -2.7475)
		%d = "North";
	else if(%a >= 1.9625 && %a <= 2.7475)
		%d = "North East";
	else if(%a >= 1.1775 && %a <= 1.9625)
		%d = "East";
	else if(%a >= 0.3925 && %a <= 1.1775)
		%d = "South East";
	else if(%a >= -0.3925 && %a <= 0.3925)
		%d = "South";
	else if(%a >= -1.1775 && %a <= -0.3925)
		%d = "South West";
	else if(%a >= -1.9625 && %a <= -1.1775)
		%d = "West";
	else if(%a >= -2.7475 && %a <= -1.9625)
		%d = "North West";

	return %d;
}

function SetOnGround(%clientId, %extraZ)
{
	dbecho($dbechoMode, "SetOnGround(" @ %clientId @ ", " @ %extra2 @ ")");

	%maxdist = 5000;

	%origpos = GameBase::getPosition(%clientId);

	%x = GetWord(%origpos, 0);
	%y = GetWord(%origpos, 1);
	%z = GetWord(%origpos, 2);

	%finalpos = %x @ " " @ %y @ " " @ %z + %extraZ;

	GameBase::setPosition(%clientId, %finalpos);

	%index = 0;
	//for(%i = 0; %i >= -3.15; %i -= 1.57)
	for(%i = 0; %i >= -4.725; %i -= 0.785)
	{
		if(GameBase::getLOSinfo(Client::getOwnedObject(%clientId), %maxdist, %i @ " 0 0"))
		{
			%index++;
			%pos[%index] = $los::position;
		}
	}

	%closest = %maxdist+1;
	for(%j = 1; %j <= %index; %j++)
	{
		%dist = Vector::getDistance(%pos[%j], %finalpos);
		if(%dist < %closest)
		{
			%closest = %dist;
			%closestIndex = %j;
		}
	}

	if(%pos[%closestIndex] != "")
		GameBase::setPosition(%clientId, %pos[%closestIndex]);
	else
		GameBase::setPosition(%clientId, %origpos);

	return %pos[%closestIndex];
}

function WalkSlowInvisLoop(%clientId, %delay, %grace)
{
	dbecho($dbechoMode, "WalkSlowInvisLoop(" @ %clientId @ ", " @ %delay @ ", " @ %grace @ ")");

	%pos = GameBase::getPosition(%clientId);
	if(fetchData(%clientId, "lastPos") == "")
		storeData(%clientId, "lastPos", %pos);

	if(Vector::getDistance(%pos, fetchData(%clientId, "lastPos")) <= %grace && fetchData(%clientId, "invisible"))
	{
		storeData(%clientId, "lastPos", GameBase::getPosition(%clientId));
		schedule("WalkSlowInvisLoop(" @ %clientId @ ", " @ %delay @ ", " @ %grace @ ");", %delay, %clientId);
	}
	else
	{
		if(fetchData(%clientId, "invisible"))
			UnHide(%clientId);

		Client::sendMessage(%clientId, $MsgRed, "You are no longer Hiding In Shadows.");

	}
}
function UnHide(%clientId)
{
	dbecho($dbechoMode, "UnHide(" @ %clientId @ ")");

	if(fetchData(%clientId, "invisible"))
	{
		GameBase::startFadeIn(%clientId);
		storeData(%clientId, "invisible", "");
	}

	storeData(%clientId, "lastPos", "");
	storeData(%clientId, "blockHide", True);
	schedule("storeData(" @ %clientId @ ", \"blockHide\", \"\");", 10);
}

function DisplayGetInfo(%clientId, %id, %obj)
{
	dbecho($dbechoMode, "DisplayGetInfo(" @ %clientId @ ", " @ %id @ ", " @ %obj @ ")");

	if(%clientId.adminLevel >= 1)
		%showid = %id @ " (" @ %obj @ ")";
	else
		%showid = "";

	%houseValue = fetchData(%id, "MyHouse");
	// Treat "0", "House0", and "house0" as empty (no house) - new players might have these invalid values
	if(%houseValue == "0" || %houseValue == "House0" || %houseValue == "house0")
		%houseValue = "";
	// CRITICAL: If houseValue is still not empty, verify it's a valid house name
	if(%houseValue != "")
	{
		%houseNum = GetHouseNumber(%houseValue);
		// If GetHouseNumber returns empty, it's not a valid house - clear it
		if(%houseNum == "" || %houseNum == 0 || %houseNum == "0")
		{
			echo("DEBUG: DisplayGetInfo - Invalid house name '" @ %houseValue @ "' detected, clearing");
			%houseValue = "";
			storeData(%id, "MyHouse", "");
		}
	}
	if(%houseValue != "")
		%house = "*** Proud member of <f2>" @ %houseValue @ "<f0>";
	else
		%house = "";

	%msg = "<jc><f1>" @ Client::getName(%id) @ ", LEVEL " @ fetchData(%id, "LVL") @ " " @ getFinalCLASS(%id) @ " REMORT " @ fetchData(%id, "RemortStep") @ "<f0> " @ " " @ %showid @ "\n" @ %house @ "\nWorld Rank: " @ $WorldRank[fetchData(%id, "TournyRank")] @ "\nBounty: " @ fetchData(%id, "bounty") @ "\n" @ fetchData(%id, "PlayerInfo");
	if(fetchData(%id, "PlayerInfo") == "")
		%msg = %msg @ "A mere citizen of the Kingdom.";

	// Use persistentCenterprint to prevent message from being overwritten by bottomprint (e.g., during combat)
	persistentCenterprint(%clientId, %msg, 5);
}

function DisplayGetStats(%clientId, %id, %obj)
{
	dbecho($dbechoMode, "DisplayGetStats(" @ %clientId @ ", " @ %id @ ", " @ %obj @ ")");

	if(%clientId.adminLevel >= 1)
		%showid = %id @ " (" @ %obj @ ")";
	else
		%showid = "";

	%name = Client::getName(%id);
	%def = fetchData(%id, "DEF");
	%mdef = fetchData(%id, "MDEF");
	%atk = fetchData(%id, "ATK");
	%maxHP = fetchData(%id, "MaxHP");
	%hp = fetchData(%id, "HP");
	%maxMANA = fetchData(%id, "MaxMANA");
	%mana = fetchData(%id, "MANA");
	%maxWeight = fetchData(%id, "MaxWeight");
	%weight = fetchData(%id, "Weight");
	%lck = AddPoints(%id, 2);
	%stance = fetchData(%id, "Stance");
	%overweightStep = fetchData(%id, "OverweightStep");

	%msg = "<jc><f1>" @ %name @ " - Combat Stats<f0> " @ %showid;
	%msg = %msg @ "\n<f2>DEF:<f0> " @ %def @ "  <f2>MDEF:<f0> " @ %mdef @ "  <f2>ATK:<f0> " @ %atk;
	%msg = %msg @ "\n<f2>HP:<f0> " @ %hp @ " / " @ %maxHP @ "  <f2>MANA:<f0> " @ %mana @ " / " @ %maxMANA;
	%msg = %msg @ "\n<f2>Weight:<f0> " @ %weight @ " / " @ %maxWeight;
	%msg = %msg @ "\n<f2>LCK:<f0> " @ %lck;
	
	if(%stance != "")
		%msg = %msg @ "  <f2>Stance:<f0> " @ %stance;
	
	if(%overweightStep > 0)
		%msg = %msg @ "\n<f2>Overweight:<f0> " @ %overweightStep @ "%";

	// Use persistentCenterprint to prevent message from being overwritten by bottomprint (e.g., during combat)
	persistentCenterprint(%clientId, %msg, 5);
}

function AddToTargetList(%clientId, %cl)
{
	dbecho($dbechoMode, "AddToTargetList(" @ %clientId @ ", " @ %cl @ ")");

	%name = Client::getName(%cl);
	if(!IsInCommaList(fetchData(%clientId, "targetlist"), %name))
	{
		storeData(%clientId, "targetlist", AddToCommaList(fetchData(%clientId, "targetlist"), %name));

		Client::sendMessage(%cl, $MsgRed, Client::getName(%clientId) @ " wants you dead!  Travel carefully!");
		Client::sendMessage(%clientId, $MsgRed, %name @ " has been notified of your intentions.");

		schedule("RemoveFromTargetList(" @ %clientId @ ", " @ %cl @ ");", 10 * 60);
	}
}
function RemoveFromTargetList(%clientId, %cl)
{
	dbecho($dbechoMode, "RemoveFromTargetList(" @ %clientId @ ", " @ %cl @ ")");

	%name = Client::getName(%cl);
	if(IsInCommaList(fetchData(%clientId, "targetlist"), %name))
	{
		storeData(%clientId, "targetlist", RemoveFromCommaList(fetchData(%clientId, "targetlist"), %name));

		Client::sendMessage(%cl, $MsgBeige, Client::getName(%clientId) @ " was forced to declare a truce.");
		Client::sendMessage(%clientId, $MsgBeige, %name @ " has expired on your target-list.");
	}
}

function WhatIs(%item)
{
	dbecho($dbechoMode, "WhatIs(" @ %item @ ")");

	//--------- GATHER INFO ------------------
	if(%item.description == False)	
		%desc = %item;
	else
		%desc = %item.description;

	%t = GetAccessoryVar(%item, $AccessoryType);
	%w = GetAccessoryVar(%item, $Weight);
	%c = GetItemCost(%item);
	%s = $SkillDesc[$SkillType[%item]];

	if(GetDelay(%item) != "" && GetDelay(%item) != 0)
		%sd = GetDelay(%item);
	else
		%sd = "";

	if($LocationDesc[%t] != "")
		%loc = " - Location: " @ $LocationDesc[%t];
	else
		%loc = "";

	if($AccessoryVar[%item, $MiscInfo] != "")
		%nfo = $AccessoryVar[%item, $MiscInfo];
	else
		%nfo = "There is no further information available.";

	%si = $Spell::index[%item];
	if(%si != "")
	{
		%desc = $Spell::name[%si];
		%nfo = $Spell::description[%si];
		%atkinfo = $Spell::damageValue[%si];
		%sd = $Spell::delay[%si];
		%sr = $Spell::recoveryTime[%si];
		%sm = $Spell::manaCost[%si];
	}

	//--------- BUILD MSG --------------------
	%msg = "";
	%msg = %msg @ "<jc><f1>" @ %desc @ %loc @ "\n";
	%msg = %msg @ "\nBonuses: " @ WhatSpecialVars(%item);
	if(%s != "")
		%msg = %msg @ "\nSkill Type: " @ %s;
	%msg = %msg @ "\nRestrictions: " @ WhatSkills(%item);
	if(%w != "")
		%msg = %msg @ "\nWeight: " @ %w;
	if(%c != "")
		%msg = %msg @ "\nPrice: $" @ %c;
	if(%sd != "")
		%msg = %msg @ "\nDelay: " @ %sd @ " sec";
	if(%sr != "")
		%msg = %msg @ "\nRecovery: " @ %sr @ " sec";
	if(%sm != "")
		%msg = %msg @ "\nMana: " @ %sm;

	%msg = %msg @ "\n\n<f0>" @ %nfo;

	return %msg;
}

function FixDecimals(%c)
{
	dbecho($dbechoMode, "FixDecimals(" @ %c @ ")");

	%d = round(%c * 10);
	%m = (%d / 10) * 1.000001;

	return %m;
}

function AddToCommaList(%list, %item)
{
	dbecho($dbechoMode, "AddToCommaList(" @ %list @ ", " @ %item @ ")");

	%list = %list @ %item @ $sepchar;

	return %list;
}
function RemoveFromCommaList(%list, %item)
{
	dbecho($dbechoMode, "RemoveFromCommaList(" @ %list @ ", " @ %item @ ")");

	%a = $sepchar @ %list;
	%a = String::replace(%a, $sepchar @ %item @ $sepchar, ",");
	%list = String::NEWgetSubStr(%a, 1, 99999);

	return %list;
}
function IsInCommaList(%list, %item)
{
	dbecho($dbechoMode, "IsInCommaList(" @ %list @ ", " @ %item @ ")");

	%a = $sepchar @ %list;
	if(String::findSubStr(%a, "," @ %item @ ",") != -1)
		return True;
	else
		return False;
}
function CountObjInCommaList(%list)
{
	dbecho($dbechoMode, "CountObjInCommaList(" @ %list @ ")");

	%cnt = 0;
	for(%i = String::findSubStr(%list, ","); (%p = String::findSubStr(%list, ",")) != -1; %list = String::NEWgetSubStr(%list, %p+1, 99999))
		%cnt++;
	return %cnt;
}

function CountObjInList(%list)
{
	dbecho($dbechoMode, "CountObjInList(" @ %list @ ")");

	for(%i = 0; GetWord(%list, %i) != -1; %i++){}

	return %i;
}

function AddBounty(%clientId, %amt)
{
	dbecho($dbechoMode, "AddBounty(" @ %clientId @ ", " @ %amt @ ")");

	%b = fetchData(%clientId, "bounty") + %amt;
	storeData(%clientId, "bounty", Cap(%b, 0, 100000000));

	return fetchData(%clientId, "bounty");
}

// TEMPORARILY DISABLED - PostSteal function
//function PostSteal(%clientId, %success, %type, %targetId)
//{
//	dbecho($dbechoMode, "PostSteal(" @ %clientId @ ", " @ %success @ ", " @ %type @ ")");
//
//	if(%type == 0)
//	{
//		//regular steal
//		if(%success)
//			AddBounty(%clientId, (5.5 * fetchData(%targetId, "LVL")) * (fetchData(%targetId, "RemortStep") + 1));
//		else
//			AddBounty(%clientId, (5.5 * fetchData(%targetId, "LVL")) * (fetchData(%targetId, "RemortStep") + 1));
//	}
//	else if(%type == 1)
//	{
//		//pickpocket
//		if(%success)
//			AddBounty(%clientId, (10 * fetchData(%targetId, "LVL")) * (fetchData(%targetId, "RemortStep") + 1));
//		else
//			AddBounty(%clientId, (10.5 * fetchData(%targetId, "LVL")) * (fetchData(%targetId, "RemortStep") + 1));
//	}
//	else if(%type == 2)
//	{
//		//mug
//		if(%success)
//			AddBounty(%clientId, (15.5 * fetchData(%targetId, "LVL")) * (fetchData(%targetId, "RemortStep") + 1));
//		else
//			AddBounty(%clientId, (15.5 * fetchData(%targetId, "LVL")) * (fetchData(%targetId, "RemortStep") + 1));
//	}
//
//	if(%success)
//		UpdateBonusState(%clientId, "Theft 1", 20 / 2);
//	else
//		UpdateBonusState(%clientId, "Theft 1", 120 / 2);
//}

function GetTypicalTossStrength(%clientId)
{
	dbecho($dbechoMode, "GetTypicalTossStrength(" @ %clientId @ ")");

	if(fetchData(%clientId, "RACE") == "DeathKnight")
	{
		%toss = 10;
	}
	else
	{
		%a = Player::getArmor(%clientId);
		%b = String::getSubStr(%a, String::len(%a)-1, 1);
		%toss = Cap($speed[fetchData(%clientId, "RACE"), %b]-2, 3, 10);
	}

	return %toss;
}

// TEMPORARILY DISABLED - AllowedToSteal function
//function AllowedToSteal(%clientId)
//{
//	dbecho($dbechoMode, "AllowedToSteal(" @ %clientId @ ")");
//
//	if(fetchData(%clientId, "InSleepZone") != "")
//		return "You can't steal inside a sleeping area.";
//	//else if(Zone::getType(fetchData(%clientId, "zone")) == "PROTECTED")
//	//	return "You can't steal from someone in protected territory.";
//
//	return "True";
//}

// TEMPORARILY DISABLED - PerhapsPlayStealSound function
//function PerhapsPlayStealSound(%clientId, %type)
//{
//	dbecho($dbechoMode, "PerhapsPlayStealSound(" @ %clientId @ ", " @ %type @ ")");
//
//	if(%type == 0)
//		%snd = SoundMoney1;
//	else if(%type == 1)
//		%snd = SoundPickupItem;
//	else if(%type == 2)
//		%snd = SoundPickupItem;
//
//	%r = getRandom() * 1000;
//	%n = 1000 - $PlayerSkill[%clientId, $SkillStealing];
//	if(%r <= %n)
//	{
//		playSound(%snd, GameBase::getPosition(%clientId));
//		return True;
//	}
//	else
//		return False;
//}

function GetLCKcost(%clientId)
{
	dbecho($dbechoMode, "GetLCKcost(" @ %clientId @ ")");

	%a = floor( pow(2, Cap(fetchData(%clientId, "LCK"), 0, 26)) * 15 ) + 100;

	return Cap(%a, 0, "inf");
}
function Getrpcost(%clientId)
{
	dbecho($dbechoMode, "Getrpcost(" @ %clientId @ ")");

	%a = floor( pow(2, Cap(fetchData(%clientId, "RankPoints"), 0, 26)) * 7 ) + 100;

	return Cap(%a, 0, "inf");
}

function GetEventCommandIndex(%object, %type)
{
	dbecho($dbechoMode, "GetEventCommandIndex(" @ %object @ ", " @ %type @ ")");

	%list = "";

	//5 event commands max. per object
	for(%i = 1; %i <= $maxEvents; %i++)
	{
		// Use temp variable to safely check if EventCommand exists before accessing
		%tempCmd = $EventCommand[%object, %i];
		if(%tempCmd != "")
		{
			%t = GetWord(%tempCmd, 1);
			if(String::ICompare(%t, %type) == 0)
				%list = %list @ %i @ " ";
		}
	}

	if(%list != "")
		return String::getSubStr(%list, 0, String::len(%list)-1);
	else
		return -1;
}

function AddEventCommand(%object, %senderName, %type, %cmd)
{
	dbecho($dbechoMode, "AddEventCommand(" @ %object @ ", " @ %senderName @ ", " @ %type @ ", " @ %cmd @ ")");

	for(%i = 1; %i <= $maxEvents; %i++)
	{
		if($EventCommand[%object, %i] == "" || String::ICompare(GetWord($EventCommand[%object, %i], 1), %type) == 0)
		{
			$EventCommand[%object, %i] = %senderName @ " " @ %type @ " " @ %cmd;
			return %i;
		}
	}
	return -1;
}

function ClearEvents(%id)
{
	dbecho($dbechoMode, "ClearEvents(" @ %id @ ")");

	for(%i = 1; %i <= $maxEvents; %i++)
	{
		$EventCommand[%id, %i] = "";
		if(%id.tag != False)
			$EventCommand[%id.tag, %i] = "";
	}
}

function msprintf(%in, %a1, %a2, %a3, %a4, %a5, %a6, %a7, %a8)
{
	dbecho($dbechoMode, "msprintf(" @ %in @ ", " @ %a1 @ ", " @ %a2 @ ", " @ %a3 @ ", " @ %a4 @ ", " @ %a5 @ ", " @ %a6 @ ", " @ %a7 @ ", " @ %a8 @ ")");

	%final = "";

	%cnt = 0;
	%list = %in;
	for(%p = String::findSubStr(%list, "%"); (%p = String::findSubStr(%list, "%")) != -1; %p = String::findSubStr(%list, "%"))
	{
		%crash++;
		if(%crash > 30)
		{
			echo("FATAL CRASH BUG...contact JeremyIrons and tell him his msprintf is fucking up");
			break;
		}

		%list = String::NEWgetSubStr(%list, %p+1, 99999);
		%cnt = String::getSubStr(%list, 0, 1);

		%check = String::findSubStr(%list, "%");
		if(%check == -1) %check = 99999;
		%endsign = String::findSubStr(%list, ";");

		if(%endsign != -1 && %endsign < %check)
		{
			%ev = String::NEWgetSubStr(%list, 1, %endsign);
			%a[%cnt] = eval("%x = " @ %a[%cnt] @ %ev);

			%in = String::replace(%in, %ev, "");
		}
	}

	return sprintf(%in, %a[1], %a[2], %a[3], %a[4], %a[5], %a[6], %a[7], %a[8]);
}

function nsprintf(%in, %a1, %a2, %a3, %a4, %a5, %a6, %a7, %a8)
{
	dbecho($dbechoMode, "nsprintf(" @ %in @ ", " @ %a1 @ ", " @ %a2 @ ", " @ %a3 @ ", " @ %a4 @ ", " @ %a5 @ ", " @ %a6 @ ", " @ %a7 @ ", " @ %a8 @ ")");

	%list = %in;
	for(%p = String::findSubStr(%list, "%"); (%p = String::findSubStr(%list, "%")) != -1; %p = String::findSubStr(%list, "%"))
	{
		%list = String::NEWgetSubStr(%list, %p+1, 99999);
		%w = String::getSubStr(%list, 0, 1);
		if(!IsInCommaList("1,2,3,4,5,6,7,8,", %w))
			return "Error in syntax";
	}

	return msprintf(%in, %a[1], %a[2], %a[3], %a[4], %a[5], %a[6], %a[7], %a[8]);
}

function UnequipMountedStuff(%clientId)
{
	dbecho($dbechoMode, "UnequipMountedStuff(" @ %clientId @ ")");

	%max = getNumItems();
	for(%i = 0; %i < %max; %i++)
	{
		%a = getItemData(%i);
		%itemcount = Player::getItemCount(%clientId, %a);

		if(%itemcount)
		{
			if(%a.className == "Equipped")
			{
				%b = String::getSubStr(%a, 0, String::len(%a)-1);
				// Remove ALL equipped items, not just one
				Player::decItemCount(%clientId, %a, %itemcount);
				Player::incItemCount(%clientId, %b, %itemcount);
			}
			else if(Player::getMountedItem(%clientId, $WeaponSlot) == %a)
			{
				Player::unMountItem(%clientId, $WeaponSlot);
			}
		}
	}
}

function LTrim(%s)
{
	dbecho($dbechoMode, "LTrim(" @ %s @ ")");

	%a = GetWord(%s, 0);
	%p1 = String::findSubStr(%s, %a);
	%s = String::NEWgetSubStr(%s, %p1, 99999);

	return %s;
}

function InitObjectives()
{
	dbecho($dbechoMode, "InitObjectives()");

	Team::setObjective(0, 1, "<jc><f8>Welcome To The Kingdom of Kronos RPG!");
	Team::setObjective(0, 2, "<jc><f5>Your Host: Jobo");
	Team::setObjective(0, 3, "<f5>PK Rules:");
	Team::setObjective(0, 4, "<f1>1) If any player involved in the PK is less than remort level 5, then the players must be within a 20 level range.");
	Team::setObjective(0, 5, "<f1>2) If all players involved in the PK are remort level 5 or above, there is no level restrictions to PK. By this point the players SHOULD be smart enough to know when to run.");
	Team::setObjective(0, 6, "<f1>3) You are not allowed to PK a single player more than once a day.");
	Team::setObjective(0, 7, "<f1>Anyone caught breaking these rules will be jailed for 10 minutes, this will become more severe if the player continues to break these rules.");
	Team::setObjective(0, 9, "<jc><f4>If you have suggestions on how to improve the server, message Jobo.");
	Team::setObjective(0, 10, "<f2>-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
	Team::setObjective(0, 11, "<f2>For a list of spells use #offensivespells #neutralspells #defensivespells.");
	Team::setobjective(0, 12, "<f2>Weapons and armor lists: #slash, #pierce, #bludge, #armor and #defense");
	Team::setobjective(0, 13, "<f8>If you need to contact me my Discord is: Joblantski");
	Team::setobjective(0, 14, "<f5>Credits: Asnabel for making the mod, Superfat for continuing it, Panda, Scorpion, Xan, DeraJ.");
	Team::setobjective(0, 15, "<f5>Xan(Serene, Dog, RPGDog,) Has contributed to this mod in extraordinary ways. Thank you Dog.");
	Team::setobjective(0, 16, "<f2>-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
	Team::setobjective(0, 17, "<f5>Bases / Artifacts / Members Online:");
	Team::setobjective(0, 18, "<f1>  House Yuliple: " @ $BaseControl[HouseYuliple] @ " bases, " @ $FlagCommand[HouseYuliple] @ " artifacts, " @ $HouseMember[HouseYuliple] @ " members online");
	Team::setobjective(0, 19, "<f1>  House Curama: " @ $BaseControl[HouseCurama] @ " bases, " @ $FlagCommand[HouseCurama] @ " artifacts, " @ $HouseMember[HouseCurama] @ " members online");
	Team::setobjective(0, 20, "<f1>  House Arbal: " @ $BaseControl[HouseArbal] @ " bases, " @ $FlagCommand[HouseArbal] @ " artifacts, " @ $HouseMember[HouseArbal] @ " members online");
	Team::setobjective(0, 21, "<f1>  House Kronos: " @ $BaseControl[HouseKronos] @ " bases, " @ $FlagCommand[HouseKronos] @ " artifacts, " @ $HouseMember[HouseKronos] @ " members online");

	for(%i = 1; %i < getNumTeams(); %i++)
	{
		Team::setObjective(%i, 1, "<f7><jc>KILL ALL HUMAN PLAYERS");
		Team::setObjective(%i, 2, "<f7><jc>KILL ALL HUMAN PLAYERS");
		Team::setObjective(%i, 3, "<f7><jc>KILL ALL HUMAN PLAYERS");
		Team::setObjective(%i, 4, "<f7><jc>KILL ALL HUMAN PLAYERS");
		Team::setObjective(%i, 5, "<f7><jc>KILL ALL HUMAN PLAYERS");
		Team::setObjective(%i, 6, "<f7><jc>KILL ALL HUMAN PLAYERS");
		Team::setObjective(%i, 7, "<f7><jc>KILL ALL HUMAN PLAYERS");
		Team::setObjective(%i, 8, "<f7><jc>KILL ALL HUMAN PLAYERS");
		Team::setObjective(%i, 9, "<f7><jc>KILL ALL HUMAN PLAYERS");
		Team::setObjective(%i, 10, "<f7><jc>KILL ALL HUMAN PLAYERS");
		Team::setObjective(%i, 11, "<f7><jc>KILL ALL HUMAN PLAYERS");
	}
	
	// Start recursive refresh of objectives screen every 60 seconds
	RecursiveObjectivesRefresh();
}

function UpdateHouseObjectivesDisplay()
{
	dbecho($dbechoMode, "UpdateHouseObjectivesDisplay()");
	
	// Clamp BaseControl and FlagCommand to prevent negative values
	// This fixes the bug where negative base counts cause negative house bonuses
	for(%i = 0; %i <= 3; %i++)
	{
		%houseNames[0] = "HouseYuliple";
		%houseNames[1] = "HouseCurama";
		%houseNames[2] = "HouseArbal";
		%houseNames[3] = "HouseKronos";
		
		%house = %houseNames[%i];
		if($BaseControl[%house] < 0)
			$BaseControl[%house] = 0;
		if($FlagCommand[%house] < 0)
			$FlagCommand[%house] = 0;
		if($HouseMember[%house] < 0)
			$HouseMember[%house] = 0;
	}
	
	// Update the house objectives display with current BaseControl, FlagCommand, and HouseMember values
	// Update only the house data lines (slots 18-21) - header at slot 17 stays the same
	Team::setobjective(0, 18, "<f1>  House Yuliple: " @ $BaseControl[HouseYuliple] @ " bases, " @ $FlagCommand[HouseYuliple] @ " artifacts, " @ $HouseMember[HouseYuliple] @ " members online");
	Team::setobjective(0, 19, "<f1>  House Curama: " @ $BaseControl[HouseCurama] @ " bases, " @ $FlagCommand[HouseCurama] @ " artifacts, " @ $HouseMember[HouseCurama] @ " members online");
	Team::setobjective(0, 20, "<f1>  House Arbal: " @ $BaseControl[HouseArbal] @ " bases, " @ $FlagCommand[HouseArbal] @ " artifacts, " @ $HouseMember[HouseArbal] @ " members online");
	Team::setobjective(0, 21, "<f1>  House Kronos: " @ $BaseControl[HouseKronos] @ " bases, " @ $FlagCommand[HouseKronos] @ " artifacts, " @ $HouseMember[HouseKronos] @ " members online");
}

function RecursiveObjectivesRefresh()
{
	dbecho($dbechoMode, "RecursiveObjectivesRefresh()");
	
	// Recalculate house objectives from actual game state to ensure accuracy
	RecalcHouseObjectives();
	
	// Schedule next refresh in 60 seconds
	schedule("RecursiveObjectivesRefresh();", 60);
}

function SaveHouseObjectives()
{
	// Save house objective captures to separate file
	File::delete("temp\\HouseObjectives.cs");
	
	// Save base control (towerswitch captures) for each house
	// Export might have issues with array syntax, so save to temp variables first
	%baseKronos = $BaseControl[HouseKronos];
	%baseArbal = $BaseControl[HouseArbal];
	%baseCurama = $BaseControl[HouseCurama];
	%baseYuliple = $BaseControl[HouseYuliple];
	
	%flagKronos = $FlagCommand[HouseKronos];
	%flagArbal = $FlagCommand[HouseArbal];
	%flagCurama = $FlagCommand[HouseCurama];
	%flagYuliple = $FlagCommand[HouseYuliple];
	
	// Export as simple variables (no array syntax)
	export("baseKronos", "temp\\HouseObjectives.cs", false);
	export("baseArbal", "temp\\HouseObjectives.cs", true);
	export("baseCurama", "temp\\HouseObjectives.cs", true);
	export("baseYuliple", "temp\\HouseObjectives.cs", true);
	export("flagKronos", "temp\\HouseObjectives.cs", true);
	export("flagArbal", "temp\\HouseObjectives.cs", true);
	export("flagCurama", "temp\\HouseObjectives.cs", true);
	export("flagYuliple", "temp\\HouseObjectives.cs", true);
	
	// Save flag positions and team ownership
	// Flags are direct children of MissionGroup, TowerSwitches are inside Tower0-Tower3 SimGroups
	%tempSet = nameToID("MissionGroup");
	%flagCount = 0;
	
	for(%i = 0; %i < Group::objectCount(%tempSet); %i++)
	{
		%obj = Group::getObject(%tempSet, %i);
		%dataName = GameBase::getDataName(%obj);
		
		if(%dataName == "flag")
		{
			// Found a flag - save its data
			%objName = %obj.objectiveName;
			%pos = GameBase::getPosition(%obj);
			
			// Use holdingTeam property to get which house holds this flag
			// (all players are on team 0, so GameBase::getTeam() won't tell us the house)
			%holdingTeam = %obj.holdingTeam;
			if(%holdingTeam == "" || %holdingTeam == -1)
				%holdingTeam = "None";
			
			// Store the data for export using numeric index
			$SavedFlag[%flagCount, "name"] = %objName;
			$SavedFlag[%flagCount, "position"] = %pos;
			$SavedFlag[%flagCount, "holdingTeam"] = %holdingTeam;
			
			%flagCount++;
		}
	}
	
	// Save Tower SimGroup teams (Tower0 through Tower3)
	// TowerSwitches are inside these SimGroups, not direct children of MissionGroup
	%switchCount = 0;
	for(%t = 0; %t <= 3; %t++)
	{
		%towerGroup = nameToID("MissionGroup/Tower" @ %t);
		if(%towerGroup != -1)
		{
			// Find the TowerSwitch in this group to get the team and objectiveName
			for(%j = 0; %j < Group::objectCount(%towerGroup); %j++)
			{
				%obj = Group::getObject(%towerGroup, %j);
				%dataName = GameBase::getDataName(%obj);
				if(%dataName == "TowerSwitch")
				{
					%objName = %obj.objectiveName;
					
					// Use .team property to get which house controls this tower
					// (all players are on team 0, so GameBase::getTeam() won't tell us the house)
					%houseTeam = %obj.team;
					if(%houseTeam == "" || %houseTeam == -1)
						%houseTeam = "None";
					
					// Save to both Tower array (for bulk team setting) and Switch array (for individual restoration)
					$SavedTower[%t, "houseTeam"] = %houseTeam;
					$SavedSwitch[%switchCount, "name"] = %objName;
					$SavedSwitch[%switchCount, "houseTeam"] = %houseTeam;
					
					%switchCount++;
					break;
				}
			}
		}
	}
	
	if(%flagCount > 0)
		export("SavedFlag*", "temp\\HouseObjectives.cs", true);
	if(%switchCount > 0)
		export("SavedSwitch*", "temp\\HouseObjectives.cs", true);
	export("SavedTower*", "temp\\HouseObjectives.cs", true);
	
	echo("Saved " @ %flagCount @ " flag positions and " @ %switchCount @ " towerswitch teams.");
}

function LoadHouseObjectives()
{
	// Load house data from save file (includes BaseControl, FlagCommand, and HouseMember)
	HouseData::Load();
	
	// Restore house objective captures from file
	exec("HouseObjectives.cs");
	
	// Restore BaseControl and FlagCommand from temp variables (if they exist)
	if(%baseKronos != "")
		$BaseControl[HouseKronos] = %baseKronos;
	if(%baseArbal != "")
		$BaseControl[HouseArbal] = %baseArbal;
	if(%baseCurama != "")
		$BaseControl[HouseCurama] = %baseCurama;
	if(%baseYuliple != "")
		$BaseControl[HouseYuliple] = %baseYuliple;
	
	if(%flagKronos != "")
		$FlagCommand[HouseKronos] = %flagKronos;
	if(%flagArbal != "")
		$FlagCommand[HouseArbal] = %flagArbal;
	if(%flagCurama != "")
		$FlagCommand[HouseCurama] = %flagCurama;
	if(%flagYuliple != "")
		$FlagCommand[HouseYuliple] = %flagYuliple;
	
	// Restore flag positions and team ownership using numeric indices
	%tempSet = nameToID("MissionGroup");
	if(%tempSet == -1)
	{
		echo("ERROR LoadHouseObjectives: MissionGroup not found!");
		return;
	}
	
	%flagsRestored = 0;
	%switchesRestored = 0;
	
	// Restore flags by matching objectiveName with saved data
	// Read the exported variables directly (export converts arrays to underscore format)
	for(%savedIdx = 0; %savedIdx < 10; %savedIdx++)
	{
		// Read exported format: $SavedFlag0_name, $SavedFlag0_holdingTeam, etc.
		%savedName = "";
		%savedPos = "";
		%savedHoldingTeam = "";
		
		if(%savedIdx == 0)
		{
			%savedName = $SavedFlag0_name;
			%savedPos = $SavedFlag0_position;
			%savedHoldingTeam = $SavedFlag0_holdingTeam;
		}
		else if(%savedIdx == 1)
		{
			%savedName = $SavedFlag1_name;
			%savedPos = $SavedFlag1_position;
			%savedHoldingTeam = $SavedFlag1_holdingTeam;
		}
		else if(%savedIdx == 2)
		{
			%savedName = $SavedFlag2_name;
			%savedPos = $SavedFlag2_position;
			%savedHoldingTeam = $SavedFlag2_holdingTeam;
		}
		else if(%savedIdx == 3)
		{
			%savedName = $SavedFlag3_name;
			%savedPos = $SavedFlag3_position;
			%savedHoldingTeam = $SavedFlag3_holdingTeam;
		}
		else if(%savedIdx == 4)
		{
			%savedName = $SavedFlag4_name;
			%savedPos = $SavedFlag4_position;
			%savedHoldingTeam = $SavedFlag4_holdingTeam;
		}
		else if(%savedIdx == 5)
		{
			%savedName = $SavedFlag5_name;
			%savedPos = $SavedFlag5_position;
			%savedHoldingTeam = $SavedFlag5_holdingTeam;
		}
		else if(%savedIdx == 6)
		{
			%savedName = $SavedFlag6_name;
			%savedPos = $SavedFlag6_position;
			%savedHoldingTeam = $SavedFlag6_holdingTeam;
		}
		else if(%savedIdx == 7)
		{
			%savedName = $SavedFlag7_name;
			%savedPos = $SavedFlag7_position;
			%savedHoldingTeam = $SavedFlag7_holdingTeam;
		}
		else if(%savedIdx == 8)
		{
			%savedName = $SavedFlag8_name;
			%savedPos = $SavedFlag8_position;
			%savedHoldingTeam = $SavedFlag8_holdingTeam;
		}
		else if(%savedIdx == 9)
		{
			%savedName = $SavedFlag9_name;
			%savedPos = $SavedFlag9_position;
			%savedHoldingTeam = $SavedFlag9_holdingTeam;
		}
		
		if(%savedName == "")
			break;
		
		if(%savedHoldingTeam == "" || %savedHoldingTeam == -1)
			%savedHoldingTeam = "None";
		
		// Find this flag in MissionGroup
		for(%i = 0; %i < Group::objectCount(%tempSet); %i++)
		{
			%obj = Group::getObject(%tempSet, %i);
			if(GameBase::getDataName(%obj) == "flag" && %obj.objectiveName == %savedName)
			{
				// Restore position
				GameBase::setPosition(%obj, %savedPos);
				
				// Restore which house holds this flag
				if(%savedHoldingTeam != "None" && %savedHoldingTeam != "")
				{
					%obj.holdingTeam = %savedHoldingTeam;
					%obj.team = %savedHoldingTeam;
					
					// Find a flagstand for this house and link the flag to it
					%flagstandFound = false;
					for(%j = 0; %j < Group::objectCount(%tempSet); %j++)
					{
						%standObj = Group::getObject(%tempSet, %j);
						if(GameBase::getDataName(%standObj) == "FlagStand" && %standObj.team == %savedHoldingTeam && %standObj.flag == "")
						{
							// Link flag to flagstand
							%obj.flagStand = %standObj;
							%standObj.flag = %obj;
							%flagstandFound = true;
							break;
						}
					}
					
					// Flags at flagstands should have GameBase::setTeam set to 0
					GameBase::setTeam(%obj, 0);
				}
				else
				{
					%obj.holdingTeam = -1;
					%obj.team = -1;
					%obj.flagStand = "";
					
					// Neutral flags MUST have GameBase::setTeam set to -1 so they can be captured
					GameBase::setTeam(%obj, -1);
				}
				
				echo("Restored flag '" @ %savedName @ "' to position " @ %savedPos @ " held by " @ %savedHoldingTeam);
				%flagsRestored++;
				break;
			}
		}
	}
	
	// Restore Tower SimGroup teams (Tower0 through Tower3)
	// Read the exported variables directly (export converts arrays to underscore format)
	for(%t = 0; %t <= 3; %t++)
	{
		%houseTeam = "";
		%switchName = "";
		
		// Read exported format: $SavedTower0_houseTeam, $SavedSwitch0_name, etc.
		if(%t == 0)
		{
			%houseTeam = $SavedTower0_houseTeam;
			%switchName = $SavedSwitch0_name;
		}
		else if(%t == 1)
		{
			%houseTeam = $SavedTower1_houseTeam;
			%switchName = $SavedSwitch1_name;
		}
		else if(%t == 2)
		{
			%houseTeam = $SavedTower2_houseTeam;
			%switchName = $SavedSwitch2_name;
		}
		else if(%t == 3)
		{
			%houseTeam = $SavedTower3_houseTeam;
			%switchName = $SavedSwitch3_name;
		}
		
		// Always try to restore, even if it's "None" or empty
		%towerGroup = nameToID("MissionGroup/Tower" @ %t);
		if(%towerGroup != -1)
		{
			if(%houseTeam == "" || %houseTeam == -1)
				%houseTeam = "None";
			
			// Set team for all objects in the tower group to 0 (all players are on team 0)
			// But set the .team property on TowerSwitch to the house name
			for(%j = 0; %j < Group::objectCount(%towerGroup); %j++)
			{
				%obj = Group::getObject(%towerGroup, %j);
				GameBase::setTeam(%obj, 0);
				
				// If it's a TowerSwitch, also restore the .team property (house name)
				if(GameBase::getDataName(%obj) == "TowerSwitch")
				{
					if(%houseTeam != "None" && %houseTeam != "")
						%obj.team = %houseTeam;
					else
						%obj.team = "";
				}
			}
			%switchesRestored++;
		}
		else
		{
			echo("WARNING: Tower" @ %t @ " group not found in MissionGroup!");
		}
	}
	
	echo("Restored " @ %flagsRestored @ " flags and " @ %switchesRestored @ " towerswitches.");
	
	// Recalculate house member counts from all currently connected players
	// This ensures the counts match the actual connected players, not just saved values
	RecalcHouseMemberCounts();
	
	// Update the objectives display with the loaded/recalculated values
	// This refreshes the screen that was initialized in InitObjectives() before LoadHouseObjectives() ran
	UpdateHouseObjectivesDisplay();
}

// Recalculate house member counts from all currently connected players
function RecalcHouseMemberCounts()
{
	dbecho($dbechoMode, "RecalcHouseMemberCounts()");
	
	// Reset all house member counts
	$HouseMember[HouseKronos] = 0;
	$HouseMember[HouseArbal] = 0;
	$HouseMember[HouseCurama] = 0;
	$HouseMember[HouseYuliple] = 0;
	
	// Count members from all currently connected clients
	%numClients = getNumClients();
	for(%i = 0; %i < %numClients; %i++)
	{
		%clientId = getClientByIndex(%i);
		if(%clientId != -1 && Client::getOwnedObject(%clientId) != -1)
		{
			%house = fetchData(%clientId, "MyHouse");
			if(%house != "")
			{
				$HouseMember[%house]++;
			}
		}
	}
}

function RecalcHouseObjectives()
{
	dbecho($dbechoMode, "RecalcHouseObjectives()");
	
	%tempSet = nameToID("MissionGroup");
	if(%tempSet == -1)
	{
		echo("ERROR RecalcHouseObjectives: MissionGroup not found!");
		return;
	}
	
	// Recalculate $BaseControl and $FlagCommand from actual flag/tower states
	// This ensures they match the actual game state, not just saved values
	// Reset all counts first
	$BaseControl[HouseKronos] = 0;
	$BaseControl[HouseArbal] = 0;
	$BaseControl[HouseCurama] = 0;
	$BaseControl[HouseYuliple] = 0;
	
	$FlagCommand[HouseKronos] = 0;
	$FlagCommand[HouseArbal] = 0;
	$FlagCommand[HouseCurama] = 0;
	$FlagCommand[HouseYuliple] = 0;
	
	// Count flags held by each house
	for(%i = 0; %i < Group::objectCount(%tempSet); %i++)
	{
		%obj = Group::getObject(%tempSet, %i);
		if(GameBase::getDataName(%obj) == "flag")
		{
			%holdingTeam = %obj.holdingTeam;
			if(%holdingTeam != "" && %holdingTeam != -1 && %holdingTeam != "None")
				$FlagCommand[%holdingTeam]++;
		}
	}
	
	// Count towers controlled by each house
	for(%t = 0; %t <= 3; %t++)
	{
		%towerGroup = nameToID("MissionGroup/Tower" @ %t);
		if(%towerGroup != -1)
		{
			for(%j = 0; %j < Group::objectCount(%towerGroup); %j++)
			{
				%obj = Group::getObject(%towerGroup, %j);
				if(GameBase::getDataName(%obj) == "TowerSwitch")
				{
					%houseTeam = %obj.team;
					if(%houseTeam != "" && %houseTeam != -1 && %houseTeam != "None")
						$BaseControl[%houseTeam]++;
					break;
				}
			}
		}
	}
	
	// Recalculate house member counts from all currently connected players
	RecalcHouseMemberCounts();
	
	// Update the objectives display with the recalculated values
	UpdateHouseObjectivesDisplay();
	
	// Silenced debug output - BaseControl, FlagCommand, and HouseMember values
	// echo("BaseControl: Kronos=" @ $BaseControl[HouseKronos] @ ", Arbal=" @ $BaseControl[HouseArbal] @ ", Curama=" @ $BaseControl[HouseCurama] @ ", Yuliple=" @ $BaseControl[HouseYuliple]);
	// echo("FlagCommand: Kronos=" @ $FlagCommand[HouseKronos] @ ", Arbal=" @ $FlagCommand[HouseArbal] @ ", Curama=" @ $FlagCommand[HouseCurama] @ ", Yuliple=" @ $FlagCommand[HouseYuliple]);
	// echo("HouseMember: Kronos=" @ $HouseMember[HouseKronos] @ ", Arbal=" @ $HouseMember[HouseArbal] @ ", Curama=" @ $HouseMember[HouseCurama] @ ", Yuliple=" @ $HouseMember[HouseYuliple]);
}

function LoadHouseObjectives()
{
	// Load house data from save file (includes BaseControl, FlagCommand, and HouseMember)
	HouseData::Load();
	
	// Restore house objective captures from file
	exec("HouseObjectives.cs");
	
	// Restore BaseControl and FlagCommand from temp variables (if they exist)
	if(%baseKronos != "")
		$BaseControl[HouseKronos] = %baseKronos;
	if(%baseArbal != "")
		$BaseControl[HouseArbal] = %baseArbal;
	if(%baseCurama != "")
		$BaseControl[HouseCurama] = %baseCurama;
	if(%baseYuliple != "")
		$BaseControl[HouseYuliple] = %baseYuliple;
	
	if(%flagKronos != "")
		$FlagCommand[HouseKronos] = %flagKronos;
	if(%flagArbal != "")
		$FlagCommand[HouseArbal] = %flagArbal;
	if(%flagCurama != "")
		$FlagCommand[HouseCurama] = %flagCurama;
	if(%flagYuliple != "")
		$FlagCommand[HouseYuliple] = %flagYuliple;
	
	// Restore flag positions and team ownership using numeric indices
	%tempSet = nameToID("MissionGroup");
	if(%tempSet == -1)
	{
		echo("ERROR LoadHouseObjectives: MissionGroup not found!");
		return;
	}
	
	%flagsRestored = 0;
	%switchesRestored = 0;
	
	// Restore flags by matching objectiveName with saved data
	// Read the exported variables directly (export converts arrays to underscore format)
	for(%savedIdx = 0; %savedIdx < 10; %savedIdx++)
	{
		// Read exported format: $SavedFlag0_name, $SavedFlag0_holdingTeam, etc.
		%savedName = "";
		%savedPos = "";
		%savedHoldingTeam = "";
		
		if(%savedIdx == 0)
		{
			%savedName = $SavedFlag0_name;
			%savedPos = $SavedFlag0_position;
			%savedHoldingTeam = $SavedFlag0_holdingTeam;
		}
		else if(%savedIdx == 1)
		{
			%savedName = $SavedFlag1_name;
			%savedPos = $SavedFlag1_position;
			%savedHoldingTeam = $SavedFlag1_holdingTeam;
		}
		else if(%savedIdx == 2)
		{
			%savedName = $SavedFlag2_name;
			%savedPos = $SavedFlag2_position;
			%savedHoldingTeam = $SavedFlag2_holdingTeam;
		}
		else if(%savedIdx == 3)
		{
			%savedName = $SavedFlag3_name;
			%savedPos = $SavedFlag3_position;
			%savedHoldingTeam = $SavedFlag3_holdingTeam;
		}
		else if(%savedIdx == 4)
		{
			%savedName = $SavedFlag4_name;
			%savedPos = $SavedFlag4_position;
			%savedHoldingTeam = $SavedFlag4_holdingTeam;
		}
		else if(%savedIdx == 5)
		{
			%savedName = $SavedFlag5_name;
			%savedPos = $SavedFlag5_position;
			%savedHoldingTeam = $SavedFlag5_holdingTeam;
		}
		else if(%savedIdx == 6)
		{
			%savedName = $SavedFlag6_name;
			%savedPos = $SavedFlag6_position;
			%savedHoldingTeam = $SavedFlag6_holdingTeam;
		}
		else if(%savedIdx == 7)
		{
			%savedName = $SavedFlag7_name;
			%savedPos = $SavedFlag7_position;
			%savedHoldingTeam = $SavedFlag7_holdingTeam;
		}
		else if(%savedIdx == 8)
		{
			%savedName = $SavedFlag8_name;
			%savedPos = $SavedFlag8_position;
			%savedHoldingTeam = $SavedFlag8_holdingTeam;
		}
		else if(%savedIdx == 9)
		{
			%savedName = $SavedFlag9_name;
			%savedPos = $SavedFlag9_position;
			%savedHoldingTeam = $SavedFlag9_holdingTeam;
		}
		
		if(%savedName == "")
			break;
		
		if(%savedHoldingTeam == "" || %savedHoldingTeam == -1)
			%savedHoldingTeam = "None";
		
		// Find this flag in MissionGroup
		for(%i = 0; %i < Group::objectCount(%tempSet); %i++)
		{
			%obj = Group::getObject(%tempSet, %i);
			if(GameBase::getDataName(%obj) == "flag" && %obj.objectiveName == %savedName)
			{
				// Restore position
				GameBase::setPosition(%obj, %savedPos);
				
				// Restore which house holds this flag
				if(%savedHoldingTeam != "None" && %savedHoldingTeam != "")
				{
					%obj.holdingTeam = %savedHoldingTeam;
					%obj.team = %savedHoldingTeam;
					
					// Find a flagstand for this house and link the flag to it
					%flagstandFound = false;
					for(%j = 0; %j < Group::objectCount(%tempSet); %j++)
					{
						%standObj = Group::getObject(%tempSet, %j);
						if(GameBase::getDataName(%standObj) == "FlagStand" && %standObj.team == %savedHoldingTeam && %standObj.flag == "")
						{
							// Link flag to flagstand
							%obj.flagStand = %standObj;
							%standObj.flag = %obj;
							%flagstandFound = true;
							break;
						}
					}
					
					// Flags at flagstands should have GameBase::setTeam set to 0
					GameBase::setTeam(%obj, 0);
				}
				else
				{
					%obj.holdingTeam = -1;
					%obj.team = -1;
					%obj.flagStand = "";
					
					// Neutral flags MUST have GameBase::setTeam set to -1 so they can be captured
					GameBase::setTeam(%obj, -1);
				}
				
				echo("Restored flag '" @ %savedName @ "' to position " @ %savedPos @ " held by " @ %savedHoldingTeam);
				%flagsRestored++;
				break;
			}
		}
	}
	
	// Restore Tower SimGroup teams (Tower0 through Tower3)
	// Read the exported variables directly (export converts arrays to underscore format)
	for(%t = 0; %t <= 3; %t++)
	{
		%houseTeam = "";
		%switchName = "";
		
		// Read exported format: $SavedTower0_houseTeam, $SavedSwitch0_name, etc.
		if(%t == 0)
		{
			%houseTeam = $SavedTower0_houseTeam;
			%switchName = $SavedSwitch0_name;
		}
		else if(%t == 1)
		{
			%houseTeam = $SavedTower1_houseTeam;
			%switchName = $SavedSwitch1_name;
		}
		else if(%t == 2)
		{
			%houseTeam = $SavedTower2_houseTeam;
			%switchName = $SavedSwitch2_name;
		}
		else if(%t == 3)
		{
			%houseTeam = $SavedTower3_houseTeam;
			%switchName = $SavedSwitch3_name;
		}
		
		// Always try to restore, even if it's "None" or empty
		%towerGroup = nameToID("MissionGroup/Tower" @ %t);
		if(%towerGroup != -1)
		{
			if(%houseTeam == "" || %houseTeam == -1)
				%houseTeam = "None";
			
			// Set team for all objects in the tower group to 0 (all players are on team 0)
			// But set the .team property on TowerSwitch to the house name
			for(%j = 0; %j < Group::objectCount(%towerGroup); %j++)
			{
				%obj = Group::getObject(%towerGroup, %j);
				GameBase::setTeam(%obj, 0);
				
				// If it's a TowerSwitch, also restore the .team property (house name)
				if(GameBase::getDataName(%obj) == "TowerSwitch")
				{
					if(%houseTeam != "None" && %houseTeam != "")
						%obj.team = %houseTeam;
					else
						%obj.team = "";
				}
			}
			%switchesRestored++;
		}
		else
		{
			echo("WARNING: Tower" @ %t @ " group not found in MissionGroup!");
		}
	}
	
	echo("Restored " @ %flagsRestored @ " flags and " @ %switchesRestored @ " towerswitches.");
	
	// Recalculate house member counts from all currently connected players
	// This ensures the counts match the actual connected players, not just saved values
	RecalcHouseMemberCounts();
	
	// Update the objectives display with the loaded/recalculated values
	// This refreshes the screen that was initialized in InitObjectives() before LoadHouseObjectives() ran
	UpdateHouseObjectivesDisplay();
}

// Recalculate house member counts from all currently connected players
function RecalcHouseMemberCounts()
{
	dbecho($dbechoMode, "RecalcHouseMemberCounts()");
	
	// Reset all house member counts
	$HouseMember[HouseKronos] = 0;
	$HouseMember[HouseArbal] = 0;
	$HouseMember[HouseCurama] = 0;
	$HouseMember[HouseYuliple] = 0;
	
	// Count members from all currently connected clients
	%numClients = getNumClients();
	for(%i = 0; %i < %numClients; %i++)
	{
		%clientId = getClientByIndex(%i);
		if(%clientId != -1 && Client::getOwnedObject(%clientId) != -1)
		{
			%house = fetchData(%clientId, "MyHouse");
			if(%house != "")
			{
				$HouseMember[%house]++;
			}
		}
	}
}

function RecalcHouseObjectives()
{
	dbecho($dbechoMode, "RecalcHouseObjectives()");
	
	%tempSet = nameToID("MissionGroup");
	if(%tempSet == -1)
	{
		echo("ERROR RecalcHouseObjectives: MissionGroup not found!");
		return;
	}
	
	// Recalculate $BaseControl and $FlagCommand from actual flag/tower states
	// This ensures they match the actual game state, not just saved values
	// Reset all counts first
	$BaseControl[HouseKronos] = 0;
	$BaseControl[HouseArbal] = 0;
	$BaseControl[HouseCurama] = 0;
	$BaseControl[HouseYuliple] = 0;
	
	$FlagCommand[HouseKronos] = 0;
	$FlagCommand[HouseArbal] = 0;
	$FlagCommand[HouseCurama] = 0;
	$FlagCommand[HouseYuliple] = 0;
	
	// Count flags held by each house
	for(%i = 0; %i < Group::objectCount(%tempSet); %i++)
	{
		%obj = Group::getObject(%tempSet, %i);
		if(GameBase::getDataName(%obj) == "flag")
		{
			%holdingTeam = %obj.holdingTeam;
			if(%holdingTeam != "" && %holdingTeam != -1 && %holdingTeam != "None")
				$FlagCommand[%holdingTeam]++;
		}
	}
	
	// Count towers controlled by each house
	for(%t = 0; %t <= 3; %t++)
	{
		%towerGroup = nameToID("MissionGroup/Tower" @ %t);
		if(%towerGroup != -1)
		{
			for(%j = 0; %j < Group::objectCount(%towerGroup); %j++)
			{
				%obj = Group::getObject(%towerGroup, %j);
				if(GameBase::getDataName(%obj) == "TowerSwitch")
				{
					%houseTeam = %obj.team;
					if(%houseTeam != "" && %houseTeam != -1 && %houseTeam != "None")
						$BaseControl[%houseTeam]++;
					break;
				}
			}
		}
	}
	
	// Recalculate house member counts from all currently connected players
	RecalcHouseMemberCounts();
	
	// Update the objectives display with the recalculated values
	UpdateHouseObjectivesDisplay();
	
	// Silenced debug output - BaseControl, FlagCommand, and HouseMember values
	// echo("BaseControl: Kronos=" @ $BaseControl[HouseKronos] @ ", Arbal=" @ $BaseControl[HouseArbal] @ ", Curama=" @ $BaseControl[HouseCurama] @ ", Yuliple=" @ $BaseControl[HouseYuliple]);
	// echo("FlagCommand: Kronos=" @ $FlagCommand[HouseKronos] @ ", Arbal=" @ $FlagCommand[HouseArbal] @ ", Curama=" @ $FlagCommand[HouseCurama] @ ", Yuliple=" @ $FlagCommand[HouseYuliple]);
	// echo("HouseMember: Kronos=" @ $HouseMember[HouseKronos] @ ", Arbal=" @ $HouseMember[HouseArbal] @ ", Curama=" @ $HouseMember[HouseCurama] @ ", Yuliple=" @ $HouseMember[HouseYuliple]);
}
	for(%i = 0; %i < Group::objectCount(%tempSet); %i++)
	{
		%obj = Group::getObject(%tempSet, %i);
		if(GameBase::getDataName(%obj) == "flag")
		{
			%holdingTeam = %obj.holdingTeam;
			if(%holdingTeam != "" && %holdingTeam != -1 && %holdingTeam != "None")
				$FlagCommand[%holdingTeam]++;
		}
	}
	
	// Count towers controlled by each house
	for(%t = 0; %t <= 3; %t++)
	{
		%towerGroup = nameToID("MissionGroup/Tower" @ %t);
		if(%towerGroup != -1)
		{
			for(%j = 0; %j < Group::objectCount(%towerGroup); %j++)
			{
				%obj = Group::getObject(%towerGroup, %j);
				if(GameBase::getDataName(%obj) == "TowerSwitch")
				{
					%houseTeam = %obj.team;
					if(%houseTeam != "" && %houseTeam != -1 && %houseTeam != "None")
						$BaseControl[%houseTeam]++;
					break;
				}
			}
		}
	}
	
	// Recalculate house member counts from all currently connected players
	RecalcHouseMemberCounts();
	
	// Update the objectives display with the recalculated values
	UpdateHouseObjectivesDisplay();
	
	echo("BaseControl: Kronos=" @ $BaseControl[HouseKronos] @ ", Arbal=" @ $BaseControl[HouseArbal] @ ", Curama=" @ $BaseControl[HouseCurama] @ ", Yuliple=" @ $BaseControl[HouseYuliple]);
	echo("FlagCommand: Kronos=" @ $FlagCommand[HouseKronos] @ ", Arbal=" @ $FlagCommand[HouseArbal] @ ", Curama=" @ $FlagCommand[HouseCurama] @ ", Yuliple=" @ $FlagCommand[HouseYuliple]);
	echo("HouseMember: Kronos=" @ $HouseMember[HouseKronos] @ ", Arbal=" @ $HouseMember[HouseArbal] @ ", Curama=" @ $HouseMember[HouseCurama] @ ", Yuliple=" @ $HouseMember[HouseYuliple]);