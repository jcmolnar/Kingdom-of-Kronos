$flagReturnTime = 45;

function ObjectiveMission::missionComplete()
{
	$missionComplete = true;
	%group = nameToID("MissionCleanup/ObjectivesSet");
	for(%i = 0; (%obj = Group::getObject(%group, %i)) != -1; %i++)
	{
		ObjectiveMission::objectiveChanged(%obj);
	}
	for(%i = 0; %i < getNumTeams(); %i++) { 
		Team::setObjective(%i, $firstObjectiveLine-4, " ");
		Team::setObjective(%i, $firstObjectiveLine-3, "<f5>Mission Summary:");
		Team::setObjective(%i, $firstObjectiveLine-2, " ");
	}
	ObjectiveMission::setObjectiveHeading();
	ObjectiveMission::refreshTeamScores();
	%lineNum = "";
	$missionComplete = false;

	// back out of all the functions...
	schedule("Server::nextMission();", 0);
}

function ObjectiveMission::setObjectiveHeading()
{
	if($missionComplete)
	{
		%curLeader = 0;
		%tieGame = false;
		%tie = 0;
		%tieTeams[%tie] = %curLeader; 
		for(%i = 0; %i < getNumTeams() ; %i++) 
		echo("GAME: teamfinalscore " @ %i @ " " @ $teamScore[%i]);
		
		for(%i = 1; %i < getNumTeams() ; %i++) 
		{
			if($teamScore[%i] == $teamScore[%curLeader]) { 
				%tieGame = true;
				%tieTeams[%tie++] = %i;
			}
			else if($teamScore[%i] > $teamScore[%curLeader])
			{
				%curLeader = %i;	   
				%tieGame = false;
				%tie = 0;
				%tieTeams[%tie] = %curLeader; 
			}
		}
		if(%tieGame) {
			for(%g = 0; %g <= %tie; %g++) { 
				%names = %names @ getTeamName(%tieTeams[%g]);
				if(%g == %tie-1)
				%names = %names @ " and "; 
				else if(%g != %tie)
				%names = %names @ ", "; 
			}
			if(%tie > 1) 
			%names = %names @ " all"; 
		}
		for(%i = -1; %i < getNumTeams(); %i++)
		{
			objective::displayBitmap(%i,0);
			if(!%tieGame) {
				if(%i == %curLeader) { 
					if($teamScore[%curLeader] == 1)
					Team::setObjective(%i, 1, "<F5>           Your team won the mission with " @ $teamScore[%curLeader] @ " point!");
					else
					Team::setObjective(%i, 1, "<F5>           Your team won the mission with " @ $teamScore[%curLeader] @ " points!");
				}
				else {
					if($teamScore[%curLeader] == 1)
					Team::setObjective(%i, 1, "<F5>     The " @ getTeamName(%curLeader) @ " team won the mission with " @ $teamScore[%curLeader] @ " point!");
					else
					Team::setObjective(%i, 1, "<F5>     The " @ getTeamName(%curLeader) @ " team won the mission with " @ $teamScore[%curLeader] @ " points!");
				}
			}	
			else {
				if(getNumTeams() > 2) {
					Team::setObjective(%i, 1, "<F5>     The " @ %names @ " tied with a score of " @ $teamScore[%curLeader]);
				}
				else
				Team::setObjective(%i, 1, "<F5>     The mission ended in a tie where each team had a score of " @ $teamScore[%curLeader]);
			}
			Team::setObjective(%i, 2, " ");
		}
	}
	else {
		for(%i = -1; %i < getNumTeams(); %i++)
		{
			objective::displayBitmap(%i,0);
			Team::setObjective(%i,1, "<f5>Mission Completion:");
			Team::setObjective(%i, 2,"<f1>   - " @ $teamScoreLimit @ " points needed to win the mission.");
		}
	}
	if(!$Server::timeLimit)
	%str = "<f1>   - No time limit on the game.";
	else if($timeLimitReached)
	%str = "<f1>   - Time limit reached.";
	else if($missionComplete)
	{
		%time = getSimTime() - $missionStartTime;
		%minutes = Time::getMinutes(%time);
		%seconds = Time::getSeconds(%time);
		if(%minutes < 10)
		%minutes = "0" @ %minutes;
		if(%seconds < 10)
		%seconds = "0" @ %seconds;
		%str = "<f1>   - Total match time: " @ %minutes @ ":" @ %seconds;
	}
	else
	%str = "<f1>   - Time remaining: " @ floor($Server::timeLimit - (getSimTime() - $missionStartTime) / 60) @ " minutes.";
	for(%i = -1; %i < getNumTeams(); %i++) {
		Team::setObjective(%i, 3, " ");
		Team::setObjective(%i, 4, "<f5>Mission Information:");
		Team::setObjective(%i, 5, "<f1>   - Mission Name: " @ $missionName); 
		Team::setObjective(%i, 6, %str);
	}
}

function objective::displayBitmap(%team, %line)
{
	if($TestMissionType == "CTF") {
		%bitmap1 = "capturetheflag1.bmp";
		%bitmap2 = "capturetheflag2.bmp";
	}
	else if($TestMissionType == "C&H") {
		%bitmap1 = "captureandhold1.bmp";
		%bitmap2 = "captureandhold2.bmp";
	}
	else if($TestMissionType == "D&D") {
		%bitmap1 = "defendanddest1.bmp";
		%bitmap2 = "defendanddest2.bmp";
	}	   
	else if($TestMissionType == "F&R") {
		%bitmap1 = "findandret1.bmp";
		%bitmap2 = "findandret2.bmp";
	}
	if(%bitmap1 == "" || %bitmap2 == "")
	Team::setObjective(%team, %line, " ");
	else
	Team::setObjective(%team, %line, "<jc><B0,0:" @ %bitmap1 @ "><B0,0:" @ %bitmap2 @ ">");
}

function Game::checkTimeLimit()
{
	// if no timeLimit set or timeLimit set to 0,
	// just reschedule the check for a minute hence
	$timeLimitReached = false;
	ObjectiveMission::setObjectiveHeading();

	if(!$Server::timeLimit)
	{
		schedule("Game::checkTimeLimit();", 60);
		return;
	}

	%curTimeLeft = ($Server::timeLimit * 60) + $missionStartTime - getSimTime();
	if(%curTimeLeft <= 0 && $matchStarted)
	{
		echo("GAME: timelimit");
		$timeLimitReached = true;
		//echo("checking for objective time limit status...");
		%set = nameToID("MissionCleanup/ObjectiveSet");
		for(%i = 0; (%obj = Group::getObject(%set, %i)) != -1; %i++)
		GameBase::virtual(%obj, "timeLimitReached", %clientId);
		ObjectiveMission::missionComplete();
	}
	else
	{
		if(%curTimeLeft >= 20)
		schedule("Game::checkTimeLimit();", 20);
		else
		schedule("Game::checkTimeLimit();", %curTimeLeft + 1);
		UpdateClientTimes(%curTimeLeft);
	}
}

function Vote::changeMission()
{
	$missionComplete = true;
	ObjectiveMission::refreshTeamScores();
	%group = nameToID("MissionCleanup/ObjectivesSet");
	%lineNum = "";
	for(%i = 0; (%obj = Group::getObject(%group, %i)) != -1; %i++)
	{
		ObjectiveMission::objectiveChanged(%obj);
	}
	for(%i = 0; %i < getNumTeams(); %i++) { 
		Team::setObjective(%i, $firstObjectiveLine-2, " ");
		Team::setObjective(%i, $firstObjectiveLine-1, "<f5>Mission Summary:");
	}
	ObjectiveMission::setObjectiveHeading();
	$missionComplete = false;
}

function ObjectiveMission::checkPoints()
{
	for(%i = 0; %i < getNumTeams(); %i++)
	$teamScore[%i] += $deltaTeamScore[%i] / 12;
	schedule("ObjectiveMission::checkPoints();", 5);
}

function ObjectiveMission::initCheck(%object)
{
	if($TestMissionType == "") {
		%name = gamebase::getdataname(%object); 
		if(%name == Flag) { 
			if(gamebase::getteam(%object) != -1)
			$TestMissionType = "CTF";
			else
			$TestMissionType = "F&R";
		}
		else if(%object.objectiveName != "" && %object.scoreValue)
		$TestMissionType = "D&D";
		else if(%name == TowerSwitch)
		$NumTowerSwitchs++;
	}

	%object.trainingObjectiveComplete = "";
	%object.objectiveLine = "";
	if(GameBase::virtual(%object, objectiveInit))
	addToSet("MissionCleanup/ObjectivesSet", %object);
}

function ObjectiveMission::refreshTeamScores()
{

}

function ObjectiveMission::objectiveChanged(%this)
{
	if(%this.objectiveLine)
	for(%i = -1; %i < getNumTeams(); %i++)
	Team::setObjective(%i,%this.objectiveLine, 
	"<f1> " @ GameBase::virtual(%this, getObjectiveString, %i));
}

function TowerSwitch::onCollision(%this, %object) {
    if (getObjectType(%object) != "Player" || Player::isDead(%object))
        return;

    %playerClient = Player::getClient(%object);
    %newTeam = fetchData(%playerClient, "MyHouse");
    if (%newTeam == "")
        return;

    %oldTeam = %this.Team;
    if (%oldTeam == %newTeam)
        return;

    %flagName = getWord(Gamebase::getMapName(%this), 2);
    if (%flagName == -1) {
        echo("ERROR: Invalid flag name from map name.");
        return;
    }

    %num = $House::BaseNum[%flagName];
    if (%num == "" || %num == -1) {
        echo("ERROR: Invalid base index for flag: " @ %flagName);
        return;
    }

    if (%oldTeam != "None") {
        %oldIndex = $House::Index[%oldTeam];
        if (%oldIndex != "" && %oldIndex != -1)
            HouseData::Set(%oldIndex, %num, false);
        else
            echo("ERROR: Invalid old house index for team: " @ %oldTeam);
    }

    %newIndex = $House::Index[%newTeam];
    if (%newIndex != "" && %newIndex != -1)
        HouseData::Set(%newIndex, %num, true);
    else
        echo("ERROR: Invalid new house index for team: " @ %newTeam);

    %touchClientName = Client::getName(%playerClient);
    %group = GetGroup(%this);
    Group::iterateRecursive(%group, GameBase::setTeam, 1);
    Group::iterateRecursive(%group, TurretTeam, %newTeam);

    if (%oldTeam == "None") {
        MessageAllExcept(%playerClient, 0, %touchClientName @ " claimed " @ %this.objectiveName @ " for " @ %newTeam @ "!");
        Client::sendMessage(%playerClient, 0, "You claimed " @ %this.objectiveName @ " for " @ %newTeam @ "!");
    } else {
        MessageAllExcept(%playerClient, 0, %touchClientName @ " captured " @ %this.objectiveName @ " from " @ %oldTeam @ "!");
        Client::sendMessage(%playerClient, 0, "You captured " @ %this.objectiveName @ " from " @ %oldTeam @ "!");
    }

    %this.Team = %newTeam;

    if (%this.objectiveLine) {
        TeamMessages(0, %newTeam, %newTeam @ " has taken an objective.");
        if (%oldTeam != "None")
            TeamMessages(1, %oldTeam, %newTeam @ " has taken your objective.~wLostTower.wav");
        ObjectiveMission::ObjectiveChanged(%this);
    }
}
function Flag::onCollision(%this, %object) {
    if (%this.carrier != -1 || RPG::isAiControlled(%object) || getObjectType(%object) != "Player")
        return;

    %playerClient = Player::getClient(%object);
    %touchClientName = Client::getName(%playerClient);
    %newTeam = fetchData(%playerClient, "MyHouse");
    %oldTeam = %this.Team;

    if (%newTeam == "" || %oldTeam == %newTeam)
        return;

    if (%object.carryFlag == "") {
        if (%object.outArea == "") {
            Player::setItemCount(%object, Flag, 1);
            Player::mountItem(%object, Flag, $FlagSlot, %oldTeam);
            Item::hide(%this, true);
            %this.atHome = false;
            %this.carrier = %object;
            %this.pickupSequence++;
            %object.carryFlag = %this;

            %flagstand = %this.flagStand;
            if (%flagstand != "")
                %flagstand.flag = "";

            Flag::setWaypoint(%playerClient, %this);

            if (%this.fadeOut) {
                GameBase::startFadeIn(%this);
                %this.fadeOut = "";
            }

            GameBase::setPosition(%this, "0 0 0");

            // Update house data
            if (%oldTeam != "None") {
                %oldIndex = $House::Index[%oldTeam];
                %flagName = getWord(%this.objectiveName, 1);
                %num = $House::FlagNum[%flagName];

                if (%oldIndex != "" && %oldIndex != -1 && %num != "" && %num != -1) {
                    HouseData::Set(%oldIndex, %num, false);
                } else {
                    echo("ERROR: Invalid house index or flag number for team: " @ %oldTeam @ ", flag: " @ %flagName);
                }

                MessageAllExcept(%playerClient, 0, %touchClientName @ " took " @ %this.objectiveName @ " from " @ %oldTeam @ ".~wflag1.wav");
                Client::sendMessage(%playerClient, 0, "You took " @ %this.objectiveName @ " from " @ %oldTeam @ ".~wflag1.wav");
                %this.Team = "None";
            } else {
                MessageAllExcept(%playerClient, 0, %touchClientName @ " took " @ %this.objectiveName @ ".~wflag1.wav");
                Client::sendMessage(%playerClient, 0, "You took " @ %this.objectiveName @ ".~wflag1.wav");
            }

            ObjectiveMission::ObjectiveChanged(%this);
        } else {
            Client::sendMessage(%playerClient, 1, "Flag not in mission area.");
        }
    }
}
function FlagStand::onCollision(%this, %object) {
    if (Gamebase::getDataName(%object) != Flag)
        return;

    %newTeam = %this.Team;
    if (%newTeam == "None" || %this.flag != "")
        return;

    %flag = %object;
    %flag.carrier = -1;
    %flag.Team = %newTeam;
    %flag.flagStand = %this;
    %this.flag = %flag;

    Item::hide(%flag, false);
    GameBase::setPosition(%flag, GameBase::getPosition(%this));

    %index = $House::Index[%newTeam];
    if (%index == "" || %index == -1) {
        echo("ERROR: Invalid house index for team: " @ %newTeam);
        return;
    }

    %flagName = getWord(%flag.objectiveName, 1);
    if (%flagName == -1) {
        echo("ERROR: Invalid flag name from objectiveName: " @ %flag.objectiveName);
        return;
    }

    %num = $House::FlagNum[%flagName];
    if (%num == "" || %num == -1) {
        echo("ERROR: Invalid flag index for flag name: " @ %flagName);
        return;
    }

    HouseData::Set(%index, %num, true);

    for (%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl)) {
        if (fetchData(%cl, "MyHouse") == %newTeam)
            Client::sendMessage(%cl, $MsgBeige, "Your House holds " @ %flag.objectiveName @ ".~wflagcapture.wav");
        else
            Client::sendMessage(%cl, $MsgBeige, %newTeam @ " holds " @ %flag.objectiveName @ ".");
    }

    ObjectiveMission::ObjectiveChanged(%flag);
}
function Flag::onDrop(%player, %type)
{
	%playerTeam = GameBase::getTeam(%player);
	%flag = %player.carryFlag;
	%flagTeam = GameBase::getTeam(%flag);
	%playerClient = Player::getClient(%player);
	%dropClientName = Client::getName(%playerClient);

	if(%flagTeam == -1)
	{
		MessageAllExcept(%playerClient, 1, %dropClientName @ " dropped " @ %flag.objectiveName @ "!");
		Client::sendMessage(%playerClient, 1, "You dropped "  @ %flag.objectiveName @ "!");
	}
	else
	{
		MessageAllExcept(%playerClient, 0, %dropClientName @ " dropped the " @ getTeamName(%flagTeam) @ " flag!");
		Client::sendMessage(%playerClient, 0, "You dropped the " @ getTeamName(%flagTeam) @ " flag!");
		TeamMessages(1, %flagTeam, "Your flag was dropped in the field.", -2, "", "The " @ getTeamName(%flagTeam) @ " flag was dropped in the field.");
	}
	GameBase::throw(%flag, %player, 10, false);
	Item::hide(%flag, false);
	Player::setItemCount(%player, "Flag", 0);
	%flag.carrier = -1;
	%player.carryFlag = "";
	Flag::clearWaypoint(%playerClient, false);

	schedule("Flag::checkReturn(" @ %flag @ ", " @ %flag.pickupSequence @ ");", $flagReturnTime);
	%flag.dropFade = 1;
	ObjectiveMission::ObjectiveChanged(%flag);
}

function Flag::checkReturn(%flag, %sequenceNum)
{
	//echo("checking for flag return: ", %flag, ", ", %sequenceNum);
	if(%flag.pickupSequence == %sequenceNum)
	{
		if(%flag.dropFade) { 
			GameBase::startFadeOut(%flag);
			%flag.dropFade= "";
			%flag.fadeOut= 1;
			schedule("Flag::checkReturn(" @ %flag @ ", " @ %sequenceNum @ ");", 2.5);
		}
		else {
			%flagTeam = GameBase::getTeam(%flag);
			if(%flagTeam == -1)
			{
				//if(%flag.flagStand == "" || %flag.flagStand.flag != "") {
				MessageAll(0, %flag.objectiveName @ " was returned to its initial position.");
				GameBase::setPosition(%flag, %flag.originalPosition);
				Item::setVelocity(%flag, "0 0 0");
				%flag.flagStand = "";
			}
			else
			{
				TeamMessages(0, %flagTeam, "Your flag was returned to base.~wflagreturn.wav", -2, "", "The " @ getTeamName(%flagTeam) @ " flag was returned to base.~wflagreturn.wav");
				GameBase::setPosition(%flag, %flag.originalPosition);
				Item::setVelocity(%flag, "0 0 0");
			}
			%flag.atHome = true;
			GameBase::startFadeIn(%flag);
			%flag.fadeOut= "";
			ObjectiveMission::ObjectiveChanged(%flag);
		}
	}
}

function Flag::clientKilled(%this, %playerId, %killerId)
{
	%player = Client::getOwnedObject(%playerId);
	%killer = Client::getOwnedObject(%killerId);

	if(%player == -1 || %killer == -1)
	return;

	%flagTeam = GameBase::getTeam(%this);
	if(%flagTeam == -1)
	return;

	%playerTeam = GameBase::getTeam(%player);
	%killerTeam = GameBase::getTeam(%killer);

	if(%playerTeam == %killerTeam)
	return;

	// killer's the only guy who gets a bonus.
	if(%killerTeam == %flagTeam)
	{
		// check for defending the flag
		// only if the flag is not being carried
		if(%this.carrier == -1)
		{
			%flagPos = GameBase::getPosition(%this);
			%playerPos = GameBase::getPosition(%player);

			if(Vector::getDistance(%flagPos, %playerPos) < 80)
			{
				%killerId.score++;
				Game::refreshClientScore(%killerId);
				messageAll(0, Client::getName(%killerId) @ " gets a bonus for defending the flag!");
			}
		}
	}
	else
	{
		if(%this.carrier != -1)
		{
			%carrierTeam = GameBase::getTeam(%this.carrier);
			// check for defending the carrier bonus
			if(%carrierTeam == %killerTeam)
			{
				if(Vector::getDistance(GameBase::getPosition(%this.carrier),
							GameBase::getPosition(%killer)) < 80)
				{
					%killerId.score++;
					Game::refreshClientScore(%killerId);
					messageAll(0, Client::getName(%killerId) @ " gets a bonus for defending the flag carrier!");
				}               
			}
		}
	}
}

function Flag::clearWaypoint(%client, %success)
{
	if(%success)
	setCommandStatus(%client, 0, "Objective completed.~wobjcomp");
	else
	setCommandStatus(%client, 0, "Objective failed.");
}

function Flag::setWaypoint(%client, %flag)
{
	if(!%client.autoWaypoint)
	return;
	%flagTeam = GameBase::getTeam(%flag);
	%team = Client::getTeam(%client);

	if(%flagTeam == -1)
	{ 
		for(%s = $teamFlagStand[%team]; %s != ""; %s = %s.nextFlagStand) 
		{
			if(%s.flag == "") {
				%pos = GameBase::getPosition(%s);
				%posX = getWord(%pos,0);
				%posY = getWord(%pos,1);
				issueCommand(%client, %client, 0,"Take " @ %flag.objectiveName @ " to empty flag stand.~wcapobj", %posX, %posY);
				return;
			}
		}
	}
	else
	{
		%pos = ($teamFlag[%team]).originalPosition;
		%posX = getWord(%pos,0);
		%posY = getWord(%pos,1);
		issueCommand(%client, %client, 0,"Take the " @ getTeamName(%flagTeam) @ " flag to our flag.~wcapobj", %posX, %posY);
		return;
	}
}

function TowerSwitch::onAdd(%this)
{

}

function TowerSwitch::onDamage()
{

}

function FlagStand::objectiveInit(%this)
{
	%this.flag = "";
	%team = GameBase::getTeam(%this);

	%this.nextFlagStand = $teamFlagStand[%team];
	$teamFlagStand[%team] = %this;
	
	return false;
}

function Flag::clientDropped(%this, %clientId)
{
	//echo(%this @ " " @ %clientId);
	%type = Player::getMountedItem(%clientId, $FlagSlot);
	if(%type != -1)
	Player::dropItem(%clientId, %type);
}

function Sensor::objectiveInit(%this)
{
	return StaticShape::objectiveInit(%this);
}

function Turret::objectiveInit(%this)
{
	return StaticShape::objectiveInit(%this);
}

function StaticShape::objectiveInit(%this)
{
	%this.destroyerTeam = "";
	return %this.scoreValue != "";
}

function Sensor::getObjectiveString(%this, %forTeam)
{
	return StaticShape::getObjectiveString(%this, %forTeam);
}

function Turret::getObjectiveString(%this, %forTeam)
{
	return StaticShape::getObjectiveString(%this, %forTeam);
}

//function StaticShape::getObjectiveString(%this, %forTeam)
//{
//   %thisTeam = GameBase::getTeam(%this);
//   if(%this.destroyerTeam != "")
//   {
//      if(%forTeam == %this.destroyerTeam && %thisTeam != %forTeam)
//         return "<Bitem_ok.bmp>\nYour team successfully destroyed the " @ getTeamName(%thisTeam) @ " " @ %this.objectiveName @ " objective.";
//      else if(%forTeam == %thisTeam)
//         return "<Bitem_damaged.bmp>\nYour team failed to defend " @ %this.objectiveName;
//      else
//         return "<Bitem_ok.bmp>\n" @ getTeamName(%this.destroyerTeam) @ " team destroyed the " @ getTeamName(%thisTeam) @ " " @ %this.objectiveName @ " objective.";
//   }
//   else
//   {
//     if($missionComplete)
//      {
//         if(%forTeam != -1) {
//				if(%forTeam == %thisTeam)
//         	   return "<Bitem_ok.bmp>\nYour team successfully defended " @ %this.objectiveName @ ".";
//         	else
//         	   return "<Bitem_damaged.bmp>\nYour team failed to destroy " @ getTeamName(%thisTeam) @ " objective, " @ %this.objectiveName @ ".";
//      	}
//			else 
//        	   return "<Bitem_ok.bmp>\n" @ getTeamName(%thisTeam) @ " failed to destroy the " @ %this.objectiveName @ " objective.";
//		}
//      else
//      {
//         if(%forTeam != -1) {
//         	if(%forTeam == %thisTeam)
//            	return "<Bitem_ok.bmp>\nDefend " @ %this.objectiveName @ ".";
//         	else
//	          	return "<Bitem_damaged.bmp>\nDestroy " @ getTeamName(%thisTeam) @ " objective, " @ %this.objectiveName @ "(" @ %this.scoreValue @ " points).";
//      	}
//			else 
//        	   return "<Bitem_ok.bmp>\n" @ getTeamName(%thisTeam) @ " must defend the " @ %this.objectiveName @ " objective.";
//
//      }
//   }
//}

function StaticShape::timeLimitReached(%this)
{
	if(%this.scoreValue && !%this.destroyerTeam)
	{
		// give the defense some props!
		$teamScore[GameBase::getTeam(%this)] += %this.scoreValue;
	}
}

function StaticShape::objectiveDestroyed(%this)
{
	if(%this.destroyed == "") {
		// test if it's really an objective
		if(!%this.objectiveLine)
		return;
		%destroyerTeam = %this.lastDamageTeam;
		%thisTeam = GameBase::getTeam(%this);
		%playerClient = GameBase::getControlClient(%this.lastDamageObject);
		if(%playerClient != -1)
		%clientName = Client::getName(%playerClient);

		if(%thisTeam == %destroyerTeam)
		{
			// uh-oh... we killed our own stuff.
			// award the points to everyone else
			for(%i = 0; %i < getNumTeams(); %i++)
			{
				if(%i == %thisTeam)
				continue;
				$teamScore[%i] += %this.scoreValue;
			}
			if(%playerClient != -1)
			{
				MessageAllExcept(%playerClient, 0, %clientName @ " destroyed a friendly objective.");
				Client::sendMessage(%playerClient, 0, "You destroyed a friendly objective!");
			}
			MessageAll(1, getTeamName(%destroyerTeam) @ " objective " @ %this.objectiveName @ " destroyed.");
		}
		else
		{
			$teamScore[%destroyerTeam] += %this.scoreValue;
			if(%playerClient != -1)
			{
				%playerClient.score+=5;
				Game::refreshClientScore(%playerClient);
				MessageAllExcept(%playerClient, 0, %clientName @ " destroyed an objective!");
				Client::sendMessage(%playerClient, 0, "You destroyed an objective!");
			}
			MessageAll(1, getTeamName(%thisTeam) @ " objective " @ %this.objectiveName @ " destroyed.");
		}
		%this.destroyerTeam = %destroyerTeam;
		ObjectiveMission::ObjectiveChanged(%this);
		%this.destroyed = 1;
	}
}

function StaticShape::objectiveDisabled(%this)
{
}

function TurretTeam(%object,%houseTeam)
{
	%object.Team = %houseTeam;
}