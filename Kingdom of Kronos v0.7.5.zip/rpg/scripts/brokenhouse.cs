
function HouseData::Defaults() {
    $House::NumFlag[1] = "Gratigud";
    $House::NumFlag[2] = "Belaguard";
    $House::NumFlag[3] = "Crosion";
    $House::NumFlag[4] = "Murch";
    $House::FlagNum["Gratigud"] = 1;
    $House::FlagNum["Belaguard"] = 2;
    $House::FlagNum["Crosion"] = 3;
    $House::FlagNum["Murch"] = 4;

    $House::NumBase[5] = "Thaliel";
    $House::NumBase[6] = "Bruin";
    $House::NumBase[7] = "Delern";
    $House::NumBase[8] = "Projao";
    $House::BaseNum["Thaliel"] = 5;
    $House::BaseNum["Bruin"] = 6;
    $House::BaseNum["Delern"] = 7;
    $House::BaseNum["Projao"] = 8;

    $House::Name[0] = "";
    $House::Name[1] = "House Kronos";
    $House::Equipment[1] = "";
    $House::Index["House Kronos"] = 1;

    $House::Name[2] = "House Arbal";
    $House::Equipment[2] = "";
    $House::Index["House Arbal"] = 2;

    $House::Name[3] = "House Curama";
    $House::Equipment[3] = "";
    $House::Index["House Curama"] = 3;

    $House::Name[4] = "House Yuliple";
    $House::Equipment[4] = "";
    $House::Index["House Yuliple"] = 4;

    $House::LoadFile = "[KoK-Houses].cs";
    $House::SaveFile = $House::LoadFile; // Ensure save/load paths match
}


//Save the data for the houses

function HouseData::Save(%echoOff) {
    File::delete($House::SaveFile);
    export("$HouseData::Data*", $House::SaveFile); // Use correct export pattern
    if (!%echoOff)
        echo("House data saved to: " @ $House::SaveFile);
}


//Load the data for the houses

function HouseData::Load() {
    HouseData::Reset();
    schedule("HouseData::LoadEnd();", 1);
}


//Post-load to prevent issues with Reset

function HouseData::LoadEnd() {
    if (isfile($House::LoadFile)) {
        exec($House::LoadFile);
        echo("House data loaded from: " @ $House::LoadFile);
    }
    HouseData::Defaults(); // Only set defaults after loading saved data
    schedule("HouseData::Init();", 4);
}

//Resets the data for the houses
function HouseData::Reset()
{
	deleteVariables("HouseData::*");
	deleteVariables("House::*");
	
	for(%i = 1; %i <= 4; %i++)
	{
		$HouseData::Data[%i, 0] = 0;
		for(%j = 1; %j <= 8; %j++)
			$HouseData::Data[%i, %j] = false;
	}
}

//Quick function for getting the house data
function HouseData::Get(%id, %index)
{
	//%id:
	//%id == 1, House Kronos
	//%id == 2, House Arbal
	//%id == 3, House Curama
	//%id == 4, House Yuliple
	
	//%index:
	//%index == 0, House Count (num Players)
	//%index == 1, Owns Gratigud
	//%index == 2, Owns Belaguard
	//%index == 3, Owns Crosion
	//%index == 4, Owns Murch
	//%index == 5, Owns Thaliel
	//%index == 6, Owns Bruin
	//%index == 7, Owns Delern
	//%index == 8, Owns Projao
	
	return $HouseData::Data[%id, %index];
}

//Quick function for setting the house data
function HouseData::Set(%id, %index, %data)
{
	//%id:
	//%id == 1, House Kronos
	//%id == 2, House Arbal
	//%id == 3, House Curama
	//%id == 4, House Yuliple
	
	//%index:
	//%index == 0, House Count (num Players)
	//%index == 1, Owns Gratigud
	//%index == 2, Owns Belaguard
	//%index == 3, Owns Crosion
	//%index == 4, Owns Murch
	//%index == 5, Owns Thaliel
	//%index == 6, Owns Bruin
	//%index == 7, Owns Delern
	//%index == 8, Owns Projao
	
	$HouseData::Data[%id, %index] = %data;
}

//Initalize flag positions and data, assign an owner if it's owned.
function HouseData::Init()
{
	%flag = 0;
	%base = 4;
	for(%i = 8250; %i <= 9000; %i++)
	{
		if(Gamebase::getDataName(%i) == Flag)
		{
			$House::Flags[$House::NumFlag[%flag++]] = %i;
			%i.Team = "None";
			%i.flagStand = "";
		}
		else if(Gamebase::getDataName(%i) == TowerSwitch)
		{
			$House::Bases[$House::NumBase[%base++]] = %i;
			%i.Team = "None";
			
			%group = getGroup(%i);
			%count = Group::objectCount(%group);
			
			for(%k = 0; %k < %count; %k++)
			{
				%obj = Group::getObject(%group, %k);
				%obj.Team = $House::Name[%i];
			}

			Group::iterateRecursive(%group, GameBase::setTeam, 1);
			Group::iterateRecursive(%group, TurretTeam, "None");				
		}
		else if(Gamebase::getDataName(%i) == FlagStand)
		{
			%name = Gamebase::getMapName(%i);
			%house = "House " @ clipTrailingNumbers(%name);
			%number = $House::Index[%house];
			%index = String::getSubStr(%name, String::Len(%name)-1, String::Len(%name)-1);
			%i.Team = %house;
			%i.flag = "";
			$House::Positions[%number, %index] = Gamebase::getPosition(%i);
		}
	}
	
	for(%i = 1; %i <= 4; %i++)
	{
		for(%j = 1; %j <= 4; %j++)
		{
			if(HouseData::Get(%i, %j) == true)
			{
				%id = $House::Flags[$House::NumFlag[%j]];
				%id.Team = $House::Name[%i];
				Gamebase::setPosition(%id, $House::Positions[%i, %j]);
			}
		}
		for(%j = 5; %j <= 8; %j++)
		{
			if(HouseData::Get(%i, %j) == true)
			{	
				%id = $House::Bases[$House::NumBase[%j]];

				%group = getGroup(%id);
				%count = Group::objectCount(%group);
				
				for(%k = 0; %k < %count; %k++)
				{
					%obj = Group::getObject(%group, %k);
					%obj.Team = $House::Name[%i];
				}
				
				Group::iterateRecursive(%group, GameBase::setTeam, 1);
				Group::iterateRecursive(%group, TurretTeam, $House::Name[%i]);	
			}
		}
	}
}

function BootFromCurrentHouse(%clientId, %echo)
{
	dbecho($dbechoMode, "BootFromCurrentHouse(" @ %clientId @ ", " @ %echo @ ")");

	%house = fetchData(%clientId, "MyHouse");

	if(%house != "")
	{
		UnequipMountedStuff(%clientId);
		%num = $House::Index[%house];

		if(%echo)
			Client::sendMessage(%clientId, $MsgRed, "You have been booted from " @ $House::Name[%num] @ " and have lost all rank points.");

		//Client Data
		storeData(%clientId, "MyHouse", "");
		storeData(%clientId, "RankPoints", 0);
		
		//Server Data
		HouseData::Set(%num, 0, (HouseData::Get(%num, 0) - 1));

		return %num;
	}
	else
		return -1;
}

function JoinHouse(%clientId, %num, %echo)
{
	dbecho($dbechoMode, "JoinHouse(" @ %clientId @ ", " @ %num @ ", " @ %echo @ ")");

	//Client Data
	storeData(%clientId, "MyHouse", $House::Name[%num]);
	storeData(%clientId, "RankPoints", $joinHouseRankPoints);
	
	//Server Data
	HouseData::Set(%num, 0, (HouseData::Get(%num, 0) + 1));

	if(%echo) 
		Client::sendMessage(%clientId, $MsgBeige, "You have joined " @ $House::Name[%num] @ " and have been awarded " @ $joinHouseRankPoints @ " rank points.");
}

function House::findHouse()
{
	%final = 1;
	for(%i = 1; %i <= 4; %i++)
	{
		%lowest = HouseData::Get(%i, 0);
		%next = HouseData::Get(%i+1, 0);
		
		if(%next != "")
			if(%lowest > %next)
				%final = (%i + 1);
	}
	
	return round((getRandom() * (4 - %final)) + %final);
}

function House::getArtifacts(%house)
{
	%count = 0;
	for(%i = 1; %i <= 4; %i++)
		if(HouseData::get(%house, %i) == true)
			%count++;
			
	return %count;
}

function House::getBases(%house)
{
	%count = 0;
	for(%i = 5; %i <= 8; %i++)
		if(HouseData::get(%house, %i) == true)
			%count++;
			
	return %count;
}

function House::Earnings()
{
	%lower = 0;
	for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
	{
		%house = fetchData(%cl, "MyHouse");
		if(%house != "")
		{
			%reward = ((10000 * (fetchData(%cl, "RemortStep") + 1)) + (1000 * (fetchData(%cl, "RemortStep") + 1) * House::getBases($House::Index[%house]))) * (0.5 + (0.5 * House::getArtifacts($House::Index[%house])));
			if(%reward < 0 && House::getArtifacts($House::Index[%house]) > 0)
				%reward = 0;
			%expreward = (300 * fetchdata(%cl,"RemortStep"));
			%rpreward = (0.25 * House::getBases($House::Index[%house])) + (0.25 * House::getArtifacts($House::Index[%house]));
			%spreward = (1 * fetchdata(%cl, "RemortStep"));
			for(%clr = Client::getFirst(); %clr != -1; %clr = Client::getNext(%clr))
			{
				if(%rpreward < 1)
					%rpreward = 0;
				%check = fetchData(%clr, "MyHouse");
				
				if(%check != %house && %check != "")
					%lower = 1;
			}
			if(%lower == 0)
			{
				%reward = %reward * 0.25;
				%expReward = %expReward * 0.25;
				%reward = floor(%reward);
				%expReward = floor(%expReward);
				%rpreward = floor(%rpreward);
				%spreward = floor(%spreward);
			}
			
			if(fetchData(%cl, "LVL") >= getMaxLevel(%cl))
				%expReward = 0;
			else
				storeData(%cl, "EXP", %expReward, "inc");			
			
			storeData(%cl, "BANK", %reward, "inc");	
			storeData(%cl, "RankPoints", %rpreward, "inc");
			storeData(%cl, "SPcredits", %spreward, "inc");
			if(%reward > 0)
				Client::sendMessage(%cl, $MsgBeige, "You received " @ %reward @ " coins as payment from your house.");
			else if(%reward < 0)
				Client::sendMessage(%cl, $MsgBeige, "You lost " @ %reward @ " coins because your house isn't making any money.");
			if(%expReward > 0)
				Client::sendMessage(%cl, $MsgBeige, "You received " @ %expReward @ " experience points for being so loyal to your house.");
			if(%rpreward > 0)
				Client::sendMessage(%cl, $MsgBeige, "You received " @ %rpreward @ " rank points for being so loyal to your house.");
			if(%spreward > 0)
				Client::sendMessage(%cl, $MsgBeige, "You received " @ %spreward @ " Skill points for being so loyal to your house.");
			RefreshAll(%cl);
		}
	}
}