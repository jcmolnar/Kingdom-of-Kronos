function Client::onKilled(%clientId, %killerId, %damageType)
{
	dbecho($dbechoMode, "Client::onKilled(" @ %clientId @ ", " @ %killerId @ ", " @ %damageType @ ")");

	//This function is NOT an event, it must be MANUALLY CALLED!
	//At this point, the client can still be queried for getItemCounts, but is not considered an object anymore.

	//we can award the other players exp
	if(!fetchData(%clientId, "noExperienceFlag"))
		DistributeExpForKilling(%clientId);

	//The player with the killshot gets the official "kill"
	if(!IsInCommaList(fetchData(%killerId, "TempKillList"), Client::getName(%clientId)))
	storeData(%killerId, "TempKillList", AddToCommaList(fetchData(%killerId, "TempKillList"), Client::getName(%clientId)));

	if(%killerId != %clientId)
	{
		//a human player killed %clientId
		%n = Client::getName(%killerId);

		Client::sendMessage(%clientId, 0, "You were killed by " @ %n @ "!");

		//if(fetchData(%killerId, "bounty") == Client::getName(%clientId))
		//	storeData(%killerId, "bounty", fetchData(%clientId, "LVL") @ " !Q@W#E$R%T^Y&U*I(O)P");
	}
	else if(%killerId == %clientId)
	{
		Client::sendMessage(%clientId, 0, "You killed yourself!");
	}
	else if(%damageType == 11 || %damageType == 12 || %damageType == 2)
	{
		Client::sendMessage(%clientId, 0, "You were killed!");
	}

	//Check to see if the player was in a sanctioned battle
	if($Colloseum::Mode == "Seal")
	{
		if($Colloseum::Client == %clientId)
			Colloseum::EndSeal(%clientId, false);
		else if($Colloseum::Client == %killerId)
			if(Colloseum::isSealComplete())
				Colloseum::EndSeal(%killerId, true);
	}
	else if($Colloseum::Mode == "Colloseum")
	{
		if($Colloseum::Client == %clientId)
			Colloseum::roomReset(%clientId, true);
		else if($Colloseum::Client == %killerId)
			Colloseum::checkRound(%clientId, $Colloseum::Round);
	}
	else if(Duel::isDueling(%clientId) && Duel::isDueling(%killerId))
	{
		if($Duel::Challenger == Client::getName(%killerId))
			Duel::endDuel(true);
		else
			Duel::endDuel(false);
	}

	UnHide(%clientId);

	//========================================================================================================================

	//echo("GAME: kill " @ %killerId @ " " @ %clientId @ " " @ %damageType);
	%clientId.guiLock = true;
	Client::setGuiMode(%clientId, $GuiModePlay);

	Game::clientKilled(%clientId, %killerId);
}

function Game::clientKilled(%playerId, %killerId)
{
	dbecho($dbechoMode, "Game::clientKilled(" @ %playerId @ ", " @ %killerId @ ")");

	%set = nameToID("MissionCleanup/ObjectivesSet");
	if(%set != -1 && %set != "")
	{
		for(%i = 0; (%obj = Group::getObject(%set, %i)) != -1; %i++)
		{
			if(%obj != -1 && %obj != "")
				GameBase::virtual(%obj, "clientKilled", %playerId, %killerId);
		}
	}
}

function Player::onKilled(%this)
{
	dbecho($dbechoMode, "Player::onKilled(" @ %this @ ")");

	//At this point, the client can still be queried for getItemCounts, and is also still an object
	//Player::Kill calls this function

	%clientId = Player::getClient(%this);
	
	// Validate clientId before proceeding
	if(%clientId == -1 || %clientId == "")
	{
		//echo("ERROR: Player::onKilled - Invalid clientId for player object " @ %this);
		return;
	}
	
	%killerId = fetchData(%clientId, "tmpkillerid");
	storeData(%clientId, "tmpkillerid", "");
	
	// Validate killerId - if invalid, set to 0 (no killer)
	if(%killerId == -1 || %killerId == "")
		%killerId = 0;

	//revert
	if(%clientId.possessId != "" && %clientId.possessId != -1)
	{
		Client::setControlObject(%clientId.possessId, %clientId.possessId);
		storeData(%clientId.possessId, "dumbAIflag", "");
		$possessedBy[%clientId.possessId] = "";
	}
	Client::setControlObject(%clientId, %clientId);

	%noDropFlag = fetchData(%clientId, "noDropLootbagFlag");
	%isJailed = %clientId.isJailed;
	%isDueling = Duel::isDueling(%clientId);
	
	if(%noDropFlag || %isJailed || %isDueling)
	{
		//do nothing
	}
	else
	{
		%tmploot = "";

		if(fetchData(%clientId, "COINS") > 0)
		{
			%coinsDrop = floor(fetchData(%clientId, "COINS"));
			%tmploot = SetStuffString(%tmploot, "COINS", %coinsDrop);
		}
		storeData(%clientId, "COINS", 0);

		%eitem = player::getMountedItem(%clientId, $WeaponSlot);
		if(%eitem != -1 && $preventDrop[%eitem] != true)
		{
			// Always prevent dropping CastingBlade - it's AI-only
			if(%eitem == CastingBlade)
			{
				// Skip mounted weapon handling for CastingBlade
			}
			else
			{
				%isAI = isRPGAI(%clientId);
				%shouldDropWeapon = true;
				%weaponDropRoll = true; // Track if drop chance passed for AI bots
				
				%player = Client::getOwnedObject(%clientId);
				if(%player != -1)
				{
					// Get current weapon count
					%eamnt = Player::getItemCount(%clientId, %eitem);
					
					// For AI bots, check if weapon was picked up from lootbags (stacked beyond original)
					// Also check if weapon has a custom drop rate percentage
					%originalWeaponCount = 0;
					%hasExtras = false;
					%weaponDropPercentage = ""; // Will store percentage format if found
					%defaultDropRate = 15; // Default 15% drop rate
					
					if(%isAI && %eamnt > 0)
					{
						%originalLootString = fetchData(%clientId, "OriginalLootString");
						if(%originalLootString != "")
						{
							// Search for weapon in original loot string
							// Skip known non-item keywords: CLASS, LVL, COINS, REMORT, LCK, TOURNYRANK, RankPoints, EXP, AI, CNT, CNTAFFECTS, LVLG, LVLS, LVLE
							for(%k = 0; GetWord(%originalLootString, %k) != -1; %k += 2)
							{
								%origItem = GetWord(%originalLootString, %k);
								
								// Skip known non-item keywords
								if(%origItem == "CLASS" || %origItem == "LVL" || %origItem == "COINS" || %origItem == "REMORT" || 
								   %origItem == "LCK" || %origItem == "TOURNYRANK" || %origItem == "RankPoints" || 
								   %origItem == "EXP" || %origItem == "AI" || %origItem == "CNT" || %origItem == "CNTAFFECTS" || 
								   %origItem == "LVLG" || %origItem == "LVLS" || %origItem == "LVLE")
									continue;
								
								if(%origItem == %eitem)
								{
									%originalCountStr = GetWord(%originalLootString, %k + 1);
									// Extract count (e.g., "1" from "1/30" or just "1")
									%spos = String::findSubStr(%originalCountStr, "/");
									if(%spos > 0)
									{
										%originalWeaponCount = floor(String::getSubStr(%originalCountStr, 0, %spos));
										// Store the percentage format for drop rate calculation
										%weaponDropPercentage = String::getSubStr(%originalCountStr, %spos+1, 99999);
									}
									else
									{
										%originalWeaponCount = floor(%originalCountStr);
									}
									break;
								}
							}
							
							// If bot has more than original count, it picked up extras from lootbags
							if(%eamnt > %originalWeaponCount)
							{
								%hasExtras = true;
							}
						}
					}
					
					// For AI bots, roll the drop rate (use custom percentage if defined, otherwise default 15%)
					if(%isAI)
					{
						%dropChance = %defaultDropRate; // Default to 15%
						%useCustomRate = false;
						
						// Check if weapon has a custom drop rate percentage
						if(%weaponDropPercentage != "")
						{
							// Use the same drop rate logic from rpgfunk.cs
							%rangePos = String::findSubStr(%weaponDropPercentage, "-");
							%firstChar = String::getSubStr(%weaponDropPercentage, 0, 1);
							
							if(%rangePos > 0 && %firstChar != "-")
							{
								// Variable drop rate range (e.g., 10-15% means roll between 10% and 15%)
								%minPerc = String::getSubStr(%weaponDropPercentage, 0, %rangePos);
								%maxPerc = String::getSubStr(%weaponDropPercentage, %rangePos + 1, 99999);
								
								// Randomly choose a drop chance within the range
								%dropChance = %minPerc + floor(getRandom() * (%maxPerc - %minPerc + 1));
								if(%dropChance > %maxPerc) %dropChance = %maxPerc;
								%useCustomRate = true;
							}
							else if(%weaponDropPercentage < 0)
							{
								// Negative percentages indicate rare drops (low chance)
								%absPerc = -%weaponDropPercentage;  // Convert -100 to 100
								%roll = floor(getRandom() * 100) + 1;  // Roll 1-100
								
								// For -100, need roll of 100 (1% chance)
								// For -50, need roll >= 51 (50% chance)
								// Formula: need roll >= (100 - absPerc + 1), but for absPerc >= 100, need exact 100
								%minRoll = 100 - %absPerc + 1;
								if(%absPerc >= 100) %minRoll = 100;  // -100 or more rare -> need exactly 100 (1% chance)
								
								if(%roll >= %minRoll)
									%shouldDropWeapon = true;
								else
								{
									%shouldDropWeapon = false;
									%weaponDropRoll = false;
								}
								%useCustomRate = true;
							}
							else
							{
								// Single fixed percentage (e.g., 5% or 10%)
								%dropChance = %weaponDropPercentage;
								%useCustomRate = true;
							}
						}
						
						// Roll the drop chance (if not already rolled for negative percentages)
						if(!%useCustomRate || %weaponDropPercentage >= 0)
						{
							%roll = floor(getRandom() * 100) + 1;  // Roll 1-100
							
							if(%roll <= %dropChance)
							{
								%shouldDropWeapon = true;
								%weaponDropRoll = true;
							}
							else
							{
								%shouldDropWeapon = false;
								%weaponDropRoll = false;
							}
						}
					}
					
					// Determine what to drop
					%weaponDropCount = 0;
					%ammoDropCount = 0;
					
					if(%shouldDropWeapon)
					{
						// Drop chance passed (or not AI bot) - drop full current count
						%weaponDropCount = %eamnt;
					}
					else if(%isAI && %hasExtras)
					{
						// Drop chance failed BUT bot has extras from lootbags - drop only the extras
						%weaponDropCount = %eamnt - %originalWeaponCount;
					}
					
					// Handle ammo drop
					if(%weaponDropCount > 0 && fetchData(%clientId, "LoadedProjectile " @ %eitem) != "")
					{
						%eammo = fetchData(%clientId, "LoadedProjectile " @ %eitem);
						if((%ammoCount = player::getItemCount(%clientId, %eammo)))
						{
							// For AI bots, always drop ammo if weapon is dropping (ignore LCK)
							// For players, use normal LCK logic
							if(%isAI || fetchData(%clientId, "LCK") <= 0)
							{
								if(!%isAI)
									Player::setItemCount(%clientId, %eammo, 0);
								
								%ammoDropCount = %ammoCount;
								%tmploot = SetStuffString(%tmploot, %eammo, %ammoDropCount);
							}
							else
								Player::setItemCount(%clientId, %eammo, %ammoCount);
						}				
					}
					
					// Handle weapon drop
					if(%weaponDropCount > 0)
					{
						// For AI bots, always drop weapon if drop chance passed or has extras (ignore LCK)
						// For players, use normal LCK logic
						if(%isAI || fetchData(%clientId, "LCK") <= 0)
						{
							if(!%isAI && %player != -1)
								Player::setItemCount(%clientId, %eitem, %eamnt - %weaponDropCount);
							%tmploot = SetStuffString(%tmploot, %eitem, %weaponDropCount);
						}
					}
				}
				else
				{
					// No player object - can't get weapon count
				}
			}
		}
		
		%max = getNumItems();
		for(%i = 0; %i < %max; %i++)
		{
			%a = getItemData(%i);
			%itemcount = Player::getItemCount(%clientId, %a);

			if(%itemcount)
			{
				// Skip the mounted weapon - it's already handled above
				if(%a == %eitem)
				{
					continue;
				}
				
				%flag = false;
				%lck = fetchData(%clientId, "LCK");

				if(%lck <= 0)
				{
					// When LCK <= 0, drop everything except protected items
					%flag = true;
					
					if($preventDrop[%a] == true)
					{
						%flag = false;
					}
					else if(%a.className == "Equipped")
					{
						%flag = false;
					}
					else if(%a.description == fetchData(%clientId, "eArmor") || %a.description == fetchData(%clientId, "eHelm"))
					{
						%flag = false;
					}
				}
				else
				{
					// When LCK > 0, only drop equipped items and lore items (mounted weapon is handled separately above)
					if(%a.className == "Equipped" || $LoreItem[%a] == True)
					{
						%flag = true;
					}
				}
				
				// Always prevent dropping CastingBlade
				if(%a == CastingBlade)
				{
					%flag = false;
				}

				if(%flag)
				{
					%b = %a;
					if(%b.className == "Equipped")
						%b = String::getSubStr(%b, 0, String::len(%b)-1);

					%tmploot = SetStuffString(%tmploot, %b, Player::getItemCount(%clientId, %a));
					
					if(!isRPGAI(%clientId))	
						Player::setItemCount(%clientId, %a, 0);
				}
			}
		}
		
		// Add belt items (quest items, key items, etc.) to loot
		// IMPORTANT: Only equipped belt items should drop, NOT stored items
		// Equipped belt items: All categories from $Belt::Categories array
		// Stored belt items (NOT dropped): StoredQuestItems, StoredKeyItems, BeltStorage, StoredConsumables, StoredArmor, StoredAccessories, StoredOther
		// Build beltCategories from $Belt::Categories array to include all categories
		%beltCategories = "";
		for(%i = 1; $Belt::Categories[%i] != ""; %i++)
		{
			%cat = $Belt::Categories[%i];
			if(%beltCategories != "")
				%beltCategories = %beltCategories @ " " @ %cat;
			else
				%beltCategories = %cat;
		}

		// Get original loot string with percentage chances for AI bots
		%originalLootString = "";
		if(isRPGAI(%clientId))
		{
			%originalLootString = fetchData(%clientId, "OriginalLootString");
		}

		for(%catIdx = 0; (%category = getWord(%beltCategories, %catIdx)) != -1; %catIdx++)
		{
			// Only read from equipped belt categories - never from stored items (StoredQuestItems, StoredKeyItems, BeltStorage, StoredConsumables, StoredArmor, StoredAccessories, StoredOther)
			// Safety check: ensure we're only processing equipped categories, not stored ones
			if(%category == "StoredQuestItems" || %category == "StoredKeyItems" || %category == "BeltStorage" || %category == "StoredConsumables" || %category == "StoredArmor" || %category == "StoredAccessories" || %category == "StoredOther")
			{
				//echo("ERROR: Player::onKilled - Attempted to drop stored belt items! Category: " @ %category);
				continue; // Skip stored items - they should never be dropped
			}
			
			%beltList = fetchData(%clientId, %category);
			
			for(%j = 0; (%beltItemName = getWord(%beltList, %j)) != -1; %j += 2)
			{
				%beltItemCount = getWord(%beltList, %j + 1);
				
				// Skip invalid entries (item is "0", empty, or count <= 0)
				if(%beltItemName == "" || %beltItemName == -1 || %beltItemName == "0" || %beltItemCount <= 0)
					continue;
				
				// Get registered item name for proper lookup
				%registeredItemName = %beltItemName;
				if($BeltItem[%beltItemName, "Item"] != "")
					%registeredItemName = $BeltItem[%beltItemName, "Item"];
				
				// CRITICAL SAFETY CHECK: Verify this item is NOT in storage before even processing
				// Check ALL storage locations with BOTH the raw name and registered name
				%beltStorage = fetchData(%clientId, "BeltStorage");
				%storedQuest = fetchData(%clientId, "StoredQuestItems");
				%storedKey = fetchData(%clientId, "StoredKeyItems");
				
				// Check with raw item name
				%storedCount1 = Belt::ItemCount(%beltItemName, %beltStorage);
				%storedQuestCount1 = Belt::ItemCount(%beltItemName, %storedQuest);
				%storedKeyCount1 = Belt::ItemCount(%beltItemName, %storedKey);
				
				// Check with registered item name (if different)
				%storedCount2 = 0;
				%storedQuestCount2 = 0;
				%storedKeyCount2 = 0;
				if(%registeredItemName != %beltItemName)
				{
					%storedCount2 = Belt::ItemCount(%registeredItemName, %beltStorage);
					%storedQuestCount2 = Belt::ItemCount(%registeredItemName, %storedQuest);
					%storedKeyCount2 = Belt::ItemCount(%registeredItemName, %storedKey);
				}
				
				%totalStoredCount = %storedCount1 + %storedQuestCount1 + %storedKeyCount1 + %storedCount2 + %storedQuestCount2 + %storedKeyCount2;
				
				// If item exists in storage, this is just informational - equipped and stored are separate locations
				// All equipped items should drop (they're in your belt/inventory), stored items remain safe in storage
				if(%totalStoredCount > 0)
				{
					%clientName = Client::getName(%clientId);
					//echo("INFO: Player::onKilled - Item '" @ %beltItemName @ "' (registered: '" @ %registeredItemName @ "') exists in BOTH equipped (" @ %category @ ") AND storage. ClientId: " @ %clientId @ " (" @ %clientName @ ")");
					//echo("  Equipped count: " @ %beltItemCount @ " (will drop), Total stored count: " @ %totalStoredCount @ " (protected in storage)");
					//echo("  Stored by raw name: BeltStorage=" @ %storedCount1 @ ", StoredQuestItems=" @ %storedQuestCount1 @ ", StoredKeyItems=" @ %storedKeyCount1);
					//echo("  Stored by registered name: BeltStorage=" @ %storedCount2 @ ", StoredQuestItems=" @ %storedQuestCount2 @ ", StoredKeyItems=" @ %storedKeyCount2);
					//echo("  Dropping all " @ %beltItemCount @ " equipped items - stored items remain safe");
					// Continue processing - drop all equipped items, stored items are separate and protected
				}
				
				if(%beltItemCount > 0)
				{
					// Check drop rate for this item
					%shouldDrop = true;
					%dropCount = %beltItemCount;
					
					if(isRPGAI(%clientId))
					{
						// For AI bots: Roll the drop rate NOW (it was skipped on spawn)
						// Look up the item in OriginalLootString to get the percentage format
						%originalCountStr = "";
						%originalItemName = "";
						
						if(%originalLootString != "")
						{
							// Search for this item in the original loot string
							// Skip known non-item keywords: CLASS, LVL, COINS, REMORT, LCK, TOURNYRANK, RankPoints, EXP, AI, CNT, CNTAFFECTS, LVLG, LVLS, LVLE
							for(%k = 0; GetWord(%originalLootString, %k) != -1; %k += 2)
							{
								%origItem = GetWord(%originalLootString, %k);
								
								// Skip known non-item keywords
								if(%origItem == "CLASS" || %origItem == "LVL" || %origItem == "COINS" || %origItem == "REMORT" || 
								   %origItem == "LCK" || %origItem == "TOURNYRANK" || %origItem == "RankPoints" || 
								   %origItem == "EXP" || %origItem == "AI" || %origItem == "CNT" || %origItem == "CNTAFFECTS" || 
								   %origItem == "LVLG" || %origItem == "LVLS" || %origItem == "LVLE")
									continue;
								
								// Check both registered name and raw name
								if(%origItem == %registeredItemName || %origItem == %beltItemName)
								{
									%originalCountStr = GetWord(%originalLootString, %k + 1);
									%originalItemName = %origItem;
									break;
								}
							}
						}
						
						// If found in OriginalLootString, check if it has a percentage format
						if(%originalCountStr != "")
						{
							%spos = String::findSubStr(%originalCountStr, "/");
							if(%spos > 0)
							{
								// Has percentage format (e.g., "1/30")
								%original = String::getSubStr(%originalCountStr, 0, %spos);
								%perc = String::getSubStr(%originalCountStr, %spos+1, 99999);
								
								// Use the same drop rate logic from rpgfunk.cs
								%rangePos = String::findSubStr(%perc, "-");
								%firstChar = String::getSubStr(%perc, 0, 1);
								
								if(%rangePos > 0 && %firstChar != "-")
								{
									// Variable drop rate range (e.g., 10-15% means roll between 10% and 15%)
									%minPerc = String::getSubStr(%perc, 0, %rangePos);
									%maxPerc = String::getSubStr(%perc, %rangePos + 1, 99999);
									
									// Randomly choose a drop chance within the range
									%chance = %minPerc + floor(getRandom() * (%maxPerc - %minPerc + 1));
									if(%chance > %maxPerc) %chance = %maxPerc;
									
									%roll = floor(getRandom() * 100) + 1;  // Roll 1-100
									
									if(%roll <= %chance)
										%shouldDrop = true;
									else
										%shouldDrop = false;
								}
								else if(%perc < 0)
								{
									// Negative percentages indicate rare drops (low chance)
									%absPerc = -%perc;  // Convert -100 to 100
									%roll = floor(getRandom() * 100) + 1;  // Roll 1-100
									
									// For -100, need roll of 100 (1% chance)
									// For -50, need roll >= 51 (50% chance)
									// Formula: need roll >= (100 - absPerc + 1), but for absPerc >= 100, need exact 100
									%minRoll = 100 - %absPerc + 1;
									if(%absPerc >= 100) %minRoll = 100;  // -100 or more rare -> need exactly 100 (1% chance)
									
									if(%roll >= %minRoll)
										%shouldDrop = true;
									else
										%shouldDrop = false;
								}
								else
								{
									// Single fixed percentage (e.g., 5% or 10%)
									%roll = floor(getRandom() * 100) + 1;  // Roll 1-100
									
									if(%roll <= %perc)
										%shouldDrop = true;
									else
										%shouldDrop = false;
								}
							}
							else
							{
								// No percentage format - guaranteed drop (100%)
								%shouldDrop = true;
							}
						}
						else
						{
							// Item not in OriginalLootString - likely picked up from lootbag, drop 100%
							%shouldDrop = true;
						}
					}
					else
					{
						// For players: items in their belt should drop 100% on death
						// (they've already passed drop rate checks when acquired)
						// Only items picked up from lootbags are in equipped belt
						%shouldDrop = true;
					}
					
					// Drop the items if drop rate check passed
					if(%shouldDrop && %beltItemCount > 0)
					{
						// Use registered item name for loot
						%lootItemName = %registeredItemName;
						%tmploot = SetStuffString(%tmploot, %lootItemName, %beltItemCount);
					}
				}
			}
			// Clear the equipped belt items from the dead player/bot
			// IMPORTANT: Only clear equipped items, NEVER clear stored items (StoredQuestItems, StoredKeyItems, BeltStorage, StoredConsumables, StoredArmor, StoredAccessories, StoredOther)
			// Stored items should remain safe in storage even after death
			// Check if this is an equipped category (exists in $Belt::Categories array)
			%isEquippedCategory = false;
			for(%k = 1; $Belt::Categories[%k] != ""; %k++)
			{
				if($Belt::Categories[%k] == %category)
				{
					%isEquippedCategory = true;
					break;
				}
			}
			
			if(%isEquippedCategory)
			{
				storeData(%clientId, %category, "");
				// CRITICAL: After clearing, use Belt::GetNS to ensure category is truly empty
				// This prevents corrupted data that looks valid (e.g., "MinotaurHorn 12") from persisting
				// Belt::GetNS will clean up any remaining corrupted entries
				if(!isRPGAI(%clientId))
				{
					%nsResult = Belt::GetNS(%clientId, %category);
					%cleanedList = fetchData(%clientId, %category);
					// If GetNS found any items (should be empty after death), clear them
					if(%cleanedList != "" && %cleanedList != "0")
					{
						%clientName = Client::getName(%clientId);
						//echo("WARNING: Player::onKilled - Found items in " @ %category @ " after clearing! Clearing again. ClientId: " @ %clientId @ " (" @ %clientName @ ")");
						//echo("  Found: '" @ %cleanedList @ "'");
						storeData(%clientId, %category, "");
					}
				}
			}
			else
			{
				// Safety check: never clear stored items
				//echo("ERROR: Player::onKilled - Attempted to clear stored belt items! Category: " @ %category);
			}
		}
		
		// CRITICAL FIX: Save character immediately after clearing equipped items to prevent duplication
		// This ensures the cleared equipped items are saved before the player can pick up their lootbag
		// If SaveCharacter runs after the player picks up their lootbag, it would save the restored items
		// Only save for players, not AI bots
		if(!isRPGAI(%clientId))
		{
			// Save immediately after clearing equipped items (with small delay to ensure clears are processed)
			schedule("SaveCharacter(" @ %clientId @ ");", 0.1, %clientId);
		}

		if(%tmploot != "")
		{
			if(isRPGAI(%clientId))
			{
				TossLootbag(%clientId, %tmploot, 1, "*", 300);
			}
			else
			{
				%namelist = Client::getName(%clientId) @ ",";
				if(fetchData(%clientId, "LCK") >= 0)
				{
					TossLootbag(%clientId, %tmploot, 5, %namelist, Cap(fetchData(%clientId, "LVL") * 300, 300, 3600));
				}
				else
					TossLootbag(%clientId, %tmploot, 5, %namelist, Cap(fetchData(%clientId, "LVL") * 0.2, 5, "inf"));
			}
		}
	}


	updateSpawnStuff(%clientId);

	//house stuff
	%victimH = fetchData(%clientId, "MyHouse");
	%killerH = "";
	%khn = "";
	if(%killerId > 0)
	{
		%killerH = fetchData(%killerId, "MyHouse");
		%khn = $House::Index[%killerH];
	}
	%vhn = $House::Index[%victimH];
	if(%vhn != "")
	{
		//a house member is killed

		if(fetchData(%clientId, "LCK") < 0)
		{
			//this house member had no LCK at time of death

			if(fetchData(%clientId, "RankPoints") <= 0)
			{
				//no LCK and no Rank Points! you're booted!
				BootFromCurrentHouse(%clientId, true);
			}
			else
			Client::sendMessage(%clientId, $MsgRed, "You have lost all your Rank Points because you died with 0 LCK!");

			storeData(%clientId, "RankPoints", 0);
		}

		//victim loses two rank points
		Client::sendMessage(%clientId, $MsgWhite, "You lost 2 Rank Points.");
		storeData(%clientId, "RankPoints", 2, "dec");

		if(%killerId > 0 && %khn != "")
		{
			if(%khn != %vhn)
			{
				//both contenders are in a house, different from each other
				Client::sendMessage(%killerId, $MsgWhite, "You gained 1 Rank Point!");
				storeData(%killerId, "RankPoints", 1, "inc");
			}
			else
			{
				//both contenders are in the same house, happens if one target-lists the other.
				Client::sendMessage(%killerId, $MsgWhite, "You lost 1 Rank Point.");
				storeData(%killerId, "RankPoints", 1, "dec");
			}
		}
	}
	else if(%vhn == "" && %killerId > 0 && %khn != "")
	{
		//a house member killed a non-house member. no bonuses or punishments
	}
	
	// Save current zone to lastzone BEFORE it gets cleared (for respawn location)
	// If player dies during seal battle in Colloseum, don't set lastzone to Colloseum
	// (Colloseum may not have DropPoints, causing air spawns)
	%currentZone = fetchData(%clientId, "zone");
	if($SealBattleActive && !isRPGAI(%clientId))
	{
		%clZoneDesc = Zone::getDesc(%currentZone);
		if(%clZoneDesc == "Colloseum")
		{
			// Don't set lastzone to Colloseum - let them spawn at default location, then teleport to recall
			// This prevents spawning in the air if Colloseum has no DropPoints
			storeData(%clientId, "lastzone", "");
			// Schedule recall after respawn (respawn happens after $AutoRespawn delay)
			schedule("FellOffMap(" @ %clientId @ ");", $AutoRespawn + 0.5, %clientId);
		}
		else
		{
			storeData(%clientId, "lastzone", %currentZone);
		}
	}
	else
	{
		storeData(%clientId, "lastzone", %currentZone);
	}
	
	if(!isRPGAI(%clientId) && fetchData(%clientId, "LCK") < 0)
		storeData(%clientId, "zone", "");
	
	%zoneType = Zone::getType(fetchData(%clientId, "zone"));
	if(%zoneType == "COLLECT" || %zoneType == "DISPLAY" || %zoneType == "CONTROL")
		storeData(%clientId, "zone", "");
	
	if(fetchData(%clientId, "deathmsg") != "")
	{
		%killerName = "";
		%kitemDesc = "";
		if(%killerId > 0)
		{
			%killerName = Client::getName(%killerId);
			%kitem = Player::getMountedItem(%killerId, $WeaponSlot);
			if(%kitem != -1 && %kitem != "")
			{
				%kitemDesc = %kitem.description;
				if(%kitemDesc == "")
					%kitemDesc = "Unknown";
			}
			else
			{
				%kitemDesc = "Unknown";
			}
		}
		else
		{
			%killerName = "Unknown";
			%kitemDesc = "Unknown";
		}
		%msg = nsprintf(fetchData(%clientId, "deathmsg"), %killerName, Client::getName(%clientId), %kitemDesc);
		remoteSay(%clientId, 0, %msg);
	}

	if(isRPGAI(%clientId))
	{
		//Check to see if it was a summoned
		if(getWord(fetchData(%clientId, "Summoner"), 0) != -1)
			Summon::Release(%clientId);
	
		//event stuff
		%i = GetEventCommandIndex(%clientId, "onkill");
		if(%i != -1)
		{
			%name = GetWord($EventCommand[%clientId, %i], 0);
			%type = GetWord($EventCommand[%clientId, %i], 1);
			%cl = NEWgetClientByName(%name);
			if(%cl == -1)
			%cl = 2048;

			%cmd = String::NEWgetSubStr($EventCommand[%clientId, %i], String::findSubStr($EventCommand[%clientId, %i], ">")+1, 99999);
			%pcmd = ParseBlockData(%cmd, %clientId, %killerid);
			$EventCommand[%clientId, %i] = "";
			schedule("remoteSay(" @ %cl @ ", 0, \"" @ %pcmd @ "\", \"" @ %name @ "\");", 2);
		}
		ClearEvents(%clientId);
	}

	storeData(%clientId, "noDropLootbagFlag", "");

	storeData(%clientId, "SpellCastStep", "");
	%clientId.sleepMode = "";
	refreshHPREGEN(%clientId);
	refreshMANAREGEN(%clientId);

	Client::setControlObject(%clientId, %clientId);
	storeData(%clientId, "dumbAIflag", "");

	PlaySound(RandomRaceSound(fetchData(%clientId, "RACE"), Death), GameBase::getPosition(%clientId));

	//========================================================================================================================

	%clientId.dead = 1;
	if($AutoRespawn > 0)
	schedule("Game::autoRespawn(" @ %clientId @ ");",$AutoRespawn,%clientId);

	if(fetchData(%clientId, "flashMode"))
		Player::setDamageFlash(%this, 0.75);

	if(%clientId != -1)
	{
		if(%this.vehicle != "")
		{
			if(%this.driver != "")
			{
				%this.driver = "";
				Client::setControlObject(Player::getClient(%this), %this);
				Player::setMountObject(%this, -1, 0);
			}
			else
			{
				%this.vehicle.Seat[%this.vehicleSlot-2] = "";
				%this.vehicleSlot = "";
			}
			%this.vehicle = "";
		}
		schedule("GameBase::startFadeOut(" @ %this @ ");", $CorpseTimeoutValue, %this);
		Client::setOwnedObject(%clientId, -1);
		Client::setControlObject(%clientId, Client::getObserverCamera(%clientId));
		Observer::setOrbitObject(%clientId, %this, 15, 15, 15);
		schedule("deleteObject(" @ %this @ ");", $CorpseTimeoutValue + 2.5, %this);
		%clientId.observerMode = "dead";
		%clientId.dieTime = getSimTime();
		
		// Save character and world after death to prevent lootbag duplication on server crash
		// NOTE: SaveCharacter is already called immediately after clearing equipped items (see above)
		// This is just a backup save in case the first one didn't complete
		// Only save for players, not AI bots
		if(!isRPGAI(%clientId))
		{
			// Backup character save after 2 second delay (in case first save didn't complete)
			schedule("SaveCharacter(" @ %clientId @ ");", 2, %clientId);
			
			// Save world after 3 second delay (allows character saves to complete first)
			schedule("SaveWorld();", 3, %clientId);
		}
	}
}

function Player::onDamage(%this,%type,%value,%pos,%vec,%mom,%vertPos,%rweapon,%object,%weapon,%preCalcMiss)
{
	dbecho($dbechoMode, "Player::onDamage(" @ %this @ ", " @ %type @ ", " @ %value @ ", " @ %pos @ ", " @ %vec @ ", " @ %mom @ ", " @ %vertPos @ ", " @ %rweapon @ ", " @ %object @ ", " @ %weapon @ ", " @ %preCalcMiss @ ")");

	%skilltype = $SkillType[%weapon];

	if(%object != -1 && %type != $NullDamageType && !Player::IsDead(%this))
	{	
		%damagedClient = Player::getClient(%this);
		
		// For AI bots, Player::getClient(%this) returns -1
		// In the RPG system, AI bots use their Player object (%this) as their "client ID"
		// So if %damagedClient is -1, use %this directly as the client ID for AI bots
		if(%damagedClient == -1 || %damagedClient == "")
		{
			%damagedClient = %this; // AI bot - use Player object as client ID
		}
		
		// %object is the shooter's client ID (for players) or Player object (for AI shooters)
		// For spell damage, %object might be a client ID, so try to get the Player object
		%shooterClient = %object;
		if(isObject(%object))
		{
			%objectType = getObjectType(%object);
			if(%objectType == "Player")
			{
				// %object is a Player object - get its client ID if it's a player, or use %object directly if it's a bot
				%shooterClientId = Player::getClient(%object);
				if(%shooterClientId != -1 && %shooterClientId != "")
					%shooterClient = %shooterClientId;
				else
					%shooterClient = %object; // AI bot shooter - use Player object as client ID
			}
		}
		
		%damagedClientPos = GameBase::getPosition(%damagedClient);
		%shooterClientPos = GameBase::getPosition(%shooterClient);

		%damagedCurrentArmor = GetCurrentlyWearingArmor(%damagedClient);

		//==============
		//PROCESS STATS
		//==============
		%isMiss = false;
		%Pierce = false;
		%Bash = false;
		%Cleave = false;
		%sameTeamNull = false;

		//------------- CREATE DAMAGE VALUE -------------
		if(%type == $SpellDamageType)
		{
			//For the case of SPELLS, the initial damage has already been determined before calling this function

			%dmg = %value;
			%skillValue = $PlayerSkill[%shooterClient, %skilltype];
			if(%skillValue == "" || %skillValue == -1)
				%skillValue = 1000; // Default skill value if not set (for NPCs or edge cases)
			
			%value = round((%dmg * %skillValue) / 1000);

			%ab = (getRandom() * (fetchData(%damagedClient, "MDEF") / 10)) + 1;
			%value = Cap(%value - %ab, 0, "inf");

			%value = (%value / $TribesDamageToNumericDamage);
			
		}
		else if(%type != $LandingDamageType)
		{
			// Check if shooter is a turret - turrets use projectile base damage, not physical damage formula
			%isTurretDamage = false;
			if(isObject(%object))
			{
				%objectClassName = %object.className;
				if(%objectClassName == "Turret")
					%isTurretDamage = true;
			}
			
			// Also detect turret projectiles by checking if it's MissileDamageType from a source without skills/ATK
			// Turrets use MissileDamageType projectiles but don't have player skills or ATK
			if(!%isTurretDamage && %type == $MissileDamageType)
			{
				// Check if shooter doesn't have ATK or skills (indicating it's a turret, not a player)
				%shooterATK = fetchData(%shooterClient, "ATK");
				if((%shooterATK == "" || %shooterATK == -1 || %shooterATK == 0) && (%skilltype == "" || $PlayerSkill[%shooterClient, %skilltype] == ""))
				{
					// Check if it's not a vehicle projectile (vehicles are handled separately)
					%shooterPlayerObj = Client::getOwnedObject(%shooterClient);
					%isVehicle = false;
					if(%shooterPlayerObj != -1)
					{
						%shooterType = getObjectType(%shooterPlayerObj);
						// Check if shooter object IS a vehicle/flier
						if(%shooterType == "Vehicle" || %shooterType == "Flier")
							%isVehicle = true;
						// Also check if player is IN a vehicle (for when player fires from vehicle)
						if(!%isVehicle && %shooterPlayerObj.vehicle != "")
							%isVehicle = true;
					}
					// If not a vehicle and no ATK/skills, it's likely a turret
					if(!%isVehicle)
						%isTurretDamage = true;
				}
			}
			
			// For turret damage, use the projectile's base damage value directly
			// Turrets don't have ATK, weapons, or skills, so we can't use the physical damage formula
			if(%isTurretDamage)
			{
				// Use the projectile's damageValue (from baseProjData.cs)
				// FusionBolt, GuardianBolt, etc. have damageValue = 1 (in Tribes damage units)
				// Convert from Tribes damage to numeric damage
				// Turret projectiles typically have damageValue = 1, which needs to be scaled appropriately
				%baseTurretDamage = 100; // Base turret damage in Tribes damage units (equivalent to 100 damage)
				
				// Scale turret damage with player level to keep threat consistent across all levels
				// Higher level players have more DEF and HP, so we scale base damage to compensate
				// Formula: baseDamage * (1 + (level / 100))
				// This means: Level 0 = 1x, Level 100 = 2x, Level 200 = 3x, Level 500 = 6x
				%playerLevel = fetchData(%damagedClient, "LVL");
				if(%playerLevel == "" || %playerLevel == -1)
					%playerLevel = 1;
				%levelMultiplier = 1 + (%playerLevel / 100);
				%scaledTurretDamage = %baseTurretDamage * %levelMultiplier;
				%value = %scaledTurretDamage;
				
				// Apply DEF reduction (turrets should still respect DEF)
				// Higher level players have more DEF, which naturally reduces the scaled damage
				%ab = (getRandom() * (fetchData(%damagedClient, "DEF") / 10)) + 1;
				%value = Cap(%value - %ab, 1, "inf");
				
				// Add random variation (±15%)
				%a = (%value * 0.15);
				%r = round((getRandom() * (%a*2)) - %a);
				%value += %r;
				if(%value < 1)
					%value = 1;
				
				// Convert from Tribes damage to numeric damage
				%value = (%value / $TribesDamageToNumericDamage);
			}
			else
			{
				%multi = 1;

				if(fetchData(%damagedClient, "invisible"))
				{
					UnHide(%damagedClient);
				}			

				//Bash
			if(fetchData(%shooterClient, "NextHitBash"))
			{
				if(%skilltype == $SkillBludgeoning)
				{
					%multi += $PlayerSkill[%shooterClient, $SkillBashing] / 470;
					%b = GameBase::getRotation(%shooterClient);
					%c = $PlayerSkill[%shooterClient, $SkillBashing] / 15;
					%Bash = true;
				}

				%delay = Cap(360 - ($PlayerSkill[%shooterClient, $SkillBashing] / 100), 30, 360);
				schedule("storeData(" @ %shooterClient @ ", \"blockBash\", \"\");", %delay);
				storeData(%shooterClient, "NextHitBash", "");
			}
	
			//Pierce
			if(fetchData(%shooterClient, "NextHitPierce"))
			{
				if(%skilltype == $SkillPiercing)
				{
					%multi += $PlayerSkill[%shooterClient, $SkillPiercing] / 470;
					%Pierce = true;
				}
				
				%delay = Cap(360 - ($PlayerSkill[%shooterClient, $SkillPiercing] / 100), 30, 360);
				schedule("storeData(" @ %shooterClient @ ", \"blockPierce\", \"\");", %delay);
				storeData(%shooterClient, "NextHitPierce", "");				
			}
			
			//Cleave
			if(fetchData(%shooterClient, "NextHitCleave"))
			{
				if(%skilltype == $SkillSlashing)
				{
					%multi += $PlayerSkill[%shooterClient, $SkillSlashing] / 470;
					%Cleave = true;
				}

				%delay = Cap(360 - ($PlayerSkill[%shooterClient, $SkillSlashing] / 100), 30, 360);
				schedule("storeData(" @ %shooterClient @ ", \"blockCleave\", \"\");", %delay);
				storeData(%shooterClient, "NextHitCleave", "");
			}			

			if(%rweapon != "")
				%rweapondamage = GetRoll(GetWord(GetAccessoryVar(%rweapon, $SpecialVar), 1));
			else
				%rweapondamage = 0;
			%weapondamage = GetRoll(GetWord(GetAccessoryVar(%weapon, $SpecialVar), 1));

			%playerattack = fetchData(%shooterClient, "ATK") - %weapondamage;
			%skillValue = $PlayerSkill[%shooterClient, %skilltype];
			if(%skillValue == "" || %skillValue == -1)
				%skillValue = 1000; // Default skill value if not set (for NPCs or edge cases)
			%value = round((( (%weapondamage + (%playerattack + %rweapondamage)) / 1000) * %skillValue) * %multi);

			%ab = (getRandom() * (fetchData(%damagedClient, "DEF") / 10)) + 1;
			%value = Cap(%value - %ab, 1, "inf");

			%a = (%value * 0.15);
			%r = round((getRandom() * (%a*2)) - %a);
			%value += %r;
			if(%value < 1)
			%value = 1;

			if(%Bash)	//i'm doing this condition here because %mom is dependant on %value
			{
				%c1 = ( %c / 15 * %value );
				%c2 = %c2 / 10;
				%mom = Vector::getFromRot( %b, %c1, %c2 );
			}

			// Vehicle Combat skill bonus: +1 damage per 100 skill points (capped at 1000 = +10 damage)
			// Check if this is a vehicle projectile
			%isVehicleProjectile = false;
			
			// Get the shooter's player object to check if it's a vehicle
			%shooterPlayerObj = Client::getOwnedObject(%shooterClient);
			if(%shooterPlayerObj != -1)
			{
				%shooterType = getObjectType(%shooterPlayerObj);
				// Check if it's a vehicle object
				if(%shooterType == "Vehicle" || %shooterType == "Flier")
				{
					%isVehicleProjectile = true;
				}
			}
			// Also check if shooter is a client ID but the player is in a vehicle
			if(!%isVehicleProjectile && %type == $MissileDamageType && (%skilltype == "" || $PlayerSkill[%shooterClient, %skilltype] == ""))
			{
				// This is likely a vehicle projectile - check if player is in a vehicle
				%playerObj = Client::getOwnedObject(%shooterClient);
				if(%playerObj != -1 && %playerObj.vehicle != "")
				{
					%isVehicleProjectile = true;
				}
			}
			
			if(%isVehicleProjectile && !isRPGAI(%shooterClient))
			{
				// Get Vehicle Combat skill (Skill 14)
				%vehicleSkill = $PlayerSkill[%shooterClient, $SkillVehicleCombat];
				if(%vehicleSkill == "" || %vehicleSkill == -1)
					%vehicleSkill = 0;
				
				// Cap skill at 1000
				if(%vehicleSkill > 1000)
					%vehicleSkill = 1000;
				
				// Calculate bonus: +1 damage per 100 skill points
				%vehicleBonus = floor(%vehicleSkill / 100);
				
				// Add bonus to damage (in Tribes damage units, before conversion)
				%value += %vehicleBonus;
			}

			%value = (%value / $TribesDamageToNumericDamage);
			}
		}

		//------------- DETERMINE MISS OR HIT -------------
		if(%preCalcMiss == "")
		{
			if(%type != $LandingDamageType && %shooterClient != %damagedClient && %shooterClient != 0)
			{
				// Check if shooter is a vehicle - vehicles always hit (no miss calculation)
				%isVehicle = false;
				
				// Get the shooter's player object to check if it's a vehicle
				%shooterPlayerObj = Client::getOwnedObject(%shooterClient);
				if(%shooterPlayerObj != -1)
				{
					%shooterType = getObjectType(%shooterPlayerObj);
					// Check if it's a vehicle object
					if(%shooterType == "Vehicle" || %shooterType == "Flier")
					{
						%isVehicle = true;
					}
				}
				// Also check if shooter is a client ID but the player is in a vehicle
				// For vehicle projectiles, the engine might pass the controlling player's client ID
				// but we can detect this by checking if the skill type is invalid/empty
				// and the damage type is MissileDamageType (vehicle projectiles)
				if(!%isVehicle && %type == $MissileDamageType && (%skilltype == "" || $PlayerSkill[%shooterClient, %skilltype] == ""))
				{
					// This is likely a vehicle projectile - check if player is in a vehicle
					%playerObj = Client::getOwnedObject(%shooterClient);
					if(%playerObj != -1 && %playerObj.vehicle != "")
					{
						%isVehicle = true;
					}
				}
				
				if(%isVehicle)
				{
					// Vehicles always hit - skip miss calculation
					%isMiss = false;
				}
				else
				{
					// Normal player/weapon miss calculation
					if(%type == $SpellDamageType)
					{
						%defenderDEF = fetchData(%damagedClient, "MDEF");
						%defenderSkill = $PlayerSkill[%damagedClient, $SkillSpellResistance];
						if(%defenderSkill == "" || %defenderSkill == -1)
							%defenderSkill = 0;
						%x = (%defenderDEF / 5) + %defenderSkill + 5;
						%defenseType = "MDEF";
						%skillTypeName = "SpellResistance";
					}
					else
					{
						%defenderDEF = fetchData(%damagedClient, "DEF");
						%defenderSkill = $PlayerSkill[%damagedClient, $SkillDodging];
						if(%defenderSkill == "" || %defenderSkill == -1)
							%defenderSkill = 0;
						%x = (%defenderDEF / 5) + %defenderSkill + 5;
						%defenseType = "DEF";
						%skillTypeName = "Dodging";
					}
					%attackerSkill = $PlayerSkill[%shooterClient, %skilltype];
					if(%attackerSkill == "" || %attackerSkill == -1)
						%attackerSkill = 1000; // Default skill value if not set (for NPCs or edge cases)
					%y = %attackerSkill + 5;
					
					%n = %x + %y;
					
					%r = floor(getRandom() * %n) + 1;
					
					// Calculate hit/miss percentages
					%missChance = (%x / %n) * 100;
					%hitChance = (%y / %n) * 100;
					
					%attackerName = Client::getName(%shooterClient);
					if(%attackerName == "")
						%attackerName = "AI Bot";
					%defenderName = Client::getName(%damagedClient);
					if(%defenderName == "")
						%defenderName = "AI Bot";
					
					%initialMiss = false;
					if(%r <= %x)
					{
						%isMiss = true;
						%initialMiss = true;
					}
					
					// LCK-based miss check
					%lckMissChance = (AddPoints(%damagedClient, 2) / 100);
					%lckRoll = getRandom();
					%lckMiss = false;
					if(!%initialMiss && %lckRoll <= %lckMissChance)
					{
						%isMiss = true;
						%lckMiss = true;
					}
					
					// Get all defender stats for debug output
					%defenderDEFValue = fetchData(%damagedClient, "DEF");
					%defenderMDEFValue = fetchData(%damagedClient, "MDEF");
					%defenderDodgingSkill = $PlayerSkill[%damagedClient, $SkillDodging];
					if(%defenderDodgingSkill == "" || %defenderDodgingSkill == -1)
						%defenderDodgingSkill = 0;
					%defenderSpellResistanceSkill = $PlayerSkill[%damagedClient, $SkillSpellResistance];
					if(%defenderSpellResistanceSkill == "" || %defenderSpellResistanceSkill == -1)
						%defenderSpellResistanceSkill = 0;
					
					// Debug output for hit/miss calculation
					//echo("DEBUG HIT/MISS: " @ %attackerName @ " -> " @ %defenderName);
					%damageTypeName = "Physical";
					if(%type == $SpellDamageType)
						%damageTypeName = "Spell";
					//echo("  Damage Type: " @ %damageTypeName);
					//echo("  Defender Stats: DEF=" @ %defenderDEFValue @ ", MDEF=" @ %defenderMDEFValue @ ", Dodging=" @ %defenderDodgingSkill @ ", SpellResistance=" @ %defenderSpellResistanceSkill);
					//if(%type == $SpellDamageType)
					//	echo("  Defender Used: MDEF=" @ %defenderMDEFValue @ " (MDEF/5=" @ floor(%defenderMDEFValue / 5) @ "), SpellResistance=" @ %defenderSpellResistanceSkill @ ", Base=5");
					//else
					//	echo("  Defender Used: DEF=" @ %defenderDEFValue @ " (DEF/5=" @ floor(%defenderDEFValue / 5) @ "), Dodging=" @ %defenderDodgingSkill @ ", Base=5");
					//echo("  Attacker: Skill=" @ %attackerSkill @ " (type: " @ %skilltype @ "), Base=5");
					//echo("  Calculation: x=" @ %x @ " (defender), y=" @ %y @ " (attacker), n=" @ %n @ " (total)");
					//echo("  Roll: r=" @ %r @ " (1-" @ %n @ ")");
					// Only show miss % when a player is attacking a bot (not when bots attack players)
					//if(!isRPGAI(%shooterClient) && isRPGAI(%damagedClient))
					//	echo("Player " @ %attackerName @ " (ID: " @ %shooterClient @ ") attacking bot - Miss Chance: " @ floor(%missChance * 100) / 100 @ "%, Hit Chance: " @ floor(%hitChance * 100) / 100 @ "%");
					//if(%initialMiss)
					//	echo("  RESULT: MISS (r <= x: " @ %r @ " <= " @ %x @ ")");
					//else if(%lckMiss)
					//{
					//	echo("  RESULT: MISS (LCK check: roll " @ floor(%lckRoll * 10000) / 10000 @ " <= " @ floor(%lckMissChance * 10000) / 10000 @ ")");
					//	echo("  LCK: " @ fetchData(%damagedClient, "LCK") @ ", LCK Miss Chance: " @ floor(%lckMissChance * 10000) / 10000);
					//}
					//else
					//	echo("  RESULT: HIT");
				}
			}
		}
		//------------- CHECK FOR A CRITICAL HIT -------------
		if(getRandom() > 0.5)
		{
			%norm = 1.000;
			%critskill = $PlayerSkill[%shooterClient, $SkillCriticals] / 3000;
			%critchance = %norm - %critskill;
			%critchance -= (AddPoints(%shooterClient, 1) / 100);
			if(%critchance < 0.1)
				%critchance = 0.1;
			if(getRandom() > %critchance)
				%criticalAttack = true;
		}
		
		//=======================================|WATER CHECKS|=========================================
		//------------------------------------
		// CHECK IF PLAYER LANDED ON WATER
		//------------------------------------
		if(%damagedClient == %shooterClient && %type == $LandingDamageType)
		{
			%object = "";
			for(%i = 0; %i >= -3.15; %i -= 1.57)
			{
				if(GameBase::getLOSInfo(Client::getOwnedObject(%damagedClient), 5, %i @ " 0 0"))
				{
					if(getObjectType($los::object) == "InteriorShape" && String::getSubStr(Object::getName($los::object), 0, 5) == "water")
					{
						%object = $los::object;
						break;
					}
				}
			}
			
			if(%object != "")
			{
				%value *= $waterDamageAmp;
				playSound(SoundSplash1, %damagedClientPos);
			}
		}

		//---------------------------------------
		// CHECK IF PLAYER LANDED WHILE IN WATER
		//---------------------------------------
		if(%damagedClient == %shooterClient && %type == $LandingDamageType)
		{
			if(Zone::getType(fetchData(%damagedClient, "zone")) == "WATER")
			%value *= $waterDamageAmp;
		}
		else if(%damagedClient != %shooterClient && %type == $LandingDamageType)
			%value = (fetchData(%damagedClient, "MaxHP") * (%value / 100) / 100);
		//============================================================================================

		//------------------------------------------------
		// SEAL BATTLE BOT DAMAGE PREVENTION
		//------------------------------------------------
		// Prevent seal battle bots from damaging each other, but allow them to damage players
		// Also allow mages to damage themselves with their spells
		if(fetchData(%shooterClient, "SealBattleBot") == "true" && fetchData(%damagedClient, "SealBattleBot") == "true" && %shooterClient != %damagedClient)
		{
			// Both are seal battle bots and not the same entity - prevent damage
			%value = 0;
			%isMiss = false;
			%noImpulse = true;
			%sameTeamNull = true;
		}
		
		// Prevent players NOT in Colloseum from damaging seal battle bots that ARE in Colloseum
		// This prevents camping outside and sniping bots during seal battles
		if($SealBattleActive == true && !isRPGAI(%shooterClient) && fetchData(%damagedClient, "SealBattleBot") == "true")
		{
			%shooterZone = Zone::getType(fetchData(%shooterClient, "zone"));
			%damagedZone = Zone::getType(fetchData(%damagedClient, "zone"));
			
			// If shooter is NOT in Colloseum but damaged bot IS in Colloseum, prevent damage
			if(%shooterZone != "Colloseum" && %damagedZone == "Colloseum")
			{
				%value = 0;
				%isMiss = false;
				%noImpulse = true;
				%sameTeamNull = true;
			}
		}
		
		// Prevent players NOT in Colloseum from damaging Colloseum arena bots that ARE in Colloseum
		// This prevents camping outside and sniping bots during Colloseum arena battles
		// Colloseum bots are named "Round1", "Round2", "Round3" (from rpgarena.cs)
		if($Fight != "" && !isRPGAI(%shooterClient) && isRPGAI(%damagedClient))
		{
			%damagedName = Client::getName(%damagedClient);
			%isColloseumBot = (%damagedName == "Round1" || %damagedName == "Round2" || %damagedName == "Round3");
			
			if(%isColloseumBot)
			{
				%shooterZone = Zone::getType(fetchData(%shooterClient, "zone"));
				%damagedZone = Zone::getType(fetchData(%damagedClient, "zone"));
				
				// If shooter is NOT in Colloseum but damaged bot IS in Colloseum, prevent damage
				if(%shooterZone != "Colloseum" && %damagedZone == "Colloseum")
				{
					%value = 0;
					%isMiss = false;
					%noImpulse = true;
					%sameTeamNull = true;
				}
			}
		}

		//------------------------------------------------
		// AI BOT TO AI BOT DAMAGE PREVENTION
		//------------------------------------------------
		// Prevent all AI bots from damaging each other, but allow:
		// - AI bots to damage players
		// - AI bots to damage themselves (self-damage from spells, handled later)
		if(isRPGAI(%shooterClient) && isRPGAI(%damagedClient) && %shooterClient != %damagedClient)
		{
			// Both are AI bots and not the same entity - prevent damage
			%value = 0;
			%isMiss = false;
			%noImpulse = true;
			%sameTeamNull = true;
		}

		//------------------------------------------------
		// SAME TEAM CHECKS
		//------------------------------------------------
		// AI mobs can always attack players, skip all same-team checks for AI attackers
		if(!Duel::isDueling(%damagedClient) && !Duel::isDueling(%shooterClient) && !isRPGAI(%shooterClient))
		{
			// Prevent all player-to-player damage when seal battle is active and players are in Colloseum zone (allows AI to still damage players)
			if($SealBattleActive == true && %shooterClient != %damagedClient)
			{
				%damagedZone = Zone::getType(fetchData(%damagedClient, "zone"));
				%shooterZone = Zone::getType(fetchData(%shooterClient, "zone"));
				
				if(%damagedZone == "Colloseum" || %shooterZone == "Colloseum")
				{
					// Only show message once per seal battle per client to avoid spam
					if(fetchData(%shooterClient, "sealDamageMsgShown") != "true")
					{
						Client::sendMessage(%shooterClient, $MsgWhite, "Player-on-Player damage is disabled in Colloseum during seal battles.");
						storeData(%shooterClient, "sealDamageMsgShown", "true");
					}
					if(fetchData(%damagedClient, "sealDamageMsgShown") != "true")
					{
						Client::sendMessage(%damagedClient, $MsgWhite, "Player-on-Player damage is disabled in Colloseum during seal battles.");
						storeData(%damagedClient, "sealDamageMsgShown", "true");
					}
					
					%value = 0;
					%isMiss = false;
					%noImpulse = true;
					%sameTeamNull = true;
				}
			}
			
			if(Client::getTeam(%damagedClient) == Client::getTeam(%shooterClient) && %shooterClient != %damagedClient)
			{
				// TEMPORARILY DISABLED - HasTheftFlag check
				//if(!HasTheftFlag(%damagedClient))
				//{
				// Prevent damage if damaged player is in PROTECTED zone (regardless of shooter's zone)
				if(Zone::getType(fetchData(%damagedClient, "zone")) == "PROTECTED")
				{
					%value = 0;
					%isMiss = false;
					%noImpulse = true;
					%sameTeamNull = true;
				}
				//}
					
					///no target-list involved
					if(!(IsInCommaList(fetchData(%damagedClient, "targetlist"), Client::getName(%shooterClient)) || IsInCommaList(fetchData(%shooterClient, "targetlist"), Client::getName(%damagedClient))) )
					{	
						%dhn = $House::Index[fetchData(%damagedClient, "MyHouse")];
						%shn = $House::Index[fetchData(%shooterClient, "MyHouse")];
						if(%dhn == %shn)
						{
							%value = 0;
							%isMiss = false;
							%noImpulse = true;
							%sameTeamNull = true;
						}
						else
						{
							if(%dhn == "" || %shn == "")
							{
								//one of the people involved is not in a house, so no damage occurs
								%value = 0;
								%isMiss = false;
								%noImpulse = true;
								%sameTeamNull = true;
							}
						}
					}

					if(Zone::getType(fetchData(%damagedClient, "zone")) != "PROTECTED" && Zone::getType(fetchData(%shooterClient, "zone")) != "PROTECTED")
					{
						if(fetchData(%damagedClient, "partyOwned"))
						{
							if(IsInCommaList(fetchData(%damagedClient, "partylist"), Client::getName(%shooterClient)))
							{
								%value = 0;
								%isMiss = false;
								%noImpulse = true;
								%sameTeamNull = true;
							}
						}
						else if(fetchData(%shooterClient, "partyOwned"))
						{
							if(IsInCommaList(fetchData(%shooterClient, "partylist"), Client::getName(%damagedClient)))
							{
								%value = 0;
								%isMiss = false;
								%noImpulse = true;
								%sameTeamNull = true;
							}
						}
					}
				}
				else
				{
					//one of the people involved has the other one on his/her target-list.
					//so let damage go thru
				}
			}
		}
		//-------------------------------------------------
		// SAME PLAYER CHECKS
		//-------------------------------------------------
		if(%damagedClient == %shooterClient)
		{
			if(isRPGAI(%damagedClient))
				%value = %value / 3;
			else if(Zone::getType(fetchData(%damagedClient, "zone")) == "PROTECTED")
				%value = 0;
			else if(%type == $SpellDamageType)
				%value = %value / 3;
		}

		if(!IsDead(%this))
		{
			%armor = Player::getArmor(%this);
			storeData(%damagedClient, "tmpkillerid", %shooterClient);

			%hitby = Client::getName(%shooterClient);
			%msgcolor = "";

			if(%isMiss)
			{
				%msgcolor = $MsgRed;
				%value = 0;
			}
			else if(!%isMiss && %value == 0 && %shooterClient != %damagedClient)
			{
				%msgcolor = $MsgWhite;
			}
			if(%msgcolor != "")
			{
				// Default damageMode to true if not set (for backwards compatibility)
				%shooterDamageMode = fetchData(%shooterClient, "damageMode");
				if(%shooterDamageMode == "")
					%shooterDamageMode = true;
				%damagedDamageMode = fetchData(%damagedClient, "damageMode");
				if(%damagedDamageMode == "")
					%damagedDamageMode = true;
				
				%isAI = isRPGAI(%shooterClient);
				
				if(%type != $SpellDamageType)
				{
					// Only send message to shooter if they're a player (not AI)
					if(!%isAI && %shooterDamageMode)
					{
						%msg = "<jl>You try to hit " @ Client::getName(%damagedClient) @ ", but miss!";
						bottomprint(%shooterClient, %msg, floor(String::len(%msg) / 20));
					}

					// Always send miss message to damaged player
					if(%damagedDamageMode)
					{
						%time = getIntegerTime(true) >> 5;
						if(%time - %damagedClient.lastMissMessage > 2)
						{
							%damagedClient.lastMissMessage = %time;
							%msg = "<jr>" @ %hitby @ " tries to hit you, but misses!";
							bottomprint(%damagedClient, %msg, floor(String::len(%msg) / 20));
						}
					}
				}
				else
				{
					// Only send message to shooter if they're a player (not AI)
					if(!%isAI && %shooterDamageMode)
					{
						if(%type == $SpellDamageType)
						{
							%msg = "<jl>" @ Client::getName(%damagedClient) @ " resists your spell!";
							bottomprint(%shooterClient, %msg, floor(String::len(%msg) / 20));
						}
						else
							Client::sendMessage(%shooterClient, %msgcolor, Client::getName(%damagedClient) @ " resists your spell!");
					}
					if(%damagedDamageMode)
					{
						if(%type == $SpellDamageType)
						{
							%msg = "<jr>You resist " @ %hitby @ "'s spell!";
							bottomprint(%damagedClient, %msg, floor(String::len(%msg) / 20));
						}
						else
							Client::sendMessage(%damagedClient, %msgcolor, "You resist " @ %hitby @ "'s spell!");
					}
				}
			}

			//-------------------------------------------------
			// SKILLS
			//-------------------------------------------------
			if(%skilltype >= 1 && !%sameTeamNull && %shooterClient != %damagedClient)
			{
				%base1 = Cap(35 + (fetchData(%shooterClient, "LVL") - fetchData(%damagedClient, "LVL")), 1, "inf");
				%base2 = Cap(35 + (fetchData(%damagedClient, "LVL") - fetchData(%shooterClient, "LVL")), 1, "inf");
				if(%isMiss)
				{
					UseSkill(%shooterClient, %skilltype, false, true);
					UseSkill(%damagedClient, $SkillEndurance, false, true, 60);
					
					if(%type == $SpellDamageType)
						UseSkill(%damagedClient, $SkillSpellResistance, true, true, %base2);
					else
						UseSkill(%damagedClient, $SkillDodging, true, true, %base2 * (3/5));
				}
				else if(!%isMiss && %value == 0)
				{
					UseSkill(%shooterClient, %skilltype, false, true);
					UseSkill(%damagedClient, $SkillEndurance, false, true, 60);
					
					if(%type == $SpellDamageType)
						UseSkill(%damagedClient, $SkillSpellResistance, true, true, %base2);
					else
						UseSkill(%damagedClient, $SkillDodging, true, true, %base2 * (3/5));
				}
				else
				{
					UseSkill(%shooterClient, %skilltype, true, true, %base1);
					UseSkill(%damagedClient, $SkillEndurance, true, true, 60);

					if(%type == $SpellDamageType)
						UseSkill(%damagedClient, $SkillSpellResistance, true, true, %base2);
				}

				if(%Bash || %Cleave || %Pierce)
					UseSkill(%shooterClient, $SkillBashing, true, true);
			}

			// Ensure %value is numeric before processing
			if(%value == "" || %value == -1)
				%value = 0;
			
			if(%value)
			{
				if(%value < 0)
					%value = 0;
				if(%criticalAttack)
					%value *= 2;
				
				// Check if shooter is a turret - turret damage bypasses all stance modifiers (except Normal)
				// Use comprehensive turret detection (same as earlier in function)
				%isTurretDamage = false;
				if(isObject(%object))
				{
					%objectClassName = %object.className;
					if(%objectClassName == "Turret")
						%isTurretDamage = true;
				}
				
				// Also detect turret projectiles by checking if it's MissileDamageType from a source without skills/ATK
				// Turrets use MissileDamageType projectiles but don't have player skills or ATK
				if(!%isTurretDamage && %type == $MissileDamageType)
				{
					// Check if shooter doesn't have ATK or skills (indicating it's a turret, not a player)
					%shooterATK = fetchData(%shooterClient, "ATK");
					if((%shooterATK == "" || %shooterATK == -1 || %shooterATK == 0) && (%skilltype == "" || $PlayerSkill[%shooterClient, %skilltype] == ""))
					{
						// Check if it's not a vehicle projectile (vehicles are handled separately)
						%shooterPlayerObj = Client::getOwnedObject(%shooterClient);
						%isVehicle = false;
						if(%shooterPlayerObj != -1)
						{
							%shooterType = getObjectType(%shooterPlayerObj);
							// Check if shooter object IS a vehicle/flier
							if(%shooterType == "Vehicle" || %shooterType == "Flier")
								%isVehicle = true;
							// Also check if player is IN a vehicle (for when player fires from vehicle)
							if(!%isVehicle && %shooterPlayerObj.vehicle != "")
								%isVehicle = true;
						}
						// If not a vehicle and no ATK/skills, it's likely a turret
						if(!%isVehicle)
							%isTurretDamage = true;
					}
				}
				
				// Offensive stance: doubles damage dealt and received (all damage types, including spells)
				// Turret damage bypasses stance modifiers
				if(!%isTurretDamage && fetchData(%shooterClient, "Stance") == "Offensive")
					%value *= 2;
				if(!%isTurretDamage && fetchData(%damagedClient, "Stance") == "Offensive")
					%value *= 2;
				
				// Defensive stance: halves damage dealt and received (all damage types)
				// Turret damage bypasses stance modifiers
				if(!%isTurretDamage && fetchData(%shooterClient, "Stance") == "Defensive")
					%value /= 2;
				if(!%isTurretDamage && fetchData(%damagedClient, "Stance") == "Defensive")
					%value /= 2;
				
				// Glass Cannon stance: 2.5x spell damage dealt, -50% max HP and -50% max mana (handled in rpgstats.cs)
				// Turret damage is affected by Glass Cannon (allows turrets to benefit from Glass Cannon stance)
				if(fetchData(%shooterClient, "Stance") == "Glass Cannon" && %type == $SpellDamageType)
					%value *= 2.5;

				// MageBane: nullifies magic damage received, doubles physical damage received
				// Turret damage bypasses bane stances
				if(!%isTurretDamage && fetchData(%damagedClient, "MANA") > 0)
				{
					if(%type == $SpellDamageType && fetchData(%damagedClient, "Stance") == "MageBane") 
						%value = 0;
					if(%type != $SpellDamageType && fetchData(%damagedClient, "Stance") == "MageBane")
						%value *= 2;
				}
				
				// BladeBane: nullifies physical damage received, doubles magic damage received
				// Turret damage bypasses bane stances
				if(!%isTurretDamage && fetchData(%damagedClient, "MANA") > 0)
				{
					if(%type != $SpellDamageType && fetchData(%damagedClient, "Stance") == "BladeBane")
						%value = 0;
					if(%type == $SpellDamageType && fetchData(%damagedClient, "Stance") == "BladeBane")
						%value *= 2;
				}
				
				// Ensure value doesn't become 0 or negative after stance modifiers
				if(%value < 0)
					%value = 0;						
				
				if(%Pierce)
				{
					//Not really any way to code this using a player's skill that won't
					// end up being too powerful at one point (ultimate pk anyone?)
					// instead let's just go with a 5% chance!

					//%regular = 1.0;
					//%chance = $PlayerSkill[%shooterClient, $SkillBashing] / 50000;
					//%special = %regular - %chance;
				
					//if(%special < 0.5)
					//	%special = 0.5;

					//if(getRandom() > %special)
					if(getRandom() > 0.95)
						$lckBypass[%damagedClient] = true;
				}
				
				%backupValue = %value;

				%rhp = refreshHP(%damagedClient, %value);

				%lckMiss = false;
				if(%rhp == -1)
				{
					%value = -1;	//There was an LCK miss
					%lckMiss = true;
				}
				else
				{
					if(!%noImpulse) Player::applyImpulse(%this,%mom);
						%noImpulse = "";

					if(%damagedCurrentArmor != "")
						%ahs = $ArmorHitSound[%damagedCurrentArmor];
					else
						%ahs = SoundHitFlesh;
					if(%skilltype == $SkillSlashing)
						PlaySound(%ahs, %damagedClientPos);
					else if(%skilltype == $SkillBludgeoning)
						PlaySound(%ahs, %damagedClientPos);
					else if(%skilltype == $SkillPiercing)
						PlaySound(%ahs, %damagedClientPos);
					else if(%skilltype == $SkillVehicleCombat)
						PlaySound(SoundArrowHit2, %damagedClientPos);
				}

				PlaySound(RandomRaceSound(fetchData(%damagedClient, "RACE"), Hit), %damagedClientPos);

			//display amount of damage caused
			// Check for LCK miss first before converting -1 to 0
			if(%lckMiss)
			{
				// Handle LCK miss message (this will be handled in the else if block below)
				%convValue = -1; // Keep as -1 to trigger LCK miss message
			}
			else
			{
				if(%value == "" || %value == -1)
					%value = 0;
				%convValue = round(%value * $TribesDamageToNumericDamage);
			}

				if(%convValue > 0)
				{
					if(%shooterClient == %damagedClient)
					{
						if(%type == $CrushDamageType)
							%hitby = "moving object";
						else if(%type == $DebrisDamageType)
							%hitby = "debris";
						else if(%type == $SpellDamageType)
							%hitby = "your " @ $Spell::name[$Spell::index[%weapon]];
						else
							%hitby = "yourself";
					}
					else if(%shooterClient == 0)
					{
						if(%type == $SpellDamageType && %weapon != "")
						{
							%spellIndex = $Spell::index[%weapon];
							if(%spellIndex != "")
								%hitby = $Spell::name[%spellIndex];
							else
							{
								//echo("DEBUG: Spell index not found for weapon='" @ %weapon @ "'");
								%hitby = "a powerful force";
							}
						}
						else
							%hitby = "a powerful force";
					}
					else
					{
						if(fetchData(%shooterClient, "invisible"))
							%hitby = "an unknown assailant";
						else if(%type == $SpellDamageType && %weapon != "")
						{
							%spellIndex = $Spell::index[%weapon];
							if(%spellIndex != "")
								%hitby = Client::getName(%shooterClient) @ "'s " @ $Spell::name[%spellIndex];
							else
							{
								//echo("DEBUG: Spell index not found for weapon='" @ %weapon @ "', shooter=" @ %shooterClient);
								%hitby = Client::getName(%shooterClient);
							}
						}
						else
							%hitby = Client::getName(%shooterClient);
					}

					if(%Pierce)
					{
						%daction = "pierced";
						%saction = "pierced";
					}
					else if(%Bash)
					{
						%daction = "bashed";
						%saction = "bashed";
					}
					else if(%Cleave)
					{
						%daction = "cleaved";
						%saction = "cleaved";
					}					
					else
					{
						%daction = "damaged";
						%saction = "damaged";
					}

					//--------------------
					//display to involved
					//--------------------
					// Default damageMode to true if not set (for backwards compatibility)
					%shooterDamageMode = fetchData(%shooterClient, "damageMode");
					if(%shooterDamageMode == "")
						%shooterDamageMode = true;
					%damagedDamageMode = fetchData(%damagedClient, "damageMode");
					if(%damagedDamageMode == "")
						%damagedDamageMode = true;
					
					if(%shooterClient != %damagedClient)
						if(%shooterDamageMode)
						{
							%spellName = "";
							if(%type == $SpellDamageType && %weapon != "")
							{
								%spellIndex = $Spell::index[%weapon];
								if(%spellIndex != "")
									%spellName = " with " @ $Spell::name[%spellIndex];
							}
							if(%type == $SpellDamageType)
							{
								if(%criticalAttack)
								{
									%msg = "<jl>You critically " @ %saction @ " " @ Client::getName(%damagedClient) @ %spellName @ " for " @ %convValue @ " points of damage!";
									bottomprint(%shooterClient, %msg, floor(String::len(%msg) / 20));
								}
								else
								{
									%msg = "<jl>You " @ %saction @ " " @ Client::getName(%damagedClient) @ %spellName @ " for " @ %convValue @ " points of damage!";
									bottomprint(%shooterClient, %msg, floor(String::len(%msg) / 20));
								}
							}
							else
							{
								if(%criticalAttack)
								{
									%msg = "<jl>You critically " @ %saction @ " " @ Client::getName(%damagedClient) @ %spellName @ " for " @ %convValue @ " points of damage!";
									bottomprint(%shooterClient, %msg, floor(String::len(%msg) / 20));
								}
								else
								{
									%msg = "<jl>You " @ %saction @ " " @ Client::getName(%damagedClient) @ %spellName @ " for " @ %convValue @ " points of damage!";
									bottomprint(%shooterClient, %msg, floor(String::len(%msg) / 20));
								}
							}
						}
					
					if(%damagedDamageMode)
					{
						if(%type == $SpellDamageType)
						{
							if(%criticalAttack)
							{
								%msg = "<jr>You were critically " @ %daction @ " by " @ %hitby @ " for " @ %convValue @ " points of damage!";
								bottomprint(%damagedClient, %msg, floor(String::len(%msg) / 20));
							}
							else
							{
								%msg = "<jr>You were " @ %daction @ " by " @ %hitby @ " for " @ %convValue @ " points of damage!";
								bottomprint(%damagedClient, %msg, floor(String::len(%msg) / 20));
							}
						}
						else
						{
							if(%criticalAttack)
							{
								%msg = "<jr>You were critically " @ %daction @ " by " @ %hitby @ " for " @ %convValue @ " points of damage!";
								bottomprint(%damagedClient, %msg, floor(String::len(%msg) / 20));
							}
							else
							{
								%msg = "<jr>You were " @ %daction @ " by " @ %hitby @ " for " @ %convValue @ " points of damage!";
								bottomprint(%damagedClient, %msg, floor(String::len(%msg) / 20));
							}
						}
					}

					//--------------------
					//display to radius
					//--------------------
					if(%shooterClient == 0)
					{
						if(%type == $SpellDamageType && %weapon != "")
						{
							%spellIndex = $Spell::index[%weapon];
							if(%spellIndex != "")
								%sname = $Spell::name[%spellIndex];
							else
							{
								//echo("DEBUG: Spell index not found for weapon='" @ %weapon @ "' in radius message");
								%sname = "A powerful force";
							}
						}
						else
							%sname = "A powerful force";
						%dname = Client::getName(%damagedClient);
					}
					else if(%shooterClient == %damagedClient)
					{
						%sname = Client::getName(%shooterClient);
						if(String::ICompare(Client::getGender(%damagedClient), "Male") == 0)
							%dname = "himself";
						else if(String::ICompare(Client::getGender(%damagedClient), "Female") == 0)
							%dname = "herself";
						else
							%dname = "itself";
					}
					else
					{
						if(fetchData(%shooterClient, "invisible"))
							%sname = "An unknown assailant";
						else if(%type == $SpellDamageType && %weapon != "")
						{
							%spellIndex = $Spell::index[%weapon];
							if(%spellIndex != "")
								%sname = Client::getName(%shooterClient) @ "'s " @ $Spell::name[%spellIndex];
							else
							{
								//echo("DEBUG: Spell index not found for weapon='" @ %weapon @ "' in radius message, shooter=" @ %shooterClient);
								%sname = Client::getName(%shooterClient);
							}
						}
						else
							%sname = Client::getName(%shooterClient);
						
						%dname = Client::getName(%damagedClient);
					}

					if(%criticalAttack)
						radiusAllExcept(%damagedClient, %shooterClient, %sname @ " critically hits " @ %dname @ " for " @ %convValue @ " points of damage!");
					else
						radiusAllExcept(%damagedClient, %shooterClient, %sname @ " hits " @ %dname @ " for " @ %convValue @ " points of damage!");
				}
				else if(%convValue < 0)
				{
					//this happens when there's a LCK consequence as miss

					if(%shooterClient == 0)
					{
						if(%type == $SpellDamageType && %weapon != "")
							%hitby = $Spell::name[$Spell::index[%weapon]];
						else
							%hitby = "A powerful force";
					}
					else
					{
						if(%type == $SpellDamageType && %weapon != "")
							%hitby = Client::getName(%shooterClient) @ "'s " @ $Spell::name[$Spell::index[%weapon]];
						else
							%hitby = Client::getName(%shooterClient);
					}

					// Default damageMode to true if not set (for backwards compatibility)
					%shooterDamageMode = fetchData(%shooterClient, "damageMode");
					if(%shooterDamageMode == "")
						%shooterDamageMode = true;
					%damagedDamageMode = fetchData(%damagedClient, "damageMode");
					if(%damagedDamageMode == "")
						%damagedDamageMode = true;
					
					if(%shooterDamageMode)
					{
						%msg = "<jl>You try to hit " @ Client::getName(%damagedClient) @ ", but miss! (LCK)";
						bottomprint(%shooterClient, %msg, floor(String::len(%msg) / 20));
					}
					if(%damagedDamageMode)
					{
						%msg = "<jr>" @ %hitby @ " tries to hit you, but misses! (LCK)";
						bottomprint(%damagedClient, %msg, floor(String::len(%msg) / 20));
					}
				}

				//-------------------------------------------
				//add entry to damagedClient's damagedBy list
				//-------------------------------------------

				//make new entry with shooter's name
				if( %shooterClient != 0 && !%isMiss)
				{
					if(%shooterClient == 0)
						%sname = "A powerful force";
					else
						%sname = Client::getName(%shooterClient);

					%dname = Client::getName(%damagedClient);
					if(%shooterClient != %damagedClient)
					{
						%index = "";
						for(%i = 1; %i <= $maxDamagedBy; %i++)
						{
							if($damagedBy[%dname, %i] == "" && %index == "")
							%index = %i;
						}
						if(%index != "")
						{
							$damagedBy[%dname, %index] = %sname @ " " @ %backupValue;
							schedule("$damagedBy[\"" @ %dname @ "\", " @ %index @ "] = \"\";", $damagedByEraseDelay);
						}
						else
						{
							//too many hits on waiting list, he doesn't get in on exp.
						}
					}
				}

				if(fetchData(%damagedClient, "flashMode"))
				{
					%flash = Player::getDamageFlash(%this) + %value * 2;
					if(%flash > 0.75)
						%flash = 0.75;
					Player::setDamageFlash(%this,%flash);
				}

				//If player not dead then play a random hurt sound
				if(!Player::IsDead(%this))
				{
					if(%damagedClient.lastDamage < getSimTime())
					{
						%sound = radnomItems(3,injure1,injure2,injure3);
						playVoice(%damagedClient,%sound);
						%damagedClient.lastdamage = getSimTime() + 1.5;
					}
				}
				else		//player died
				{
					if(isRPGAI(%shooterClient))
					{
						RemotePlayAnim(%shooterClient, 8);
						PlaySound(RandomRaceSound(fetchData(%shooterClient, "RACE"), Taunt), %shooterClientPos);
					}

					if( Player::isCrouching(%this) )
					%curDie = $PlayerAnim::Crouching;
					else
					%curDie = radnomItems(3, $PlayerAnim::DieLeftSide, $PlayerAnim::DieChest, $PlayerAnim::DieForwardKneel);

					Player::setAnimation(%this, %curDie);

					if(%type == $ImpactDamageType && %object.clLastMount != "")
					%shooterClient = %object.clLastMount;

					Client::onKilled(%damagedClient, %shooterClient, %type);
				}  // line 1237 - closes else from line 1219
			}  // line 1238 - closes if(!Player::IsDead(%this)) from line 1209

			if(%isMiss)  // line 1240
			{
				if(fetchData(%damagedClient, "isBonused"))  // line 1242
				{
					GameBase::activateShield(%this, "0 0 1.57", 1.47);  // line 1244
					PlaySound(SoundHitShield, %damagedClientPos);  // line 1245
				}  // closes if(fetchData(%damagedClient, "isBonused")) from line 1243
			}  // closes if(%isMiss) from line 1241
		}  // closes if(%value) from line 859
	}  // closes if(!IsDead(%this)) from line 759

  // closes function Player::onDamage from line 440
function remoteKill(%clientId)
{
	dbecho($dbechoMode, "remoteKill(" @ %clientId @ ")");

	if(!$matchStarted)
		return;
	if(%clientId.isJailed || Duel::isDueling(%clientId))
		return;
	
	%player = Client::getOwnedObject(%clientId);
	if(%player != -1 && getObjectType(%player) == "Player" && !IsDead(%clientId))
	{
		storeData(%clientId, "LCK", 1, "dec");

		if(fetchData(%clientId, "LCK") >= 0)
			Client::sendMessage(%clientId, $MsgRed, "You have permanently lost an LCK point!");

		playNextAnim(%clientId);
		Player::kill(%clientId);
	}
}