$HouseName[1] = "HouseKronos";
$HouseName[2] = "HouseArbal";
$HouseName[3] = "HouseCurama";
$HouseName[4] = "HouseYuliple";

//$HouseStartUpEq[1] = "AntivaRobe 1";
//$HouseStartUpEq[2] = "FenyarRobe 1";
//$HouseStartUpEq[3] = "TemminRobe 1";
//$HouseStartUpEq[4] = "VenkRobe 1";
$HouseStartUpEq[1] = "";
$HouseStartUpEq[2] = "";
$HouseStartUpEq[3] = "";
$HouseStartUpEq[4] = "";


$HouseMember[HouseYuliple] = 0;
$HouseMember[HouseCurama] = 0;
$HouseMember[HouseArbal] = 0;
$HouseMember[HouseKronos] = 0;

function GetHouseNumber(%n)
{
	dbecho($dbechoMode, "GetHouseNumber(" @ %n @ ")");

	for(%i = 1; $HouseName[%i] != ""; %i++)
	{
		//if($HouseName[%i] == %n)
		if(String::ICompare($HouseName[%i], %n) == 0)
			return %i;
	}
	return "";
}

function BootFromCurrentHouse(%clientId, %echo)
{
	dbecho($dbechoMode, "BootFromCurrentHouse(" @ %clientId @ ", " @ %echo @ ")");

	%h = fetchData(%clientId, "MyHouse");
	
	// Treat "0" as empty (no house) - new players might have "0" instead of empty string
	if(%h == "0")
		%h = "";

	if(%h != "")
	{
		UnequipMountedStuff(%clientId);

		%hn = GetHouseNumber(%h);
		if(%echo) Client::sendMessage(%clientId, $MsgRed, "You have been booted from " @ $HouseName[%hn] @ " and have lost all rank points.");

		storeData(%clientId, "MyHouse", "");
		storeData(%clientId, "RankPoints", 0);
		$HouseMember[%h] -= 1;
		
		// Reset to unaffiliated citizen team
		GameBase::setTeam(%clientId, 0);
		
		// Update objectives display to refresh member counts
		UpdateHouseObjectivesDisplay();

		return %hn;
	}
	else
		return -1;
}

function JoinHouse(%clientId, %hn, %echo)
{
	dbecho($dbechoMode, "JoinHouse(" @ %clientId @ ", " @ %hn @ ", " @ %echo @ ")");

	storeData(%clientId, "MyHouse", $HouseName[%hn]);
	storeData(%clientId, "RankPoints", $joinHouseRankPoints);
	$HouseMember[$HouseName[%hn]] += 1;
	$HouseChecked[Client::getName(%clientId)] = 1;
	
	// All players remain on team 0 (Citizen) to allow NPC dialogue and enemy NPC combat
	// House affiliation is tracked via MyHouse property, not team number
	GameBase::setTeam(%clientId, 0);
	
	// Update objectives display to refresh member counts
	UpdateHouseObjectivesDisplay();

	if(%echo) Client::sendMessage(%clientId, $MsgBeige, "You have joined " @ $HouseName[%hn] @ " and have been awarded " @ $joinHouseRankPoints @ " rank points.");
}

// Helper function to check if two players are in the same house
function IsSameHouse(%client1, %client2)
{
	%house1 = fetchData(%client1, "MyHouse");
	%house2 = fetchData(%client2, "MyHouse");
	
	// If either player has no house, they're not in the same house
	if(%house1 == "" || %house2 == "")
		return False;
	
	return String::ICompare(%house1, %house2) == 0;
}

// Helper function to get house name from client
function GetClientHouse(%clientId)
{
	return fetchData(%clientId, "MyHouse");
}

// House data file paths
$House::LoadFile = "[KoK-Houses].cs";
$House::SaveFile = $House::LoadFile;

// Save house data to file
function HouseData::Save(%echoOff) {
    File::delete($House::SaveFile);
    export("$BaseControl*", $House::SaveFile, false);
    export("$FlagCommand*", $House::SaveFile, true);
    export("$HouseMember*", $House::SaveFile, true);
    if (!%echoOff)
        echo("House data saved to: " @ $House::SaveFile);
}

// Load house data from file
function HouseData::Load() {
    if (isfile($House::LoadFile)) {
        exec($House::LoadFile);
        echo("House data loaded from: " @ $House::LoadFile);
    }
}

// Reset all house data
function HouseData::Reset()
{
	deleteVariables("HouseData::*");
	
	for(%i = 1; %i <= 4; %i++)
	{
		$HouseData::Data[%i, 0] = 0;
		for(%j = 1; %j <= 8; %j++)
			$HouseData::Data[%i, %j] = false;
	}
}