//Globals for seal system; %i is the id of the battle.
//$SealBattleActive: If true, then a seal battle is currently active for a player.
//Just leave this one as it is.
//$SealValue[%i]: The seal value that is assigned to the player who wins this battle.
//$SealEnemy[%i,1]: The enemy used for the 1st wave. Use the bot's spawnIndex value.
//$SealEnemy[%i,2]: The enemy used for the 2nd wave. Use the bot's spawnIndex value.
//$SealEnemy[%i,3]: The enemy used for the final wave. Use the bot's spawnIndex value.
///////////////////////////////////////////////////////////////////////
// DEFAULT SEAL MULTIPLIERS SHOULD BE DOABLE BY 4-5 FULLY GEARED PLAYERS. ADJUST AS NECESSARY FOR PLAYERBASE.
///////////////////////////////////////////////////////////////////////
$SealBattleActive = false;
%i=0;

// Centralized TotalSealValue management functions
function GetTotalSealValue()
{
    // Ensure TotalSealValue is always initialized and valid
    if($TotalSealValue == "" || $TotalSealValue < 20)
    {
        $TotalSealValue = 20;
        echo("WARNING: TotalSealValue was invalid, reset to 20");
    }
    return $TotalSealValue;
}

function IncrementTotalSealValue()
{
    // Get current value (ensures it's valid)
    %current = GetTotalSealValue();
    
    // Increment by 20
    $TotalSealValue = %current + 20;
    
    // Save to separate file immediately
    File::delete("temp\\SealValue.cs");
    export("TotalSealValue", "temp\\SealValue.cs", false);
    
    echo("TotalSealValue incremented to " @ $TotalSealValue);
    return $TotalSealValue;
}

function SetTotalSealValue(%value)
{
    // Ensure value is at least 20
    if(%value < 20)
        %value = 20;
    
    $TotalSealValue = %value;
    
    // Save to file immediately
    File::delete("temp\\SealValue.cs");
    export("TotalSealValue", "temp\\SealValue.cs", false);
    
    echo("TotalSealValue set to " @ $TotalSealValue);
    return $TotalSealValue;
}

//multiplier for each additional seal that needs to be broken to dynamically scale
function SealBattle::GetEnemyStrengthMultiplier()
{
    %baseMultiplier = 0.100;
    %increment = 0.1;
    %sealValue = GetTotalSealValue();
    %steps = %sealValue / 20;
    %multiplier = %baseMultiplier + (%steps * %increment);
    return %multiplier;
}

function SealBattle::GetParticipantNames()
{
	// Build a formatted list of participant names
	%participantNames = "";
	%participantCount = 0;
	%list = $SealBattleParticipants;
	
	// Parse comma-separated list
	while(String::len(%list) > 0)
	{
		%commaPos = String::findSubStr(%list, ",");
		if(%commaPos > 0)
		{
			%participantId = String::getSubStr(%list, 0, %commaPos);
			%list = String::getSubStr(%list, %commaPos + 1, 99999);
		}
		else
		{
			%participantId = %list;
			%list = "";
		}
		
		if(%participantId == "" || %participantId == -1)
			continue;
		
		%name = Client::getName(%participantId);
		if(%name != "")
		{
			if(%participantNames != "")
				%participantNames = %participantNames @ ", " @ %name;
			else
				%participantNames = %name;
			%participantCount++;
		}
	}
	
	return %participantNames;
}

function SealBattle::MessageColloseumPlayers(%message)
{
	// Send message to all players currently in the Colloseum zone
	for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
	{
		if(isRPGAI(%cl))
			continue;
		
		%clZoneId = fetchData(%cl, "zone");
		%clZoneDesc = Zone::getDesc(%clZoneId);
		if(%clZoneDesc == "Colloseum")
		{
			Client::sendMessage(%cl, $MsgWhite, %message);
		}
	}
}

function SealBattle::Begin(%clientId,%pos,%seal)
{
	if($SealBattleActive != true)
	{
		//echo("DEBUG SealBattle::Begin: Starting seal battle for " @ Client::getName(%clientId) @ " (" @ %clientId @ ")");
		storeData(%clientId,"noDropLootbagFlag",false);
		$SealFighterDied = false;
		$SealBattleActive = true;
		
		
		// Store the zone description and house for checking all friendly players
		// Seal battles always take place in "Colloseum" zone, so we always check for that
		%house = fetchData(%clientId, "MyHouse");
		$SealBattleZone = "Colloseum";  // Seal battles always happen in Colloseum
		$SealBattleHouse = %house;
		//echo("DEBUG SealBattle::Begin: Seal battle zone=Colloseum, House=" @ %house);
		
		// Initialize the list of players who join during the 30-second window
		$SealBattleParticipants = "";
		
		// Add the initiator to the participants list
		$SealBattleParticipants = AddToCommaList($SealBattleParticipants, %clientId);
		
		// Announce to all players that the seal battle will begin in 30 seconds
		messageAll(2, "The seal battle will begin in 30 seconds! Type #helpseal now to join!");
		
		// Schedule the actual battle start after 30 seconds
		schedule("SealBattle::StartBattle(" @ %clientId @ ", \"" @ %pos @ "\", " @ %seal @ ");", 30);
	}
	else
	{
		//echo("DEBUG SealBattle::Begin: Seal battle already active, ignoring request");
	}
}

function SealBattle::StartBattle(%clientId,%pos,%seal)
{
	//echo("DEBUG SealBattle::StartBattle: Beginning seal battle for " @ Client::getName(%clientId) @ " (" @ %clientId @ ")");
	
	// Capture all players currently in Colloseum as participants (30-second window just ended)
	%colloseumEntrance = "-3588 -2364 354";
	for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
	{
		if(isRPGAI(%cl))
			continue;
		
		%clZoneId = fetchData(%cl, "zone");
		%clZoneDesc = Zone::getDesc(%clZoneId);
		if(%clZoneDesc == "Colloseum")
		{
			// Add to participants list if not already there
			if(String::findSubStr($SealBattleParticipants, %cl) == -1)
			{
				$SealBattleParticipants = AddToCommaList($SealBattleParticipants, %cl);
				//echo("DEBUG SealBattle::StartBattle: Added " @ Client::getName(%cl) @ " (" @ %cl @ ") to participants");
			}
			
			// Set lastzone to Colloseum zone ID so players spawn correctly if they die
			storeData(%cl, "lastzone", %clZoneId);
			// Also ensure they're at the Colloseum entrance
			%playerObj = Client::getOwnedObject(%cl);
			if(%playerObj != -1)
				GameBase::setPosition(%playerObj, %colloseumEntrance);
		}
	}
	
	//echo("DEBUG SealBattle::StartBattle: Participants list: " @ $SealBattleParticipants);
	
	// Build a formatted list of participant names for the message
	// Parse comma-separated list (AddToCommaList uses $sepchar which is ",")
	%participantNames = "";
	%participantCount = 0;
	%list = $SealBattleParticipants;
	
	// Parse comma-separated list
	while(String::len(%list) > 0)
	{
		%commaPos = String::findSubStr(%list, ",");
		if(%commaPos > 0)
		{
			%participantId = String::getSubStr(%list, 0, %commaPos);
			%list = String::getSubStr(%list, %commaPos + 1, 99999);
		}
		else
		{
			%participantId = %list;
			%list = "";
		}
		
		if(%participantId == "" || %participantId == -1)
			continue;
		
		%name = Client::getName(%participantId);
		if(%name != "")
		{
			if(%participantNames != "")
				%participantNames = %participantNames @ ", " @ %name;
			else
				%participantNames = %name;
			%participantCount++;
		}
	}
	
	// Send message with participant list
	if(%participantCount > 0)
	{
		messageAll(2, "Wish " @ %participantNames @ " good luck in breaking the seal!");
	}
	
	// Start the battle loop
	SealBattle::Loop(%clientId,%pos,%seal,1);
	storeData(Sealbot,"noDropLootbagFlag",True);
	storeData(Sealbot2,"noDropLootbagFlag",True);
	storeData(Sealbot3,"noDropLootbagFlag",True);
}
function SealBattle::Loop(%clientId,%pos,%seal,%round)
{
	%name = Client::getName(%clientId);
	%player = Client::getOwnedObject(%clientId);
	%zone = Zone::getDesc(fetchData(%clientId, "zone"));
	//echo("DEBUG SealBattle::Loop: Round=" @ %round @ ", Client=" @ %name @ " (" @ %clientId @ "), SealFighterDied=" @ $SealFighterDied);
	
	// Check if player died FIRST - if so, kill all bots and exit immediately
	if($SealFighterDied)
	{
		//echo("DEBUG SealBattle::Loop: SealFighterDied=true, killing all seal bots and concluding battle");
		//Play random enemy taunt sound (just to annoy the hell out of the player >:D)
		%randtaunt = floor(getRandom()*3);
		if(%randtaunt == 0) %sound = "OgreTaunt1.wav";
		if(%randtaunt == 1) %sound = "UndeadTaunt1.wav";
		if(%randtaunt == 2) %sound = "GnollTaunt1.wav";
		Client::sendMessage(%clientId,$MsgRed,"You died...~w"@%sound);
		
		// Round 1 bots
		%g1 = NEWgetClientByName("SealGuardian1");
		%m1 = NEWgetClientByName("SealMage1");
		%f1 = NEWgetClientByName("SealFighter1");
		//echo("DEBUG SealBattle::Loop: Killing Round 1 bots - Guardian1=" @ %g1 @ ", Mage1=" @ %m1 @ ", Fighter1=" @ %f1);
		if(%g1 != -1) Player::Kill(%g1);
		if(%m1 != -1) Player::Kill(%m1);
		if(%f1 != -1) Player::Kill(%f1);
		
		// Round 2 bots
		%g2 = NEWgetClientByName("SealGuardian2");
		%m2 = NEWgetClientByName("SealMage2");
		%f2 = NEWgetClientByName("SealFighter2");
		//echo("DEBUG SealBattle::Loop: Killing Round 2 bots - Guardian2=" @ %g2 @ ", Mage2=" @ %m2 @ ", Fighter2=" @ %f2);
		if(%g2 != -1) Player::Kill(%g2);
		if(%m2 != -1) Player::Kill(%m2);
		if(%f2 != -1) Player::Kill(%f2);
		
		// Round 3 bots
		%g3 = NEWgetClientByName("SealGuardian3");
		%m3 = NEWgetClientByName("SealMage3");
		%f3 = NEWgetClientByName("SealFighter3");
		//echo("DEBUG SealBattle::Loop: Killing Round 3 bots - Guardian3=" @ %g3 @ ", Mage3=" @ %m3 @ ", Fighter3=" @ %f3);
		if(%g3 != -1) Player::Kill(%g3);
		if(%m3 != -1) Player::Kill(%m3);
		if(%f3 != -1) Player::Kill(%f3);
		
		// Broadcast message that all players have died
		%participantNames = SealBattle::GetParticipantNames();
		messageAll(2, %participantNames @ " have died attempting to shatter the seal... Heavens be with us!");
		
		SealBattle::Conclude(%clientId, false);  // false = failure, teleport back
		return;
	}
	
	if(%round == 1)
	{
		// FIRST check if all players are dead - if so, end battle immediately
		// Run a quick death check before spawning bots
		SealBattle::LazyDeathCheck(%clientId);
		if($SealFighterDied)
		{
			//echo("DEBUG SealBattle::Loop: Round 1 - All players dead, ending battle immediately");
			// This will be handled by the $SealFighterDied check at the top of the function
			// But we need to return here to prevent bot spawning
			return;
		}
		
		%bot = 66; //fighter bot
		%bot2 = 67; //mage bot
		%bot3 = 68; //Guardian bot
		
		// Validate spawn indexes exist
		if($spawnIndex[%bot] == "" || $spawnIndex[%bot2] == "" || $spawnIndex[%bot3] == "")
		{
			//echo("ERROR: SealBattle::Loop - Invalid spawn indexes (Round 1): bot=" @ %bot @ ", bot2=" @ %bot2 @ ", bot3=" @ %bot3);
			return;
		}
		
		//echo("DEBUG SealBattle::Loop: Round 1 - Spawning bots (Fighter=" @ %bot @ ", Mage=" @ %bot2 @ ", Guardian=" @ %bot3 @ ")");
		AI::helper($spawnIndex[%bot],"SealFighter1","TempSpawn -3608 -2365 354 1",default);
		//echo("DEBUG SealBattle::Loop: Called AI::helper for SealFighter1, scheduling SetupBot");
		schedule("SealBattle::SetupBot(\"SealFighter1\", \"" @ %pos @ "\");", 0.5);
		
		AI::helper($spawnIndex[%bot2],"SealMage1","TempSpawn -3608 -2365 354 1",default);
		//echo("DEBUG SealBattle::Loop: Called AI::helper for SealMage1, scheduling SetupBot");
		schedule("SealBattle::SetupBot(\"SealMage1\", \"" @ %pos @ "\");", 0.5);
		
		AI::helper($spawnIndex[%bot3],"SealGuardian1","TempSpawn -3608 -2365 354 1",default);
		//echo("DEBUG SealBattle::Loop: Called AI::helper for SealGuardian1, scheduling SetupBot");
		schedule("SealBattle::SetupBot(\"SealGuardian1\", \"" @ %pos @ "\");", 0.5);

		%round++;
		// Message already sent in SealBattle::Begin() - removed duplicate
		%sealValue = GetTotalSealValue();
		messageall(2,"The current seal value is " @ %sealValue @ "");
		
		//echo("DEBUG SealBattle::Loop: Round 1 complete, round incremented to " @ %round);
	}
	else if(%round == 2)
	{
		// FIRST check if all players are dead - if so, end battle immediately
		// Run a quick death check before checking bot status
		SealBattle::LazyDeathCheck(%clientId);
		if($SealFighterDied)
		{
			//echo("DEBUG SealBattle::Loop: Round 2 - All players dead, ending battle immediately");
			// This will be handled by the $SealFighterDied check at the top of the function
			// But we need to return here to prevent the bot check from running
			return;
		}
		
		%fighter1Id = NEWgetClientByName("SealFighter1");
		%mage1Id = NEWgetClientByName("SealMage1");
		%guardian1Id = NEWgetClientByName("SealGuardian1");
		//echo("DEBUG SealBattle::Loop: Round 2 check - SealFighter1=" @ %fighter1Id @ ", SealMage1=" @ %mage1Id @ ", SealGuardian1=" @ %guardian1Id);
		
		if(%fighter1Id == -1 && %mage1Id == -1 && %guardian1Id == -1)
		{
			// Round 1 bots are dead - schedule Round 2 spawn after 30 seconds
			// Send recovery message immediately
			SealBattle::MessageColloseumPlayers("You have 30 seconds to recover from battle. Use it wisely");
			//echo("DEBUG SealBattle::Loop: Round 1 bots died, scheduling Round 2 spawn in 30 seconds");
			
			// Schedule countdown messages
			schedule("SealBattle::MessageColloseumPlayers(\"20 seconds remaining to recover...\");", 10);
			schedule("SealBattle::MessageColloseumPlayers(\"10 seconds remaining to recover...\");", 20);
			
			// Schedule Round 2 spawn after 30 seconds
			schedule("SealBattle::SpawnRound2(" @ %clientId @ ", \"" @ %pos @ "\", " @ %seal @ ", " @ %round @ ", \"" @ %name @ "\");", 30);
			return;
		}
		else
		{
			//echo("DEBUG SealBattle::Loop: Round 2 check failed - Round 1 bots still alive");
		}
	}
	else if(%round == 3)
	{
		// FIRST check if all players are dead - if so, end battle immediately
		// Run a quick death check before checking bot status
		SealBattle::LazyDeathCheck(%clientId);
		if($SealFighterDied)
		{
			//echo("DEBUG SealBattle::Loop: Round 3 - All players dead, ending battle immediately");
			// This will be handled by the $SealFighterDied check at the top of the function
			// But we need to return here to prevent the bot check from running
			return;
		}
		
		%fighter2Id = NEWgetClientByName("SealFighter2");
		%mage2Id = NEWgetClientByName("SealMage2");
		%guardian2Id = NEWgetClientByName("SealGuardian2");
		//echo("DEBUG SealBattle::Loop: Round 3 check - SealFighter2=" @ %fighter2Id @ ", SealMage2=" @ %mage2Id @ ", SealGuardian2=" @ %guardian2Id);
		
		if(%fighter2Id == -1 && %mage2Id == -1 && %guardian2Id == -1)
		{
			// Round 2 bots are dead - schedule Round 3 spawn after 30 seconds
			// Send recovery message immediately
			SealBattle::MessageColloseumPlayers("You have 30 seconds to recover from battle. Use it wisely");
			//echo("DEBUG SealBattle::Loop: Round 2 bots died, scheduling Round 3 spawn in 30 seconds");
			
			// Schedule countdown messages
			schedule("SealBattle::MessageColloseumPlayers(\"20 seconds remaining to recover...\");", 10);
			schedule("SealBattle::MessageColloseumPlayers(\"10 seconds remaining to recover...\");", 20);
			
			// Schedule Round 3 spawn after 30 seconds
			schedule("SealBattle::SpawnRound3(" @ %clientId @ ", \"" @ %pos @ "\", " @ %seal @ ", " @ %round @ ", \"" @ %name @ "\");", 30);
			return;
		}
		else
		{
			//echo("DEBUG SealBattle::Loop: Round 3 check failed - Round 2 bots still alive");
		}
	}
	else if(%round == 4)
	{
		// FIRST check if all players are dead - if so, end battle immediately
		// Run a quick death check before checking bot status
		SealBattle::LazyDeathCheck(%clientId);
		if($SealFighterDied)
		{
			//echo("DEBUG SealBattle::Loop: Round 4 - All players dead, ending battle immediately");
			// This will be handled by the $SealFighterDied check at the top of the function
			// But we need to return here to prevent the bot check from running
			return;
		}
		
		%fighter3Id = NEWgetClientByName("SealFighter3");
		%mage3Id = NEWgetClientByName("SealMage3");
		%guardian3Id = NEWgetClientByName("SealGuardian3");
		//echo("DEBUG SealBattle::Loop: Round 4 check (final round) - SealFighter3=" @ %fighter3Id @ ", SealMage3=" @ %mage3Id @ ", SealGuardian3=" @ %guardian3Id);
		
		if(%fighter3Id == -1 && %mage3Id == -1 && %guardian3Id == -1)
		{
			//echo("DEBUG SealBattle::Loop: All waves complete! Seal battle won!");
			
			// Get participant names for the success message
			%participantNames = SealBattle::GetParticipantNames();
			
			// Send success message with participant list
			if(%participantNames != "")
			{
				messageAll(2, "The final wave has been beaten! The brave soldier(s) of Kronos-" @ %participantNames @ ", have shattered the seal! We can all rest and remort safely...for now. ~wflag_capture.wav");
			}
			else
			{
				messageAll(2, "The final wave has been beaten! The seal has been shattered...for now. ~wflag_capture.wav");
			}
			
			// Increment and save seal value using centralized function
			%newSealValue = IncrementTotalSealValue();
			messageall(2,"The remort cap is now " @ %newSealValue @ "!");
			
			Saveworld();
			SealBattle::Conclude(%clientId, true);  // true = success, don't teleport back
			return;
		}
		else
		{
			//echo("DEBUG SealBattle::Loop: Round 4 check failed - Round 3 bots still alive");
		}
	}
	else
	{
		//echo("DEBUG SealBattle::Loop: No matching round condition - Round=" @ %round);
	}
	//if(%zone != "Colloseum") //$SealBattleActive == True && 
	//{
	//	if(NEWgetClientByName("SealGuardian") != -1)
	//		Player::Kill(NEWgetClientByName("SealGuardian"));
	//	if(NEWgetClientByName("SealMage") != -1)
	//		Player::Kill(NEWgetClientByName("SealMage"));
	//	if(NEWgetClientByName("SealFighter") != -1)
	//		Player::Kill(NEWgetClientByName("SealFighter"));
	//	//round 2
	//	if(NEWgetClientByName("SealGuardian1") != -1)
	//		Player::Kill(NEWgetClientByName("SealGuardian1"));
	//	if(NEWgetClientByName("SealMage1") != -1)
	//		Player::Kill(NEWgetClientByName("SealMage1"));
	//	if(NEWgetClientByName("SealFighter1") != -1)
	//		Player::Kill(NEWgetClientByName("SealFighter1"));
	//	///3rd rnd
	//	if(NEWgetClientByName("SealGuardian2") != -1)
	//		Player::Kill(NEWgetClientByName("SealGuardian2"));
	///	if(NEWgetClientByName("SealMage2") != -1)
	//		Player::Kill(NEWgetClientByName("SealMage2"));
	//	if(NEWgetClientByName("SealFighter2") != -1)
	//		Player::Kill(NEWgetClientByName("SealFighter2"));
	//	//round 3
	//	if(NEWgetClientByName("SealGuardian3") != -1)
	//		Player::Kill(NEWgetClientByName("SealGuardian3"));
	///	if(NEWgetClientByName("SealMage3") != -1)
	//		Player::Kill(NEWgetClientByName("SealMage3"));
	//	if(NEWgetClientByName("SealFighter3") != -1)
	//		Player::Kill(NEWgetClientByName("SealFighter3"));
	//	SealBattle::Conclude(%clientId);
	//	return;
	//}
	//if(%challengerzone != "Colloseum" && $SealBattleActive != true)
	//{
	//	for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
	//		Client::sendMessage(%cl, $MsgBeige, $Contestant @ " has died and failed at breaking the seal!");
	//	if(IsDead(%clientId))
	//		Game::playerSpawn(%clientId, True);
	//	%lospos = -3588 @ " " @ -2364 @ " " @ 354;
	//	GameBase::setPosition(%clientId, %lospos);
	//	Client::sendMessage(%clientId, $MsgWhite, "You have one minute to retrieve your pack before you are teleported out.");
	//if($SealFighterDied != true)
	//{
//		for(%i=0;%i<10;%i++)
//		schedule("SealBattle::LazyDeathCheck("@%clientId@");",%i/2,%player);
//		schedule("SealBattle::Loop("@%clientId@",\""@%pos@"\","@%seal@","@%round@","@$SealFighterDied@");",5);
//		}
//	}
//	
//	}
//	if(%zone != "Colloseum" && $SealBattleActive = true)
//	for(%i=0;%i<10;%i++)	
//	messageall(2,"" @ %name @ " has fled the battle to break the seal! All hope is lost...");
//	SealBattle::Conclude(%clientId);
//	return;
//	}
	if($SealFighterDied != true)
	{
		// Add initial delay before first death check to give player time to enter Colloseum
		// For Round 1, wait 10 seconds before starting death checks
		// For subsequent rounds, wait 2 seconds
		%initialDelay = 10;
		if(%round > 2)
			%initialDelay = 2;
		
		//echo("DEBUG SealBattle::Loop: Scheduling death checks and next loop iteration (round=" @ %round @ ", initialDelay=" @ %initialDelay @ " seconds)");
		
		for(%i=0;%i<10;%i++)
		schedule("SealBattle::LazyDeathCheck("@%clientId@");", %initialDelay + (%i/2), %player);
		schedule("SealBattle::Loop("@%clientId@",\""@%pos@"\","@%seal@","@%round@");", %initialDelay + 5);
	}
	else
	{
		//echo("DEBUG SealBattle::Loop: SealFighterDied=true, NOT scheduling next loop iteration");
	}
}

function SealBattle::SpawnRound2(%clientId, %pos, %seal, %round, %name)
{
	//echo("DEBUG SealBattle::SpawnRound2: Spawning Round 2 bots");
	
	// Send "round starting now" message to Colloseum players
	SealBattle::MessageColloseumPlayers("Wave " @ %round @ " is starting now!");
	
	%bot = 69;
	%bot2 = 70;
	%bot3 = 71;
	
	// Validate spawn indexes exist
	if($spawnIndex[%bot] == "" || $spawnIndex[%bot2] == "" || $spawnIndex[%bot3] == "")
	{
		//echo("ERROR: SealBattle::SpawnRound2 - Invalid spawn indexes: bot=" @ %bot @ ", bot2=" @ %bot2 @ ", bot3=" @ %bot3);
		return;
	}
	
	// Get participant names for wave announcement
	%participantNames = SealBattle::GetParticipantNames();
	if(%participantNames != "")
		messageall(2, "" @ %participantNames @ " are entering wave " @ %round @ ".");
	else
		messageall(2, "" @ %name @ " is entering wave " @ %round @ ".");
	
	AI::helper($spawnIndex[%bot],"SealFighter2","TempSpawn -3608 -2365 354 1",default);
	schedule("SealBattle::SetupBot(\"SealFighter2\", \"" @ %pos @ "\");", 0.5);
	AI::helper($spawnIndex[%bot2],"SealMage2","TempSpawn -3608 -2365 354 1",default);
	schedule("SealBattle::SetupBot(\"SealMage2\", \"" @ %pos @ "\");", 0.5);
	AI::helper($spawnIndex[%bot3],"SealGuardian2","TempSpawn -3608 -2365 354 1",default);
	schedule("SealBattle::SetupBot(\"SealGuardian2\", \"" @ %pos @ "\");", 0.5);
	
	%round++;
	//echo("DEBUG SealBattle::SpawnRound2: Round 2 spawned, round incremented to " @ %round);
	
	// Continue the loop with the new round
	SealBattle::Loop(%clientId, %pos, %seal, %round);
}

function SealBattle::SpawnRound3(%clientId, %pos, %seal, %round, %name)
{
	//echo("DEBUG SealBattle::SpawnRound3: Spawning Round 3 (final) bots");
	
	// Send "round starting now" message to Colloseum players
	SealBattle::MessageColloseumPlayers("Wave " @ %round @ " is starting now!");
	
	%bot = 72;
	%bot2 = 73;
	%bot3 = 74;
	
	// Validate spawn indexes exist
	if($spawnIndex[%bot] == "" || $spawnIndex[%bot2] == "" || $spawnIndex[%bot3] == "")
	{
		//echo("ERROR: SealBattle::SpawnRound3 - Invalid spawn indexes: bot=" @ %bot @ ", bot2=" @ %bot2 @ ", bot3=" @ %bot3);
		return;
	}
	
	// Get participant names for final wave announcement
	%participantNames = SealBattle::GetParticipantNames();
	if(%participantNames != "")
		messageall(2, "" @ %participantNames @ " are entering the final wave!");
	else
		messageall(2, "" @ %name @ " is entering the final wave!");
	
	AI::helper($spawnIndex[%bot],"SealFighter3","TempSpawn -3608 -2365 354 1",default);
	schedule("SealBattle::SetupBot(\"SealFighter3\", \"" @ %pos @ "\");", 0.5);
	AI::helper($spawnIndex[%bot2],"SealMage3","TempSpawn -3608 -2365 354 1",default);
	schedule("SealBattle::SetupBot(\"SealMage3\", \"" @ %pos @ "\");", 0.5);
	AI::helper($spawnIndex[%bot3],"SealGuardian3","TempSpawn -3608 -2365 354 1",default);
	schedule("SealBattle::SetupBot(\"SealGuardian3\", \"" @ %pos @ "\");", 0.5);
	
	%round++;
	//echo("DEBUG SealBattle::SpawnRound3: Round 3 spawned, round incremented to " @ %round);
	
	// Continue the loop with the new round
	SealBattle::Loop(%clientId, %pos, %seal, %round);
}

function SealBattle::LazyDeathCheck(%clientId)
{
	// Check if all participants are dead (check participant list, not just players in Colloseum)
	// This handles cases where players died and respawned elsewhere
	
	if($SealBattleParticipants == "")
	{
		// Fallback: if no participant list, check the initiator
		if(IsDead(%clientId))
		{
			$SealFighterDied = true;
		}
		return;
	}
	
	// Count all participants and check if they're all dead
	%aliveParticipantCount = 0;
	%totalParticipantCount = 0;
	%list = $SealBattleParticipants;
	
	// Parse comma-separated list
	while(String::len(%list) > 0)
	{
		%commaPos = String::findSubStr(%list, ",");
		if(%commaPos > 0)
		{
			%participantId = String::getSubStr(%list, 0, %commaPos);
			%list = String::getSubStr(%list, %commaPos + 1, 99999);
		}
		else
		{
			%participantId = %list;
			%list = "";
		}
		
		// Skip if invalid client ID
		if(%participantId == "" || %participantId == -1)
			continue;
		
		// Check if client still exists
		%clName = Client::getName(%participantId);
		if(%clName == "")
			continue;
		
		// Count this participant
		%totalParticipantCount++;
		if(!IsDead(%participantId))
			%aliveParticipantCount++;
	}
	
	// Only set SealFighterDied if we found participants AND they're all dead
	// This prevents setting it to true before participants have been added
	if(%totalParticipantCount > 0 && %aliveParticipantCount == 0)
	{
		//echo("DEBUG SealBattle::LazyDeathCheck: All " @ %totalParticipantCount @ " participant(s) are dead! Setting SealFighterDied=true");
		$SealFighterDied = true;
	}

}
function SealBattle::Conclude(%clientId, %success)
{
	// Get the zone description and house for finding all friendly players
	%zoneDesc = $SealBattleZone;  // This is now a zone description, not an ID
	%house = $SealBattleHouse;
	%lospos = "-3588 -2364 354";
	%outpos = "-335 -2339 65.5";
	
	// Find all friendly players who were in the seal battle zone and teleport them out
	if(%zoneDesc != "" && %zoneDesc != -1)
	{
		for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
		{
			// Skip AI bots
			if(isRPGAI(%cl))
				continue;
			
			// Check if player was in the seal battle zone (compare zone descriptions)
			// All players in Colloseum are considered friendly, regardless of house
			%clZoneId = fetchData(%cl, "zone");
			%clZoneDesc = Zone::getDesc(%clZoneId);
			if(%clZoneDesc != %zoneDesc)
				continue;
			
			// All players in Colloseum are friendly (no house check needed)
			// Clear lootbag flag
			storeData(%cl, "noDropLootbagFlag", false);
			
			// Spawn player if dead, then teleport them back into Colloseum to get their pack
			if(IsDead(%cl))
			{
				Game::playerSpawn(%cl, True);
				// Schedule position fix after spawn completes - teleport to Colloseum entrance
				schedule("SealBattle::FixSpawnPosition(" @ %cl @ ", \"" @ %lospos @ "\");", 0.5, %cl);
			}
			
			if(!%success)
			{
				// Failure: Teleport to pack retrieval location (Colloseum entrance) first, then out after 1 minute
				// If player was already alive, teleport them now; if dead, position was fixed above
				if(!IsDead(%cl))
				{
					%playerObj = Client::getOwnedObject(%cl);
					if(%playerObj != -1)
						GameBase::setPosition(%playerObj, %lospos);
				}
				Client::sendMessage(%cl, $MsgWhite, "You have one minute to retrieve your pack before you are teleported out.");
				schedule("SealBattle::TeleportOut(" @ %cl @ ");", 60, %cl);
			}
			else
			{
				// Success: Teleport out immediately
				// If player was dead, wait for spawn to complete first
				if(IsDead(%cl))
				{
					schedule("SealBattle::TeleportOutSuccess(" @ %cl @ ", \"" @ %outpos @ "\");", 0.5, %cl);
				}
				else
				{
					%playerObj = Client::getOwnedObject(%cl);
					if(%playerObj != -1)
						GameBase::setPosition(%playerObj, %outpos);
					Client::sendMessage(%cl, $MsgWhite, "The seal battle has ended. You have been teleported out.");
				}
			}
		}
	}
	else
	{
		// Fallback: if zone not stored, just handle the initiator
		storeData(%clientId, "noDropLootbagFlag", false);
		if(IsDead(%clientId))
		{
			Game::playerSpawn(%clientId, True);
			// Schedule position fix after spawn completes
			schedule("SealBattle::FixSpawnPosition(" @ %clientId @ ", \"" @ %lospos @ "\");", 0.5, %clientId);
		}
		
		if(!%success)
		{
			// Failure: Teleport to pack retrieval location (Colloseum entrance) first, then out after 1 minute
			if(!IsDead(%clientId))
			{
				%playerObj = Client::getOwnedObject(%clientId);
				if(%playerObj != -1)
					GameBase::setPosition(%playerObj, %lospos);
			}
			Client::sendMessage(%clientId, $MsgWhite, "You have one minute to retrieve your pack before you are teleported out.");
			schedule("SealBattle::TeleportOut(" @ %clientId @ ");", 60, %clientId);
		}
		else
		{
			// Success: Teleport out immediately
			if(IsDead(%clientId))
			{
				schedule("SealBattle::TeleportOutSuccess(" @ %clientId @ ", \"" @ %outpos @ "\");", 0.5, %clientId);
			}
			else
			{
				%playerObj = Client::getOwnedObject(%clientId);
				if(%playerObj != -1)
					GameBase::setPosition(%playerObj, %outpos);
				Client::sendMessage(%clientId, $MsgWhite, "The seal battle has ended. You have been teleported out.");
			}
		}
	}
	
	// Teleport dead participants back into Colloseum to retrieve packs (on both success and failure)
	// This handles participants who may have respawned elsewhere and aren't in Colloseum anymore
	if($SealBattleParticipants != "")
	{
		%colloseumEntrance = "-3588 -2364 354";
		//echo("DEBUG SealBattle::Conclude: Teleporting dead participants back for pack retrieval: " @ $SealBattleParticipants);
		
		// Track which participants we've already handled in the zone loop above
		%handledParticipants = "";
		
		// First, mark all participants currently in Colloseum as already handled
		if(%zoneDesc != "" && %zoneDesc != -1)
		{
			for(%cl = Client::getFirst(); %cl != -1; %cl = Client::getNext(%cl))
			{
				if(isRPGAI(%cl))
					continue;
				
				%clZoneId = fetchData(%cl, "zone");
				%clZoneDesc = Zone::getDesc(%clZoneId);
				if(%clZoneDesc == %zoneDesc)
				{
					// This participant is in Colloseum and was handled by the zone loop above
					%handledParticipants = AddToCommaList(%handledParticipants, %cl);
				}
			}
		}
		
		// Parse comma-separated list of all participants
		%list = $SealBattleParticipants;
		while(String::len(%list) > 0)
		{
			%commaPos = String::findSubStr(%list, ",");
			if(%commaPos > 0)
			{
				%participantId = String::getSubStr(%list, 0, %commaPos);
				%list = String::getSubStr(%list, %commaPos + 1, 99999);
			}
			else
			{
				%participantId = %list;
				%list = "";
			}
			
			// Skip if invalid client ID
			if(%participantId == "" || %participantId == -1)
				continue;
			
			// Check if client still exists
			%clName = Client::getName(%participantId);
			if(%clName == "")
				continue;
			
			// Check if this participant was already handled by the zone loop
			%alreadyHandled = false;
			%handledList = %handledParticipants;
			while(String::len(%handledList) > 0)
			{
				%handledCommaPos = String::findSubStr(%handledList, ",");
				if(%handledCommaPos > 0)
				{
					%handledId = String::getSubStr(%handledList, 0, %handledCommaPos);
					%handledList = String::getSubStr(%handledList, %handledCommaPos + 1, 99999);
				}
				else
				{
					%handledId = %handledList;
					%handledList = "";
				}
				
				if(%handledId == %participantId)
				{
					%alreadyHandled = true;
					break;
				}
			}
			
			// Skip if already handled by zone loop
			if(%alreadyHandled)
			{
				//echo("DEBUG SealBattle::Conclude: Participant " @ %clName @ " (" @ %participantId @ ") already handled by zone loop, skipping");
				continue;
			}
			
			// This participant wasn't in Colloseum (likely respawned elsewhere) - teleport them back
			//echo("DEBUG SealBattle::Conclude: Participant " @ %clName @ " (" @ %participantId @ ") not in Colloseum, teleporting back");
			
			// Clear lootbag flag
			storeData(%participantId, "noDropLootbagFlag", false);
			
			// Spawn if dead, then teleport
			if(IsDead(%participantId))
			{
				// Don't set lastzone to Colloseum to prevent air spawns
				storeData(%participantId, "lastzone", "");
				Game::playerSpawn(%participantId, True);
				// Schedule teleport after spawn completes
				schedule("SealBattle::TeleportParticipantBack(" @ %participantId @ ", \"" @ %colloseumEntrance @ "\");", 0.5, %participantId);
			}
			else
			{
				// Already alive, teleport immediately
				SealBattle::TeleportParticipantBack(%participantId, %colloseumEntrance);
			}
			
			// On failure, schedule teleport out after 1 minute (same as zone loop)
			if(!%success)
			{
				Client::sendMessage(%participantId, $MsgWhite, "You have one minute to retrieve your pack before you are teleported out.");
				schedule("SealBattle::TeleportOut(" @ %participantId @ ");", 60, %participantId);
			}
		}
	}
	
	$SealFighterDied = false;
	$SealBattleActive = false;
	
	// Clear seal battle zone and house tracking
	$SealBattleZone = "";
	$SealBattleHouse = "";
	$SealBattleParticipants = "";
}

function SealBattle::FixSpawnPosition(%clientId, %targetPos)
{
	// Fix spawn position for a player who just respawned during seal battle
	%playerObj = Client::getOwnedObject(%clientId);
	if(%playerObj != -1)
	{
		GameBase::setPosition(%playerObj, %targetPos);
		//echo("DEBUG SealBattle::FixSpawnPosition: Fixed spawn position for " @ Client::getName(%clientId) @ " to " @ %targetPos);
	}
}

function SealBattle::TeleportParticipantBack(%clientId, %targetPos)
{
	// Teleport a participant back into Colloseum for pack retrieval
	// Clear lootbag flag so they can pick up their pack
	storeData(%clientId, "noDropLootbagFlag", false);
	
	%playerObj = Client::getOwnedObject(%clientId);
	if(%playerObj != -1)
	{
		GameBase::setPosition(%playerObj, %targetPos);
		Client::sendMessage(%clientId, $MsgWhite, "You have been teleported back to retrieve your pack. Use #recall or transport out when you are finished.");
		//echo("DEBUG SealBattle::TeleportParticipantBack: Teleported " @ Client::getName(%clientId) @ " (" @ %clientId @ ") to " @ %targetPos);
	}
}

function SealBattle::TeleportOutSuccess(%clientId, %outpos)
{
	// Teleport player out after successful seal battle (called after respawn completes)
	%playerObj = Client::getOwnedObject(%clientId);
	if(%playerObj != -1)
		GameBase::setPosition(%playerObj, %outpos);
	Client::sendMessage(%clientId, $MsgWhite, "The seal battle has ended. You have been teleported out.");
}

function SealBattle::TeleportOut(%clientId)
{
	// Teleport player out after 1 minute
	%outpos = "-335 -2339 65.5";
	%playerObj = Client::getOwnedObject(%clientId);
	if(%playerObj != -1)
		GameBase::setPosition(%playerObj, %outpos);
	Client::sendMessage(%clientId, $MsgWhite, "You have been teleported out.");
}

function SealBattle::SetupBot(%botName, %pos)
{
	//echo("DEBUG SealBattle::SetupBot: Setting up bot " @ %botName);
	%aiId = NEWgetClientByName(%botName);
	if(%aiId == -1 || %aiId == "")
	{
		//echo("ERROR SealBattle::SetupBot: Could not find bot " @ %botName @ " (aiId=" @ %aiId @ ")");
		return;
	}
	
	//echo("DEBUG SealBattle::SetupBot: Found bot " @ %botName @ " with ID " @ %aiId);
	
	// Get current HP before setting new values
	%oldHP = fetchData(%aiId, "HP");
	%playerObj = Client::getOwnedObject(%aiId);
	if(%playerObj != -1)
		%currentHP = GameBase::getDamageLevel(%playerObj);
	else
		%currentHP = "N/A";
	//echo("DEBUG SealBattle::SetupBot: " @ %botName @ " current HP (stored)=" @ %oldHP @ ", HP (actual)=" @ %currentHP);
	
	storeData(%aiId, "botAttackMode", 1);
	storeData(%aiId, "tmpbotdata", %pos);
	storeData(%aiId, "noDropLootbagFlag", True);
	storeData(%aiId, "AImoveChance", 1);
	storeData(%aiId, "SealBattleBot", true);  // Flag this bot as a seal battle bot
	%mult = SealBattle::GetEnemyStrengthMultiplier();
	%hp = floor(110 * %mult);
	%dmg = floor(25* %mult);
	%def = floor(10* %mult);
	
	storeData(%aiId, "HP", %hp);
	storeData(%aiId, "DMG", %dmg);
	storeData(%aiId, "DEF", %def);
	
	//echo("DEBUG SealBattle::SetupBot: " @ %botName @ " (" @ %aiId @ ") - Setting HP=" @ %hp @ ", DMG=" @ %dmg @ ", DEF=" @ %def @ ", mult=" @ %mult);
	
	// Refresh stats to apply HP/DEF
	RefreshAll(%aiId);
	
	// IMPORTANT: After RefreshAll, directly set damage level to 0.0 (full health)
	// This ensures the bot is at full health regardless of MaxHP calculation
	%playerObj = Client::getOwnedObject(%aiId);
	if(%playerObj != -1)
	{
		GameBase::setDamageLevel(%playerObj, 0.0);
		//echo("DEBUG SealBattle::SetupBot: " @ %botName @ " - Set damage level to 0.0 (full health)");
	}
	
	// Check HP after RefreshAll
	%newHP = fetchData(%aiId, "HP");
	if(%playerObj != -1)
		%newActualHP = GameBase::getDamageLevel(%playerObj);
	else
		%newActualHP = "N/A";
	//echo("DEBUG SealBattle::SetupBot: " @ %botName @ " after RefreshAll - HP (stored)=" @ %newHP @ ", HP (actual)=" @ %newActualHP);
	
	// Display comprehensive stats for balancing (similar to #getstats)
	%def = fetchData(%aiId, "DEF");
	%mdef = fetchData(%aiId, "MDEF");
	%atk = fetchData(%aiId, "ATK");
	%maxHP = fetchData(%aiId, "MaxHP");
	%hp = fetchData(%aiId, "HP");
	%maxMANA = fetchData(%aiId, "MaxMANA");
	%mana = fetchData(%aiId, "MANA");
	%maxWeight = fetchData(%aiId, "MaxWeight");
	%weight = fetchData(%aiId, "Weight");
	%lck = AddPoints(%aiId, 2);
	%stance = fetchData(%aiId, "Stance");
	%overweightStep = fetchData(%aiId, "OverweightStep");
	%overweightPenalty = (%overweightStep * 7.0);
	%storedDMG = fetchData(%aiId, "DMG");
	
	echo("=== SealBattle Bot Stats: " @ %botName @ " (ID: " @ %aiId @ ") ===");
	echo("  Multiplier: " @ %mult);
	echo("  DEF: " @ %def @ "  MDEF: " @ %mdef @ "  ATK: " @ %atk);
	echo("  HP: " @ %hp @ " / " @ %maxHP @ "  MANA: " @ %mana @ " / " @ %maxMANA);
	echo("  DMG (stored): " @ %storedDMG);
	echo("  Weight: " @ %weight @ " / " @ %maxWeight @ "  LCK: " @ %lck);
	if(%stance != "")
		echo("  Stance: " @ %stance);
	if(%overweightStep > 0)
		echo("  Overweight Penalty: " @ %overweightPenalty @ "%");
	echo("==========================================");
	
	// Verify bot still exists after setup
	%verifyId = NEWgetClientByName(%botName);
	if(%verifyId == -1 || %verifyId == "")
	{
		//echo("ERROR SealBattle::SetupBot: Bot " @ %botName @ " disappeared after setup! (was " @ %aiId @ ")");
	}
	else if(%verifyId != %aiId)
	{
		//echo("WARNING SealBattle::SetupBot: Bot " @ %botName @ " ID changed from " @ %aiId @ " to " @ %verifyId);
	}
	else
	{
		//echo("DEBUG SealBattle::SetupBot: " @ %botName @ " setup complete and verified (ID=" @ %aiId @ ")");
	}
}

// Stub functions for Duel system - returns false/does nothing since dueling system is not used
// These are called by playerdamage.cs but we don't have a dueling system
function Duel::isDueling(%clientId)
{
	return false;
}

function Duel::endDuel(%pass)
{
	// Stub - does nothing since dueling system is not used
}