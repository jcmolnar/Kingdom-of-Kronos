//Colloseum / Seal: Variables
//- Every x remorts players will have to break their seal to remort. This variable controls the amount
//   needed. Players have to break their seal on remort 0, and then every Colloseum::StepCount after.
$Seal::StepCount = 20;
//- Global variables that are throughout the new system; exist here to be declared. No touchy!
$Colloseum::Mode = "";
$Colloseum::Client = "";
$Colloseum::Round = "";

//Seal: Rewards
//- Seal rewards are granted on a per step basis: Step 0 = Remort 0, Step 1 = Remort * $Seal::StepCount, Step 2 = Remort * ($Seal::StepCount * 2)
//- Use "" for no reward. Note, do not grant EXP, player remorts shortly after.
$Colloseum::sealReward[0] = "COINS 50000";
$Colloseum::sealReward[1] = "DuelCard 1 COINS 500000";
$Colloseum::sealReward[2] = "DuelCard 1 COINS 1000000";
$Colloseum::sealReward[3] = "DuelCard 1 COINS 2000000";
$Colloseum::sealReward[4] = "DuelCard 1 COINS 4000000";
$Colloseum::sealReward[5] = "DuelCard 1 COINS 8000000";

//Colloseum / Seal: No-Cast List
// - These spells cannot be casted while in the colloseum / seal.
$Colloseum::noCast[teleport] = true;
$Colloseum::noCast[telelos] = true;
$Colloseum::noCast[transport] = true;
$Colloseum::noCast[advtransport] = true;
$Colloseum::noCast[mimic] = true;
$Colloseum::noCast[masstransport] = true;
$Colloseum::noCast[heavystep] = true;
$Colloseum::noCast[airblast] = true;
$Colloseum::noCast[airwarp] = true;	

//Colloseum: Ranks & Loadouts
// - Each Rank must have three accompaning loadouts
// - 1 Spawns, 2 Spawns, 3 Spawns, then 1 2 & 3 Spawn.
// - Names / Armors are determined randomly
// - The rewards are given upon the completion of that rank of the colloseum
$Colloseum::Rank[0] = "Newbie";
$Colloseum::colloseumReward[0] = "";
$Colloseum::Loadout[0, 1] = "CLASS Fighter LVL 50 LCK 1 WarHammer 1";
$Colloseum::Loadout[0, 2] = "CLASS Fighter LVL 75 LCK 1 Claymore 1";
$Colloseum::Loadout[0, 3] = "CLASS Fighter LVL 100 LCK 1 Trident 1";

$Colloseum::Rank[1] = "Adventurer";
$Colloseum::colloseumReward[1] = "";
$Colloseum::Loadout[1, 1] = "CLASS Random LVL 125 LCK 1 SteelBlade 1";
$Colloseum::Loadout[1, 2] = "CLASS Random LVL 175 LCK 1 SteelSlicer 1";
$Colloseum::Loadout[1, 3] = "CLASS Random LVL 225 LCK 1 SteelFlail 1";

$Colloseum::Rank[2] = "Soldier";
$Colloseum::colloseumReward[2] = "";
$Colloseum::Loadout[2, 1] = "CLASS Random LVL 275 LCK 1 SteelFlail 1";
$Colloseum::Loadout[2, 2] = "CLASS Random LVL 325 LCK 1 SteelBlade 1";
$Colloseum::Loadout[2, 3] = "CLASS Random LVL 375 LCK 1 SteelSlicer 1";

$Colloseum::Rank[3] = "Gladiator";
$Colloseum::colloseumReward[3] = "";
$Colloseum::Loadout[3, 1] = "CLASS Random LVL 300 RemortStep 1 LCK 2 SteelBlade 1";
$Colloseum::Loadout[3, 2] = "CLASS Random LVL 400 RemortStep 1 LCK 2 HunterBow 1 HeavyArrow 500";
$Colloseum::Loadout[3, 3] = "CLASS Random LVL 500 RemortStep 1 LCK 2 TitaniumCrozier 1";

$Colloseum::Rank[4] = "Star";
$Colloseum::colloseumReward[4] = "";
$Colloseum::Loadout[4, 1] = "CLASS Random LVL 400 RemortStep 3 LCK 2 TitaniumEdge 1";
$Colloseum::Loadout[4, 2] = "CLASS Random LVL 500 RemortStep 3 LCK 2 TitaniumLance 1";
$Colloseum::Loadout[4, 3] = "CLASS Random LVL 600 RemortStep 3 LCK 2 TitaniumCrozier 1";

$Colloseum::Rank[5] = "Titan";
$Colloseum::colloseumReward[5] = "";
$Colloseum::Loadout[5, 1] = "CLASS Random LVL 500 RemortStep 5 LCK 2 TitaniumLance 1";
$Colloseum::Loadout[5, 2] = "CLASS Random LVL 600 RemortStep 5 LCK 2 SteelVault 1 SteelArrow 500";
$Colloseum::Loadout[5, 3] = "CLASS Random LVL 700 RemortStep 5 LCK 2 TitaniumCrozier 1";

$Colloseum::Rank[6] = "Avenger";
$Colloseum::colloseumReward[6] = "";
$Colloseum::Loadout[6, 1] = "CLASS Random LVL 600 RemortStep 7 LCK 3 TitaniumLance 1";
$Colloseum::Loadout[6, 2] = "CLASS Random LVL 700 RemortStep 7 LCK 3 TitaniumCrozier 1";
$Colloseum::Loadout[6, 3] = "CLASS Random LVL 800 RemortStep 7 LCK 3 SteelVault 1 SteelArrow 500";

$Colloseum::Rank[7] = "Private";
$Colloseum::colloseumReward[7] = "";
$Colloseum::Loadout[7, 1] = "CLASS Random LVL 700 RemortStep 9 LCK 3 MythrilSledge 1";
$Colloseum::Loadout[7, 2] = "CLASS Random LVL 800 RemortStep 9 LCK 3 MythrilSplitter 1";
$Colloseum::Loadout[7, 3] = "CLASS Random LVL 900 RemortStep 9 LCK 3 MythrilRapier 1";

$Colloseum::Rank[8] = "Private 1st Class";
$Colloseum::colloseumReward[8] = "";
$Colloseum::Loadout[8, 1] = "CLASS Random LVL 1000 RemortStep 12 LCK 3 TitaniumSaint 1 TitaniumArrow 500";
$Colloseum::Loadout[8, 2] = "CLASS Random LVL 1250 RemortStep 12 LCK 3 MythrilRapier 1";
$Colloseum::Loadout[8, 3] = "CLASS Random LVL 1500 RemortStep 12 LCK 3 MythrilSledge 1";

$Colloseum::Rank[9] = "Corporal";
$Colloseum::colloseumReward[9] = "";
$Colloseum::Loadout[9, 1] = "CLASS Random LVL 1750 RemortStep 15 LCK 4 MythrilSledge 1";
$Colloseum::Loadout[9, 2] = "CLASS Random LVL 2000 RemortStep 15 LCK 4 MythrilRapier 1";
$Colloseum::Loadout[9, 3] = "CLASS Random LVL 2250 RemortStep 15 LCK 4 TitaniumSaint 1 TitaniumArrow 500";

$Colloseum::Rank[10] = "Sergeant";
$Colloseum::colloseumReward[10] = "";
$Colloseum::Loadout[10, 1] = "CLASS Random LVL 2250 RemortStep 18 LCK 4 DiamondBattleAxe 1";
$Colloseum::Loadout[10, 2] = "CLASS Random LVL 2500 RemortStep 18 LCK 4 DiamondScimtar 1";
$Colloseum::Loadout[10, 3] = "CLASS Random LVL 2750 RemortStep 18 LCK 4 DiamondSplatter 1";

$Colloseum::Rank[11] = "Staff Sergeant";
$Colloseum::colloseumReward[11] = "";
$Colloseum::Loadout[11, 1] = "CLASS Random LVL 2750 RemortStep 21 LCK 5 DiamondScimtar 1";
$Colloseum::Loadout[11, 2] = "CLASS Random LVL 3000 RemortStep 21 LCK 5 DiamondSplatter 1";
$Colloseum::Loadout[11, 3] = "CLASS Random LVL 3250 RemortStep 21 LCK 5 MythrilArc 1 MythrilArrow 500";

$Colloseum::Rank[12] = "Technical Sergeant";
$Colloseum::colloseumReward[12] = "";
$Colloseum::Loadout[12, 1] = "CLASS Random LVL 3250 RemortStep 24 LCK 5 MythrilArc 1 MythrilArrow 500";
$Colloseum::Loadout[12, 2] = "CLASS Random LVL 3500 RemortStep 24 LCK 5 DiamondSplatter 1";
$Colloseum::Loadout[12, 3] = "CLASS Random LVL 3750 RemortStep 24 LCK 5 DiamondBattleAxe 1";

$Colloseum::Rank[13] = "Master Sergeant";
$Colloseum::colloseumReward[13] = "";
$Colloseum::Loadout[13, 1] = "CLASS Random LVL 3750 RemortStep 27 LCK 6 TerminusEst 1";
$Colloseum::Loadout[13, 2] = "CLASS Random LVL 4000 RemortStep 27 LCK 6 AecoSeori 1";
$Colloseum::Loadout[13, 3] = "CLASS Random LVL 4250 RemortStep 27 LCK 6 MorningStar 1";

$Colloseum::Rank[14] = "Sergeant Major";
$Colloseum::colloseumReward[14] = "";
$Colloseum::Loadout[14, 1] = "CLASS Random LVL 4250 RemortStep 30 LCK 6 TerminusEst 1";
$Colloseum::Loadout[14, 2] = "CLASS Random LVL 4500 RemortStep 30 LCK 6 AecoSeori 1";
$Colloseum::Loadout[14, 3] = "CLASS Random LVL 4750 RemortStep 30 LCK 6 DarkComet 1 DiamondArrow 500";

$Colloseum::Rank[15] = "2nd Lieutenant";
$Colloseum::colloseumReward[15] = "";
$Colloseum::Loadout[15, 1] = "CLASS Random LVL 4750 RemortStep 33 LCK 7 TerminusEst 1";
$Colloseum::Loadout[15, 2] = "CLASS Random LVL 5000 RemortStep 33 LCK 7 DarkComet 1 DiamondArrow 500";
$Colloseum::Loadout[15, 3] = "CLASS Random LVL 5250 RemortStep 33 LCK 7 MorningStar 1";

$Colloseum::Rank[16] = "1st Lieutenant";
$Colloseum::colloseumReward[16] = "";
$Colloseum::Loadout[16, 1] = "CLASS Random LVL 5250 RemortStep 36 LCK 7 DarkComet 1 DiamondArrow 500";
$Colloseum::Loadout[16, 2] = "CLASS Random LVL 5500 RemortStep 36 LCK 7 AecoSeori 1";
$Colloseum::Loadout[16, 3] = "CLASS Random LVL 5750 RemortStep 36 LCK 7 MorningStar 1";

$Colloseum::Rank[17] = "Captain";
$Colloseum::colloseumReward[17] = "";
$Colloseum::Loadout[17, 1] = "CLASS Random LVL 5750 RemortStep 39 LCK 8 TerminusEst 1";
$Colloseum::Loadout[17, 2] = "CLASS Random LVL 6000 RemortStep 39 LCK 8 AecoSeori 1";
$Colloseum::Loadout[17, 3] = "CLASS Random LVL 6250 RemortStep 39 LCK 8 MorningStar 1";

$Colloseum::Rank[18] = "Major";
$Colloseum::colloseumReward[18] = "";
$Colloseum::Loadout[18, 1] = "CLASS Random LVL 6250 RemortStep 42 LCK 8 TerminusEst 1";
$Colloseum::Loadout[18, 2] = "CLASS Random LVL 6500 RemortStep 42 LCK 8 AecoSeori 1";
$Colloseum::Loadout[18, 3] = "CLASS Random LVL 6750 RemortStep 42 LCK 8 MorningStar 1";

$Colloseum::Rank[19] = "Lieutenant Colonel";
$Colloseum::colloseumReward[19] = "";
$Colloseum::Loadout[19, 1] = "CLASS Random LVL 6750 RemortStep 45 LCK 9 TerminusEst 1";
$Colloseum::Loadout[19, 2] = "CLASS Random LVL 7000 RemortStep 45 LCK 9 AecoSeori 1";
$Colloseum::Loadout[19, 3] = "CLASS Random LVL 7250 RemortStep 45 LCK 9 MorningStar 1";

$Colloseum::Rank[20] = "Colonel";
$Colloseum::colloseumReward[20] = "";
$Colloseum::Loadout[20, 1] = "CLASS Random LVL 7250 RemortStep 48 LCK 9 TerminusEst 1";
$Colloseum::Loadout[20, 2] = "CLASS Random LVL 7500 RemortStep 48 LCK 9 DarkComet 1 AngelStorm 500";
$Colloseum::Loadout[20, 3] = "CLASS Random LVL 7750 RemortStep 48 LCK 9 MorningStar 1";

$Colloseum::Rank[21] = "Brigadier General";
$Colloseum::colloseumReward[21] = "";
$Colloseum::Loadout[21, 1] = "CLASS Random LVL 7750 RemortStep 51 LCK 10 TerminusEst 1";
$Colloseum::Loadout[21, 2] = "CLASS Random LVL 8000 RemortStep 51 LCK 10 AecoSeori 1";
$Colloseum::Loadout[21, 3] = "CLASS Random LVL 8250 RemortStep 51 LCK 10 MorningStar 1";

$Colloseum::Rank[22] = "Major General";
$Colloseum::colloseumReward[22] = "";
$Colloseum::Loadout[22, 1] = "CLASS Random LVL 8250 RemortStep 54 LCK 11 DarkComet 1 AngelStorm 500";
$Colloseum::Loadout[22, 2] = "CLASS Random LVL 8500 RemortStep 54 LCK 12 AecoSeori 1";
$Colloseum::Loadout[22, 3] = "CLASS Random LVL 8750 RemortStep 54 LCK 13 MorningStar 1";

$Colloseum::Rank[23] = "Lieutenant General";
$Colloseum::colloseumReward[23] = "";
$Colloseum::Loadout[23, 1] = "CLASS Random LVL 8750 RemortStep 57 LCK 13 TerminusEst 1";
$Colloseum::Loadout[23, 2] = "CLASS Random LVL 9000 RemortStep 57 LCK 14 AecoSeori 1";
$Colloseum::Loadout[23, 3] = "CLASS Random LVL 9250 RemortStep 57 LCK 15 MorningStar 1";

$Colloseum::Rank[24] = "General";
$Colloseum::colloseumReward[24] = "";
$Colloseum::Loadout[24, 1] = "CLASS Random LVL 9250 RemortStep 60 LCK 15 TerminusEst 1";
$Colloseum::Loadout[24, 2] = "CLASS Random LVL 9500 RemortStep 60 LCK 15 AecoSeori 1";
$Colloseum::Loadout[24, 3] = "CLASS Random LVL 9750 RemortStep 60 LCK 15 DarkComet 1 AngelStorm 500";

$Colloseum::Rank[25] = "General Of Kronos";

//Colloseum / Seal: Defined Armors
//- Must be the name of a bot that has an armor, otherwise will error out
//- Serves no purpose other than to give colloseum and seal battles a random feel
//- Ideally, you need only one bot per armor type. numArmors must match the total.
$Colloseum::armorArray[1] = "MoonBreaker";
$Colloseum::armorArray[2] = "MoonBreaker";
$Colloseum::armorArray[3] = "MoonBreaker";
$Colloseum::armorArray[4] = "MoonBreaker"; 
$Colloseum::armorArray[5] = "MoonBreaker";
$Colloseum::armorArray[6] = "MoonBreaker";
$Colloseum::armorArray[7] = "MoonBreaker";
$Colloseum::armorArray[8] = "MoonBreaker";
$Colloseum::armorArray[9] = "MoonBreaker";

//Colloseum / Seal: Defined Names
//- The defined names for enemies that players will face while breaking seals
//- This is the display name for the bot. You must update the total in the getName function
$Colloseum::nameArray[1] = "Taf RepuS"; 
$Colloseum::nameArray[2] = "Panda";
$Colloseum::nameArray[3] = "Amanda";
$Colloseum::nameArray[4] = "Nexus";
$Colloseum::nameArray[5] = "Sneezy";
$Colloseum::nameArray[6] = "Sleepy";
$Colloseum::nameArray[7] = "Dopey";
$Colloseum::nameArray[8] = "Doc";
$Colloseum::nameArray[9] = "Happy";
$Colloseum::nameArray[10] = "Bashful";
$Colloseum::nameArray[11] = "Grumpy";
$Colloseum::nameArray[12] = "Bubba";
$Colloseum::nameArray[13] = "Sergeant";
$Colloseum::nameArray[14] = "Chew";
$Colloseum::nameArray[15] = "Bones";
$Colloseum::nameArray[16] = "Leonidis";
$Colloseum::nameArray[17] = "Freckles";
$Colloseum::nameArray[18] = "Eight-Ball";
$Colloseum::nameArray[19] = "Orion";
$Colloseum::nameArray[20] = "Full-Stop";
$Colloseum::nameArray[21] = "Snip";
$Colloseum::nameArray[22] = "DotCom";
$Colloseum::nameArray[23] = "Marbles";
$Colloseum::nameArray[24] = "SunSpot";
$Colloseum::nameArray[25] = "Nickles";
$Colloseum::nameArray[26] = "Hotdog";
$Colloseum::nameArray[27] = "Fetch";
$Colloseum::nameArray[28] = "Cinders";
$Colloseum::nameArray[29] = "Lollipop";
$Colloseum::nameArray[30] = "Scout";
$Colloseum::nameArray[31] = "Domino";
$Colloseum::nameArray[32] = "Gobstopper";
$Colloseum::nameArray[33] = "Tic";
$Colloseum::nameArray[34] = "Tac";
$Colloseum::nameArray[35] = "Toe";
$Colloseum::nameArray[36] = "Nipper";
$Colloseum::nameArray[37] = "Oddball";
$Colloseum::nameArray[38] = "Tippy";
$Colloseum::nameArray[39] = "Nugget";
$Colloseum::nameArray[40] = "Fang";
$Colloseum::nameArray[41] = "Wind-Chill";
$Colloseum::nameArray[42] = "Smokey";
$Colloseum::nameArray[43] = "Chief";
$Colloseum::nameArray[44] = "Soho";
$Colloseum::nameArray[45] = "Drifter";
$Colloseum::nameArray[46] = "Rufus";
$Colloseum::nameArray[47] = "Cosmo";
$Colloseum::nameArray[48] = "Grinder";
$Colloseum::nameArray[49] = "Gideon";
$Colloseum::nameArray[50] = "Snicker";
$Colloseum::nameArray[51] = "Little-Dipper";
$Colloseum::nameArray[52] = "Zephyr";
$Colloseum::nameArray[53] = "Otto";
$Colloseum::nameArray[54] = "Hydrant";
$Colloseum::nameArray[55] = "Ashes";
$Colloseum::nameArray[56] = "Typhoon";
$Colloseum::nameArray[57] = "Snake-Eyes";
$Colloseum::nameArray[58] = "Whirlwind";
$Colloseum::nameArray[59] = "Diggity";
$Colloseum::nameArray[60] = "Big-Dipper";
$Colloseum::nameArray[61] = "Splatter";
$Colloseum::nameArray[62] = "Cue-Ball";

function Colloseum::getName()
{
	//return floor(getRandom() * (Max - 1)) + 1
	return $Colloseum::nameArray[floor(getRandom() * 62) + 1];
}

function Colloseum::GetArmor()
{
	//return floor(getRandom() * (Max - 1)) + 1
	return $Colloseum::armorArray[floor(getRandom() * 9) + 1];
}

function Colloseum::isSealStep(%clientId)
{
	%remort = fetchData(%clientId, "RemortStep");
	if(%remort == 0)
		return true;
	else if(%remort == Colloseum::getRemortStep(%remort))
		return true;
	
	return false;
}

function Colloseum::getRemortStep(%remort)
{
	if(%remort == 0)
		return 0;
	else if(%remort <= $Seal::StepCount)
		return $Seal::StepCount;
	return $Seal::StepCount * Colloseum::getCurrentStep(%remort);
}

function Colloseum::getCurrentStep(%remort)
{
	if(%remort == 0)
		return 0;
		
	if(%remort % $Seal::StepCount == 0)
		return floor(%remort / $Seal::StepCount);
	else
		return floor(%remort / $Seal::StepCount) + 1;
}

function Colloseum::getRemortsLeft(%clientId)
{
	%remort = fetchData(%clientId, "RemortStep");
	if(%remort == 0)
		return 0;

	return Colloseum::getRemortStep(%remort) - %remort;
}

function Colloseum::StartSeal(%clientId)
{
	%pos = -3588 @ " " @ -2364 @ " " @ 354;
	GameBase::setPosition(%clientId, %pos);
	
	$Colloseum::Mode = "Seal";
	$Colloseum::Client = %clientId;
	storeData(%clientId, "noDropLootbagFlag", true);
	
	%name = Client::getName(%clientId);
	if(!String::ICompare(fetchData(%clientId, "Race"), "Female"))
		%adj = her;
	else
		%adj = his;
	MessageAll($MsgBeige, %name @ " is trying to break " @ %adj @ " seal! Type #eyes " @ %name @ " to watch " @ %adj @ " progress and #revert to stop!");	
	
	for(%i = 1; %i <= 3; %i++)
		schedule("Colloseum::spawnSeal(" @ %clientId @ ", " @ %i @ ");", (%i * 0.33));
}

function Colloseum::EndSeal(%clientId, %pass)
{
	%step = Colloseum::getCurrentStep(fetchData(%clientId, "RemortStep"));
		
	if(%pass)
	{
		if($Colloseum::sealReward[%step] != "")
			GiveThisStuff(%clientId, $Colloseum::sealReward[%step], true);
	
		Client::sendMessage(%clientId, $MsgRed, "Congratulations! You have broken your seal! You will remort in 90 seconds");
		storeData(%clientId, "currentlyRemorting", true);
		schedule("DoRemort(" @ %clientId @ ");", 90, %clientId);
		
		MessageAll($MsgBeige, Client::getName(%clientId) @ " has succeeded in breaking seal #" @ %step @ "!");
	}
	
	storeData(%clientId, "noDropLootbagFlag", false);
	Colloseum::roomReset(%clientId, false);
	FellOffMap(%clientId);
}

function Colloseum::roomReset(%clientId, %flag)
{
	if(%flag)
	{
		if($Colloseum::Mode == "Seal")
			MessageAll($MsgBeige, Client::getName(%clientId) @ " has failed to break seal #" @ Colloseum::getCurrentStep(fetchData(%clientId, "RemortStep")));
		else
			MessageAll($MsgBeige, Client::getName(%clientId) @ " failed to achieve victory in round " @ $Colloseum::Round @ " of the Colloseum!");
	}
		
	$Colloseum::Mode = "";
	$Colloseum::Round = 0;
	$Colloseum::Client = false;
	for(%i = 1; %i <= 3; %i++)
	{
		%id = NEWgetClientByName($Colloseum::Bots[%i]);
		if(%id != -1 && !isDead(%id))
			Player::Kill(%id);

		$Colloseum::Bots[%i] = "";
	}
}

function Colloseum::isSealComplete()
{
	for(%i = 1; %i <= 3; %i++)
	{
		%id = NEWgetClientByName($Colloseum::Bots[%i]);

		if(%id != -1 && !isDead(%id))
			return false;
	}

	return true;
}

function Colloseum::spawnSeal(%clientId, %index)
{
	%newName = Colloseum::GetArmor() @ $numAI;
	%displayName = Colloseum::getName() @ $numAI;

	%loadout = Colloseum::scaleSeal(%clientId, %index);
	%position = -3588 @ " " @ -2364 @ " " @ 354;

	$numAI++;
	SpawnAI(%newName, %displayName, %position, "TempSpawn " @ %position @ " 1", %loadout, true);
	setAInumber(%newName, ($numAi - 1));
	%id = AI::getId(%newName);
	
	GameBase::setPosition(%id, %position);

	storeData(%id, "noDropLootbagFlag", true);
	storeData(%id, "noExperienceFlag", true);
	storeData(%id, "botAttackMode", 3);
	storeData(%id, "tmpbotdata", %position);
	storeData(%id, "colloseumOwner", %clientId);
	AI::newDirectiveFollow(%newName, %clientId, 0, 99);

	$Colloseum::Bots[%index] = %displayName;
	return;
}

function Colloseum::scaleSeal(%clientId, %index)
{	
	%max = round(getMaxLevel(%clientId) * 0.90);
	%remort = cap((fetchData(%clientId, "RemortStep")), 0, "inf");
	%step = Colloseum::getCurrentStep(%remort);
	%var = floor(getRandom() * 4) + 1;
	
	%loadout = "";
	%loadout = %loadout @ "LVL " @ %max @ " RemortStep " @ %remort @ " LCK " @ round(getRandom() * 8) @ " ";
	%loadout = %loadout @ "CLASS Random " @ Colloseum::getCurrentStepWeapons(%step, %var);
	return %loadout;
}

function Colloseum::getCurrentStepWeapons(%step, %index)
{
	if(%step == 0)
	{
		if(%index == 1)
			return "SteelBlade 1 ";
		else if(%index == 2)
			return "SteelSlicer 1 ";
		else if(%index == 3)
			return "SteelFlail 1 ";
		else if(%index == 4)
			return "SteelVault 1 TitaniumArrow 500 ";				
	}
	else if(%step == 1)
	{
		if(%index == 1)
			return "MythrilSplitter 1 ";
		else if(%index == 2)
			return "MythrilRapier 1 ";
		else if(%index == 3)
			return "MythrilSledge 1 ";
		else if(%index == 4)
			return "TitaniumSaint 1 MythrilArrow 500 ";				
	}
	else if(%step == 2)
	{
		if(%index == 1)
			return "DiamondBattleAxe 1 ";
		else if(%index == 2)
			return "DiamondScimtar 1 ";
		else if(%index == 3)
			return "DiamondSplatter 1 ";
		else if(%index == 4)
			return "MythrilArc 1 DiamondArrow 500 ";				
	}
	else
	{
		if(%index == 1)
			return "TerminusEst 1 ";
		else if(%index == 2)
			return "AecoSeori 1 ";
		else if(%index == 3)
			return "MorningStar 1 ";
		else if(%index == 4)
			return "DarkComet 1 AngelStorm 500 ";				
	}	
}

function Colloseum::StartColloseum(%clientId)
{
	%pos = -3588 @ " " @ -2364 @ " " @ 354;
	GameBase::setPosition(%clientId, %pos);
	
	%name = Client::getName(%clientId);
	if(!String::ICompare(fetchData(%clientId, "Race"), "Female"))
		%adj = her;
	else
		%adj = his;
	MessageAll($MsgBeige, %name @ " has entered the Colloseum! Type #eyes " @ %name @ " to watch " @ %adj @ " progress and #revert to stop!");
	
	$Colloseum::Mode = "Colloseum";
	$Colloseum::Round = 1;
	$Colloseum::Client = %clientId;
	storeData(%clientId, "noDropLootbagFlag", true);
	
	schedule("Colloseum::spawnRound(" @ %clientId @ ", " @ ($Colloseum::Round) @ ");", 0.33);
}

function Colloseum::spawnRound(%clientId, %round)
{
	%rank = fetchData(%clientId, "TourneyRank");
	%loadout = $Colloseum::Loadout[%rank, %round];
	
	%newName = Colloseum::GetArmor() @ $numAI;
	%displayName = Colloseum::getName() @ $numAI;
	$numAI++;

	%position = Panda::findMarkers("Colloseum\\" @ %round);
	SpawnAI(%newName, %displayName, %position, "TempSpawn " @ %position @ " 1", %loadout, true);
	setAInumber(%newName, ($numAi - 1));
	%id = AI::getId(%newName);
	
	GameBase::setPosition(%id, %position);

	storeData(%id, "noDropLootbagFlag", true);
	storeData(%id, "noExperienceFlag", true);
	storeData(%id, "botAttackMode", 3);
	storeData(%id, "tmpbotdata", %position);
	storeData(%id, "colloseumOwner", %clientId);
	AI::newDirectiveFollow(%newName, %clientId, 0, 99);
	
	$Colloseum::Bots[%round] = %displayName;
	return;
}

function Colloseum::checkRound(%aiId, %round)
{
	$Colloseum::Round++;
	if(%round <= 3)
	{
		%owner = fetchData(%aiId, "colloseumOwner");
		MessageAll($MsgBeige, Client::getName(%owner) @ " has completed round " @ %round @ " in the Colloseum!");
		$Colloseum::Bots[%round] = "";
		
		if(%round < 3)
			schedule("Colloseum::spawnRound(" @ %owner @ ", " @ (%round + 1) @ ");", 0.33);
		else
		{
			for(%i = 1; %i <= 3; %i++)
				schedule("Colloseum::spawnRound(" @ %owner @ ", " @ %i @ ");", (%i * 0.33));		
		}

		return true;
	}
	else
	{
		%owner = fetchData(%aiId, "colloseumOwner");
		
		%flag = true;
		for(%i = 1; %i <= 3; %i++)
		{
			%id = NEWgetClientByName($Colloseum::Bots[%i]);
			if(%id != -1 || !isDead(%id))
				%flag = false;
		}

		if(%flag)
		{		
			storeData(%owner, "noDropLootbagFlag", false);
			Colloseum::roomReset(%owner, false);

			storeData(%owner, "TourneyRank", 1, "inc");
			%rank = fetchData(%owner, "TourneyRank");			

			MessageAll($MsgBeige, Client::getName(%owner) @ " has completed rank " @ %rank @ " of the Colloseum and has earned the title of " @ $Colloseum::Rank[%rank] @ "!");
			FellOffMap(%owner);
			GiveThisStuff(%owner, $Colloseum::colloseumReward[(%rank - 1)], true);

			return true;
		}		
	}
	return false;
}

function Colloseum::canEnterColloseum(%clientId)
{
	%required = ((fetchData(%clientId, "TourneyRank") + 1) * 50);
	
	if(fetchData(%clientId, "LVL") >= %required)
		return true;
	
	return false;
}

function Colloseum::getLevelsLeft(%clientId)
{
	%level = fetchData(%clientId, "LVL");
	%required = ((fetchData(%clientId, "TourneyRank") + 1) * 50);
	
	if(%level >= %required)
		return 0;
	
	return %required - %level;
}

function Duel::isDueling(%clientId)
{
	%name = Client::getName(%clientId);
	if($Duel::Challenger == %name || $Duel::Opponent == %name)
		return true;
	else
		return false;
}

function Duel::startDuel(%clientId, %id)
{
	MessageAll($MsgBeige, Client::getName(%clientId) @ " has challenged " @ Client::getName(%id) @ " to a duel to the death!");
	
	GameBase::setPosition(%clientId, Panda::findMarkers("Dueling\\Challenger"));
	Player::setDamageFlash(%clientId, 2);	
	$Duel::Challenger = Client::getName(%clientId);

	GameBase::setPosition(%id, Panda::findMarkers("Dueling\\Opponent"));
	Player::setDamageFlash(%id, 2);
	$Duel::Opponent = Client::getName(%id);
}

function Duel::endDuel(%pass)
{
	if(%pass)
	{
		MessageAll($MsgBeige, "Challenger " @ $Duel::Challenger @ " defeated " @ $Duel::Opponent @ " in their duel!");
		%victor = $Duel::Challenger;
		%loser = $Duel::Opponent;
	}
	else
	{
		MessageAll($MsgBeige, "Challenger " @ $Duel::Challenger @ " was defeated by " @ $Duel::Opponent @ " in their duel!");
		%victor = $Duel::Opponent;
		%loser = $Duel::Challenger;
	}

	Duel::Reset(NEWgetClientByName(%victor));
}

function Duel::Runaway(%clientId, %try)
{
	%name = Client::getName(%clientId);

	if(%name == $Duel::Challenger)
	{
		%runaway = $Duel::Challenger;
		%otherName = $Duel::Opponent;
	}
	else if(%name == $Duel::Opponent)
	{
		%runaway = $Duel::Opponent;
		%otherName = $Duel::Challenger;
	}

	%otherId = NEWgetClientByName(%otherName);
	MessageAll($MsgBeige, %otherName @ " won the duel with " @ %runaway @ " because they chickened out!");
	MessageAll($MsgRed, %runaway @ " has been jailed for 300 seconds for chickening out of the duel!");
	
	if(%try)
		schedule("Jail(" @ %clientId @ ", 300, " @ GetRandomJailNumber() @ ");", 1);
	else
		storeData(%clientId, "Jail", 300);

	if(fetchData(%clientId, "MyHouse") != "" && fetchData(%otherId, "MyHouse") != "")
	{
		if(fetchData(%clientId, "MyHouse") != fetchData(%otherId, "MyHouse"))
		{
			storeData(%otherId, "RankPoints", 1, "inc");
			storeData(%clientId, "RankPoints", 2, "dec");
			
			if(%try)
				Client::sendMessage(%clientId, $MsgBeige, "You have lost two rank points for fleeing the duel!");
			Client::sendMessage(%otherId, $MsgBeige, "You have received one rank point for your opponent fleeing the duel!");
		}
	}		

	Duel::Reset(%otherId);
}

function Duel::Reset(%clientId)
{
	$Duel::Challenger = "";
	$Duel::Opponent = "";
	fellOffMap(%clientId);
}